# Planwright — scheduling rules and where they came from

Source studied: `ProjectPlan_365_Mac_26.49.1299.pkg` → `Project Plan 365.app` (Xamarin.Mac / .NET).
The planning engine is `MonoBundle/HousatonicMPP_PCL.dll` (sha256 9007a72d…ea), read with the
built-in .NET reader (evidence ev_27d7f345…, ev_d2bf127f…). Addresses below are .NET method names
and IL offsets (there are no native addresses; this is managed code). Nothing was copied: the rules
were written down here and re-implemented in `src/schedule.rs` and `src/calendar.rs`.

## The native main program (decompiled)
`Contents/MacOS/Project Plan 365` (arm64 Mach-O, sha256 83de6358…e6e6) was opened and decompiled:
* `_main` @ 0x10008ab48 → only `objc_alloc_init`, then `xamarin_main(argc, argv)`: it starts the .NET runtime.
* Its 18 312 functions are Objective-C bridges. For example `-[Housatonic_ProjectMac_CalendarBarView mouseDown:]` @ 0x10008e484,
  `-[NewCalendarHeader drawRect:]` @ 0x1000a42c8 and `-[NewCalendarTable mouseDown:]` @ 0x1000a4724 each just call
  `native_to_managed_trampoline_N` to hand the event to .NET code.
* The strings that match Slack/Critical/Predecessor/Calendar are Objective-C class and selector names (e.g. `PredecessorsPickerEditControl`), with no code referencing them.
* Read with native_function_pseudocode (Ghidra failed to analyse this program, so the built-in decompiler answered):
  - `_xamarin_main` @ 0x1000113f4: xamarin_setup → chdir to bundle → xamarin_vm_initialize → xamarin_open_and_register("%s.exe") → `mono_jit_exec` of the main .NET assembly.
  - `native_to_managed_trampoline_3` @ 0x10008b4c4: `xamarin_get_method_from_token` → `mono_runtime_invoke` (the only string: "Unable to marshal the parameter").
  - `-[TaskInfoDialog setPredecessorsGrid:]` @ 0x100136284 and `-[PredecessorsPickerEditControl keyUp:]` @ 0x100183008: one call each into that trampoline.
* `native_strings_find` for kWarning_Circular_Relationship / CriticalSlackDays / HoursInDay / DefaultDuration finds nothing; "Predecessor" only matches outlet names of TaskInfoDialog.
So no planning rule lives in native code. Every rule below was read from the .NET IL (not ReadyToRun) of HousatonicMPP_PCL.dll.

## Defaults (DefaultSettings::.ctor, IL_0018–IL_007d)
| Value | Original | Here |
|---|---|---|
| Hours per day | `ldc.r4 8` → set_DefaultHoursInDay | 480 working minutes |
| Hours per week | `ldc.r4 40` → set_DefaultHoursInWeek | 2400 minutes |
| Standard rate | `ldc.r8 10` → MPXRate(10, per hour) | new resource 10/h |
| Overtime rate | `ldc.r8 15` | new resource 15/h |
| Default task type | `ldc.i4.1` (fixed duration) | duration drives work |
| Default task mode | `ldc.i4.0` (auto scheduled) | new tasks auto scheduled |
| Days per month | get_DefaultDaysPerMonth reads record field 11 from the file; the constructor never sets it | 20 (**estimated**, MS Project convention) |
| New task duration | MPXCalendar::GetDefaultDuration = TimeSpan.FromHours(Hours[1].IntervalTotal), the calendar's working hours on Monday (IL_0002–IL_000e) | Monday's working minutes (8 h on Standard), marked estimated "?" (the "?" flag itself is **estimated**) |

## Standard calendar (MPXCalendar::addDefaultCalendarHours, default branch IL_0194–IL_028a)
* Days 2–6 (Mon–Fri): 08:00–12:00 and 13:00–17:00.
* Days 1 and 7 (Sun, Sat): non-working (`SetInterval(MinValue, MinValue)`).
* (French/German/Italian/Russian/Spanish locales use other hours — not reproduced.)

## Durations
* Stored as tenths of a minute (`MPPDuration.MppValue / 10` → minutes in Task::CoumputeEarlyStartPDM_FS IL_0013–IL_0022). Here: whole minutes.
* Shown in days = minutes / minutes-per-day.

## Calculation order (PDM::CalculateProject → PDM::SetDates)
1. Reset IDs, WBS, resource IDs (ResetIDs/ResetWBS/ResetResourceIDs).
2. Build the precedence graph; a cycle stops the calculation with warning
   `kWarning_Circular_Relationship` naming the two tasks (IL_0098–IL_0101). Here: same — a message names both IDs and the old dates are kept.
3. Hierarchy graph topological sort (TasksGraph::ConstructHierarchyGraph).
4. Early dates: open-ended tasks → manual tasks → auto tasks → placeholders (SetDates IL_011b–IL_0133).
5. Late dates (IL_0330), then **as-late-as-possible tasks** (IL_0338, after late dates), then scheduled dates.
6. Summary roll-up (Task::CalculateSummaryPDM), work/cost (SetWorkCost), slacks (Task::ComputeSlacks), critical flag.

## Links (Task::CoumputeEarlyStartPDM_FS)
* FS: successor start = predecessor finish + lag in **working time** (`getDate(calendar, predFinish, lag)`); if the successor's duration ≠ 0 the date is moved to the next working moment (`calendar.getStart`, IL_0070–IL_0076). Milestones keep the exact finish time.
* Elapsed lags add wall-clock time (IL_0009–IL_0027) — **not implemented** (lags are working time only).
* SS / FF / SF follow the same pattern with start/finish swapped (relation types read in ComputeSlacks IL_01ad–IL_02bd).

## Slack and critical (Task::ComputeSlacks, PDM::SetDates IL_088e–IL_08ba)
* Start slack = working time from early start to late start; finish slack = early finish to late finish; negatives clamped to 0 (IL_0098–IL_00eb).
* Total slack = start slack when it is smaller **and** the task is 0 % complete, otherwise finish slack (IL_00f3–IL_0146).
* Free slack = smallest gap to any successor for its link type (FS: succ ES − (EF+lag); SS: succ ES − (ES+lag); FF: succ EF − (EF+lag); SF: succ EF − (ES+lag)); no successors → total slack; completed task → 0 (IL_014e–IL_0384).
* Critical = active **and** total slack (tenth-minutes) ≤ CriticalSlackDays × 4800 (IL_0896–IL_08ba). 4800 tenth-minutes = one 8-hour day.
* CriticalSlackDays default = 0: MPPFile's constructors never assign it (only the save path reads it).

## Constraints (ConstraintTypeEnum order: ASAP, ALAP, MSO, MFO, SNET, SNLT, FNET, FNLT)
* Honoured over links (a conflict is flagged with an indicator).
* Typing a start on an auto-scheduled task (Task::SetFieldStart): constraint type 4 = *Start No Earlier Than* on that date (IL_021b–IL_0229).
  If the task has exactly one predecessor, that link is Finish-to-Start with zero lag, and the predecessor's early finish date is later than the typed date, the link is removed (IL_0235–IL_02b9).
  Dragging a bar uses the same SNET rule here (drag itself is **estimated**).

## Summary tasks
* Start = earliest child start, finish = latest child finish, duration = working time between them.
* % complete (Task::SetSummaryPercent + CalculateSummaryPDM IL_0063–IL_00a0): over **active** subtasks only,
  actual duration = round(duration × % / 100); summary % = Σ actual duration / Σ duration × 100.
  If the subtasks have no duration: 100 % when all are complete, else 0 % (IL_01c8).
* Typing a % on a summary (PercentCalculatorForSummaryTasks::SetPercent / SplitPercentForTasks):
  0 %, 100 % or only zero-duration subtasks → every subtask gets that %. Otherwise done share =
  Σ durations × % / 100 (GetEntireDuration, IL_0035–IL_0052). It is poured into the subtasks in date order over the
  sorted start/finish points (GetDurationIntersectionsPoints). Tasks overlapping an interval share it
  (GetActualDurationForTasksUID, interval length = calendar working time × 600 tenth-minutes/hour). Each subtask's % =
  filled / duration × 100, capped at 100 (SetPercentForTasks). Milestones finishing by the last filled point get
  100 %, later ones 0 % (SetPercentForTasksWithDuration0).
* Links on a summary task apply to all of its subtasks.

## Resources
* Work = duration × assignment units (fixed-duration default). Cost = work hours × standard rate + cost per use; material = units × rate + cost per use.
* Over-allocated = more units booked at the same time than Max Units (flag m_IsDirtyOverallocated recomputed in CalculateProject).
* Level All delays the later / lower-priority of two clashing tasks until the other finishes (**estimated**: leveling classes LevelAllActivity/LevelingOptions exist, algorithm not decoded).

## Default view list (MPPFile::.ctor IL_02ed–IL_0325)
Gantt Chart, Tracking Gantt, Task Sheet, Resource Sheet, Calendar, Timeline, Team Planner, Multiple Baselines Gantt.
Here: all except Multiple Baselines Gantt (one baseline is kept; Tracking Gantt shows it), plus Network Diagram.

## Not reproduced
* Reading/writing binary .mpp files and cloud drives (OneDrive, Google Drive, Dropbox, Box, SharePoint, Project Server). Exchange is via Microsoft Project XML instead.
* Reports/dashboards, agile boards, AI status report, multiple baselines (1–10), interim plans, elapsed lags, task splits, recurring tasks, sub-projects.
