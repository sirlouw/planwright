#!/bin/bash
# Double-click this file on a Mac to build Planwright.app and Planwright.dmg.
# It installs what it needs the first time (Apple's command line tools and Rust).
cd "$(dirname "$0")"
# the kit keeps this file next to Cargo.toml; in the source tree it lives in packaging/macos
if [ ! -f Cargo.toml ]; then cd ../..; fi

echo "== Building Planwright for Mac =="

if ! xcode-select -p >/dev/null 2>&1; then
  echo "Installing Apple's command line tools. A window will open - click Install."
  echo "When it has finished, double-click this file again."
  xcode-select --install
  read -n 1 -s -r -p "Press any key to close."
  exit 0
fi

if ! command -v cargo >/dev/null 2>&1; then
  if [ -f "$HOME/.cargo/env" ]; then
    . "$HOME/.cargo/env"
  else
    echo "Installing Rust (one time, a few minutes)..."
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
    . "$HOME/.cargo/env"
  fi
fi

if sh packaging/macos/build-mac-app.sh; then
  echo ""
  echo "Finished. Planwright.app and Planwright.dmg are in dist/macos (opening it now)."
  echo "Drag Planwright.app into Applications. The first time, right-click it and choose Open."
  open dist/macos
else
  echo ""
  echo "The build stopped with an error (see above)."
fi
read -n 1 -s -r -p "Press any key to close."
