//! Project data: tasks, links, resources, assignments, and the text formats
//! used in the grid (durations like "3 days", predecessors like "2FS+1d").

use crate::calendar::WorkCalendar;
use chrono::{NaiveDate, NaiveDateTime};
use serde::{Deserialize, Serialize};

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub enum LinkKind {
    FS,
    SS,
    FF,
    SF,
}

impl LinkKind {
    pub const ALL: [LinkKind; 4] = [LinkKind::FS, LinkKind::SS, LinkKind::FF, LinkKind::SF];
    pub fn code(self) -> &'static str {
        match self {
            LinkKind::FS => "FS",
            LinkKind::SS => "SS",
            LinkKind::FF => "FF",
            LinkKind::SF => "SF",
        }
    }
    pub fn label(self) -> &'static str {
        match self {
            LinkKind::FS => "Finish-to-Start (FS)",
            LinkKind::SS => "Start-to-Start (SS)",
            LinkKind::FF => "Finish-to-Finish (FF)",
            LinkKind::SF => "Start-to-Finish (SF)",
        }
    }
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Link {
    pub pred: u32,
    pub kind: LinkKind,
    /// Lag in working minutes (may be negative = lead).
    pub lag: i64,
}

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub enum Constraint {
    ASAP,
    ALAP,
    SNET,
    SNLT,
    FNET,
    FNLT,
    MSO,
    MFO,
}

impl Constraint {
    pub const ALL: [Constraint; 8] = [
        Constraint::ASAP,
        Constraint::ALAP,
        Constraint::MSO,
        Constraint::MFO,
        Constraint::SNET,
        Constraint::SNLT,
        Constraint::FNET,
        Constraint::FNLT,
    ];
    pub fn label(self) -> &'static str {
        match self {
            Constraint::ASAP => "As Soon As Possible",
            Constraint::ALAP => "As Late As Possible",
            Constraint::MSO => "Must Start On",
            Constraint::MFO => "Must Finish On",
            Constraint::SNET => "Start No Earlier Than",
            Constraint::SNLT => "Start No Later Than",
            Constraint::FNET => "Finish No Earlier Than",
            Constraint::FNLT => "Finish No Later Than",
        }
    }
    pub fn needs_date(self) -> bool {
        !matches!(self, Constraint::ASAP | Constraint::ALAP)
    }
    pub fn is_finish(self) -> bool {
        matches!(self, Constraint::MFO | Constraint::FNET | Constraint::FNLT)
    }
    pub fn inflexible(self) -> bool {
        matches!(self, Constraint::MSO | Constraint::MFO | Constraint::SNLT | Constraint::FNLT)
    }
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Assignment {
    pub res: u32,
    /// 1.0 = 100 %.
    pub units: f64,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Baseline {
    pub start: NaiveDateTime,
    pub finish: NaiveDateTime,
    pub dur: i64,
    pub work: f64,
    pub cost: f64,
}

/// Values the scheduler fills in; never saved.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct Calc {
    pub id: usize,
    pub wbs: String,
    pub summary: bool,
    pub parent: Option<usize>,
    pub es: Option<NaiveDateTime>,
    pub ef: Option<NaiveDateTime>,
    pub ls: Option<NaiveDateTime>,
    pub lf: Option<NaiveDateTime>,
    pub total_slack: i64,
    pub free_slack: i64,
    pub critical: bool,
    pub work_min: f64,
    pub cost: f64,
    pub late: bool,
    pub missed_deadline: bool,
    pub overallocated: bool,
    pub conflict: bool,
    pub visible: bool,
}

fn default_true() -> bool {
    true
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Task {
    pub uid: u32,
    pub name: String,
    pub level: u32,
    pub manual: bool,
    #[serde(default = "default_true")]
    pub active: bool,
    /// Duration in working minutes.
    pub dur: i64,
    #[serde(default)]
    pub estimated: bool,
    pub start: NaiveDateTime,
    pub finish: NaiveDateTime,
    pub constraint: Constraint,
    pub constraint_date: Option<NaiveDateTime>,
    pub deadline: Option<NaiveDate>,
    pub percent: f64,
    pub links: Vec<Link>,
    pub assign: Vec<Assignment>,
    #[serde(default)]
    pub notes: String,
    pub priority: u32,
    #[serde(default)]
    pub collapsed: bool,
    #[serde(default)]
    pub on_timeline: bool,
    #[serde(default)]
    pub baseline: Option<Baseline>,
    /// Leveling delay in working minutes.
    #[serde(default)]
    pub level_delay: i64,
    #[serde(default)]
    pub fixed_cost: f64,
    #[serde(default)]
    pub milestone_flag: bool,
    #[serde(skip)]
    pub calc: Calc,
}

impl Task {
    pub fn new(uid: u32, name: &str, start: NaiveDateTime, dur: i64) -> Self {
        Task {
            uid,
            name: name.into(),
            level: 1,
            manual: false,
            active: true,
            dur,
            estimated: false,
            start,
            finish: start,
            constraint: Constraint::ASAP,
            constraint_date: None,
            deadline: None,
            percent: 0.0,
            links: vec![],
            assign: vec![],
            notes: String::new(),
            priority: 500,
            collapsed: false,
            on_timeline: false,
            baseline: None,
            level_delay: 0,
            fixed_cost: 0.0,
            milestone_flag: false,
            calc: Calc::default(),
        }
    }
    pub fn is_milestone(&self) -> bool {
        (self.dur == 0 || self.milestone_flag) && !self.calc.summary
    }
    pub fn complete(&self) -> bool {
        self.percent >= 100.0
    }
}

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub enum ResKind {
    Work,
    Material,
    Cost,
}

impl ResKind {
    pub fn label(self) -> &'static str {
        match self {
            ResKind::Work => "Work",
            ResKind::Material => "Material",
            ResKind::Cost => "Cost",
        }
    }
}

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub enum Accrue {
    Start,
    Prorated,
    End,
}

impl Accrue {
    pub fn label(self) -> &'static str {
        match self {
            Accrue::Start => "Start",
            Accrue::Prorated => "Prorated",
            Accrue::End => "End",
        }
    }
}

#[derive(Clone, Debug, Default, PartialEq)]
pub struct ResCalc {
    pub id: usize,
    pub work_min: f64,
    pub cost: f64,
    pub overallocated: bool,
    pub peak: f64,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Resource {
    pub uid: u32,
    pub name: String,
    pub kind: ResKind,
    pub material_label: String,
    pub initials: String,
    pub group: String,
    pub max_units: f64,
    pub std_rate: f64,
    pub ovt_rate: f64,
    pub cost_per_use: f64,
    pub accrue: Accrue,
    #[serde(default)]
    pub email: String,
    #[serde(default)]
    pub notes: String,
    #[serde(skip)]
    pub calc: ResCalc,
}

impl Resource {
    pub fn new(uid: u32, name: &str) -> Self {
        let initials: String = name.split_whitespace().filter_map(|w| w.chars().next()).collect();
        Resource {
            uid,
            name: name.into(),
            kind: ResKind::Work,
            material_label: String::new(),
            initials,
            group: String::new(),
            max_units: 1.0,
            // DefaultSettings: standard rate 10/h, overtime 15/h
            std_rate: 10.0,
            ovt_rate: 15.0,
            cost_per_use: 0.0,
            accrue: Accrue::Prorated,
            email: String::new(),
            notes: String::new(),
            calc: ResCalc::default(),
        }
    }
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Project {
    pub title: String,
    pub manager: String,
    pub company: String,
    pub start: NaiveDateTime,
    pub status_date: Option<NaiveDate>,
    pub calendar: WorkCalendar,
    pub tasks: Vec<Task>,
    pub resources: Vec<Resource>,
    pub next_uid: u32,
    pub next_res_uid: u32,
    pub minutes_per_day: i64,
    pub minutes_per_week: i64,
    pub days_per_month: i64,
    pub critical_slack_days: i64,
    pub new_tasks_manual: bool,
    pub currency: String,
    #[serde(default)]
    pub notes: String,
}

impl Project {
    pub fn blank(start: NaiveDateTime) -> Self {
        Project {
            title: "Project1".into(),
            manager: String::new(),
            company: String::new(),
            start,
            status_date: None,
            calendar: WorkCalendar::standard(),
            tasks: vec![],
            resources: vec![],
            next_uid: 1,
            next_res_uid: 1,
            // DefaultSettings: 8 h/day, 40 h/week
            minutes_per_day: 480,
            minutes_per_week: 2400,
            days_per_month: 20,
            critical_slack_days: 0,
            new_tasks_manual: false,
            currency: "$".into(),
            notes: String::new(),
        }
    }

    /// MPXCalendar::GetDefaultDuration: a new task lasts the calendar's working hours of
    /// `Hours[1]` (Monday in the 0 = Sunday table) - 8 h on the Standard calendar.
    pub fn default_task_minutes(&self) -> i64 {
        let m: i64 = self.calendar.week[0].iter().map(|(s, e)| (*e - *s) as i64).sum();
        if m > 0 { m } else { self.minutes_per_day }
    }

    pub fn alloc_uid(&mut self) -> u32 {
        let u = self.next_uid;
        self.next_uid += 1;
        u
    }

    pub fn alloc_res_uid(&mut self) -> u32 {
        let u = self.next_res_uid;
        self.next_res_uid += 1;
        u
    }

    pub fn index_of(&self, uid: u32) -> Option<usize> {
        self.tasks.iter().position(|t| t.uid == uid)
    }

    pub fn res_index(&self, uid: u32) -> Option<usize> {
        self.resources.iter().position(|r| r.uid == uid)
    }

    pub fn finish(&self) -> NaiveDateTime {
        self.tasks.iter().map(|t| t.finish).max().unwrap_or(self.start)
    }

    pub fn first_start(&self) -> NaiveDateTime {
        self.tasks.iter().map(|t| t.start).min().unwrap_or(self.start)
    }

    // ---------- text formats ----------

    pub fn fmt_duration(&self, minutes: i64, estimated: bool) -> String {
        let q = if estimated { "?" } else { "" };
        let days = minutes as f64 / self.minutes_per_day as f64;
        let s = fmt_num(days);
        if (days - 1.0).abs() < 1e-9 {
            format!("1 day{q}")
        } else {
            format!("{s} days{q}")
        }
    }

    pub fn fmt_lag(&self, minutes: i64) -> String {
        if minutes == 0 {
            return String::new();
        }
        let sign = if minutes > 0 { "+" } else { "-" };
        let a = minutes.abs();
        if a % self.minutes_per_day == 0 {
            format!("{sign}{} days", a / self.minutes_per_day)
        } else if a % 60 == 0 {
            format!("{sign}{} hrs", a / 60)
        } else {
            format!("{sign}{} mins", a)
        }
    }

    /// Parses "3", "3d", "3 days", "4h", "2w", "1mo", "30m", optionally ending with "?".
    pub fn parse_duration(&self, text: &str) -> Option<(i64, bool)> {
        let t = text.trim().to_lowercase();
        if t.is_empty() {
            return None;
        }
        let estimated = t.ends_with('?');
        let t = t.trim_end_matches('?').trim();
        let num_end = t
            .char_indices()
            .find(|(_, c)| !(c.is_ascii_digit() || *c == '.' || *c == ',' || *c == '-' || *c == '+'))
            .map(|(i, _)| i)
            .unwrap_or(t.len());
        let n: f64 = t[..num_end].replace(',', ".").parse().ok()?;
        let unit = t[num_end..].trim();
        let mins = match unit {
            "" | "d" | "day" | "days" | "dy" | "dys" => n * self.minutes_per_day as f64,
            "h" | "hr" | "hrs" | "hour" | "hours" => n * 60.0,
            "m" | "min" | "mins" | "minute" | "minutes" => n,
            "w" | "wk" | "wks" | "week" | "weeks" => n * self.minutes_per_week as f64,
            "mo" | "mon" | "mons" | "month" | "months" => {
                n * (self.days_per_month * self.minutes_per_day) as f64
            }
            _ => return None,
        };
        Some((mins.round() as i64, estimated))
    }

    pub fn fmt_preds(&self, t: &Task) -> String {
        let mut parts = vec![];
        for l in &t.links {
            let Some(pi) = self.index_of(l.pred) else { continue };
            let id = self.tasks[pi].calc.id;
            let mut s = id.to_string();
            if l.kind != LinkKind::FS || l.lag != 0 {
                s.push_str(l.kind.code());
            }
            s.push_str(&self.fmt_lag(l.lag));
            parts.push(s);
        }
        parts.join(",")
    }

    /// Parses "2,3SS+1d,4FF-2h" (task IDs as shown in the grid).
    pub fn parse_preds(&self, text: &str) -> Result<Vec<Link>, String> {
        let mut out = vec![];
        for part in text.split([',', ';']) {
            let p = part.trim();
            if p.is_empty() {
                continue;
            }
            let digits: String = p.chars().take_while(|c| c.is_ascii_digit()).collect();
            if digits.is_empty() {
                return Err(format!("'{p}' doesn't start with a task ID"));
            }
            let id: usize = digits.parse().map_err(|_| format!("bad ID in '{p}'"))?;
            let rest = p[digits.len()..].trim().to_uppercase();
            let (kind, rest) = if rest.starts_with("FS") {
                (LinkKind::FS, &rest[2..])
            } else if rest.starts_with("SS") {
                (LinkKind::SS, &rest[2..])
            } else if rest.starts_with("FF") {
                (LinkKind::FF, &rest[2..])
            } else if rest.starts_with("SF") {
                (LinkKind::SF, &rest[2..])
            } else {
                (LinkKind::FS, rest.as_str())
            };
            let rest = rest.trim();
            let lag = if rest.is_empty() {
                0
            } else {
                let (m, _) = self
                    .parse_duration(rest)
                    .ok_or_else(|| format!("can't read the lag '{rest}'"))?;
                m
            };
            let Some(task) = self.tasks.iter().find(|t| t.calc.id == id) else {
                return Err(format!("there is no task with ID {id}"));
            };
            out.push(Link { pred: task.uid, kind, lag });
        }
        Ok(out)
    }

    pub fn fmt_resources(&self, t: &Task) -> String {
        t.assign
            .iter()
            .filter_map(|a| {
                let r = &self.resources[self.res_index(a.res)?];
                Some(if (a.units - 1.0).abs() < 1e-9 || r.kind != ResKind::Work {
                    if r.kind == ResKind::Material && (a.units - 1.0).abs() > 1e-9 {
                        format!("{}[{} {}]", r.name, fmt_num(a.units), r.material_label)
                    } else {
                        r.name.clone()
                    }
                } else {
                    format!("{}[{}%]", r.name, fmt_num(a.units * 100.0))
                })
            })
            .collect::<Vec<_>>()
            .join(",")
    }

    /// Parses "Ann,Bob[50%]"; unknown names become new work resources.
    pub fn parse_resources(&mut self, text: &str) -> Vec<Assignment> {
        let mut out = vec![];
        for part in text.split([',', ';']) {
            let p = part.trim();
            if p.is_empty() {
                continue;
            }
            let (name, units) = if let Some(i) = p.find('[') {
                let name = p[..i].trim();
                let inner = p[i + 1..].trim_end_matches(']').trim();
                let num: String = inner
                    .chars()
                    .take_while(|c| c.is_ascii_digit() || *c == '.' || *c == ',')
                    .collect();
                let v: f64 = num.replace(',', ".").parse().unwrap_or(100.0);
                let units = if inner.contains('%') { v / 100.0 } else { v };
                (name.to_string(), units)
            } else {
                (p.to_string(), 1.0)
            };
            let uid = match self.resources.iter().find(|r| r.name.eq_ignore_ascii_case(&name)) {
                Some(r) => r.uid,
                None => {
                    let uid = self.alloc_res_uid();
                    self.resources.push(Resource::new(uid, &name));
                    uid
                }
            };
            let units = if self.resources[self.res_index(uid).unwrap()].kind == ResKind::Work
                && !p.contains('[')
            {
                1.0
            } else {
                units
            };
            if !out.iter().any(|a: &Assignment| a.res == uid) {
                out.push(Assignment { res: uid, units });
            }
        }
        out
    }

    pub fn money(&self, v: f64) -> String {
        format!("{}{}", self.currency, fmt_money(v))
    }
}

pub fn fmt_num(v: f64) -> String {
    if (v - v.round()).abs() < 1e-9 {
        format!("{}", v.round() as i64)
    } else {
        let s = format!("{:.2}", v);
        s.trim_end_matches('0').trim_end_matches('.').to_string()
    }
}

pub fn fmt_money(v: f64) -> String {
    let neg = v < 0.0;
    let cents = (v.abs() * 100.0).round() as i64;
    let whole = cents / 100;
    let frac = cents % 100;
    let digits = whole.to_string();
    let mut grouped = String::new();
    for (i, c) in digits.chars().enumerate() {
        if i > 0 && (digits.len() - i) % 3 == 0 {
            grouped.push(',');
        }
        grouped.push(c);
    }
    format!("{}{}.{:02}", if neg { "-" } else { "" }, grouped, frac)
}

pub fn fmt_work(minutes: f64) -> String {
    format!("{} hrs", fmt_num(minutes / 60.0))
}

/// "Mon 11/23/26" - the short date style of desktop planners.
pub fn fmt_date(dt: NaiveDateTime) -> String {
    dt.format("%a %m/%d/%y").to_string()
}

pub fn fmt_date_long(dt: NaiveDateTime) -> String {
    dt.format("%a %b %-d, %Y %H:%M").to_string()
}

pub fn parse_date(text: &str) -> Option<NaiveDate> {
    let t = text.trim();
    let t = t
        .split_once(' ')
        .map(|(a, b)| if a.chars().all(|c| c.is_alphabetic()) { b } else { t })
        .unwrap_or(t)
        .trim();
    for f in ["%m/%d/%y", "%m/%d/%Y", "%Y-%m-%d", "%d.%m.%Y", "%d.%m.%y", "%b %d %Y", "%b %d, %Y"] {
        if let Ok(d) = NaiveDate::parse_from_str(t, f) {
            return Some(d);
        }
    }
    None
}
