//! Starter plans offered under File > New (our own sample content).

use crate::model::*;
use chrono::NaiveDate;

/// (level, name, duration in days, predecessors as row numbers 1-based "2,3", resources, percent)
type Row<'a> = (u32, &'a str, f64, &'a str, &'a str, f64);

fn build(title: &str, monday: NaiveDate, resources: &[(&str, &str, f64)], rows: &[Row]) -> Project {
    let mut p = Project::blank(monday.and_hms_opt(8, 0, 0).unwrap());
    p.title = title.into();
    for (name, group, rate) in resources {
        let uid = p.alloc_res_uid();
        let mut r = Resource::new(uid, name);
        r.group = group.to_string();
        r.std_rate = *rate;
        r.ovt_rate = rate * 1.5;
        p.resources.push(r);
    }
    let mut uids = vec![];
    for (level, name, days, _, res, pct) in rows {
        let uid = p.alloc_uid();
        uids.push(uid);
        let mut t = Task::new(uid, name, p.start, (days * p.minutes_per_day as f64) as i64);
        t.level = *level;
        t.percent = *pct;
        if !res.is_empty() {
            t.assign = p.parse_resources(res);
        }
        p.tasks.push(t);
    }
    for (k, (_, _, _, preds, _, _)) in rows.iter().enumerate() {
        for part in preds.split(',').filter(|s| !s.trim().is_empty()) {
            let part = part.trim();
            let digits: String = part.chars().take_while(|c| c.is_ascii_digit()).collect();
            let Ok(n) = digits.parse::<usize>() else { continue };
            let rest = &part[digits.len()..];
            let (kind, lag_txt) = if let Some(r) = rest.strip_prefix("SS") {
                (LinkKind::SS, r)
            } else if let Some(r) = rest.strip_prefix("FF") {
                (LinkKind::FF, r)
            } else if let Some(r) = rest.strip_prefix("SF") {
                (LinkKind::SF, r)
            } else {
                (LinkKind::FS, rest.strip_prefix("FS").unwrap_or(rest))
            };
            let lag = if lag_txt.is_empty() { 0 } else { p.parse_duration(lag_txt).map(|x| x.0).unwrap_or(0) };
            if n >= 1 && n <= uids.len() {
                p.tasks[k].links.push(Link { pred: uids[n - 1], kind, lag });
            }
        }
    }
    p
}

pub fn blank(monday: NaiveDate) -> Project {
    Project::blank(monday.and_hms_opt(8, 0, 0).unwrap())
}

pub fn website_launch(monday: NaiveDate) -> Project {
    let mut p = build(
        "Website Launch",
        monday,
        &[
            ("Alex Morgan", "Management", 65.0),
            ("Sam Rivera", "Design", 48.0),
            ("Jordan Lee", "Development", 55.0),
            ("Casey Brooks", "Development", 52.0),
            ("Taylor Kim", "Content", 40.0),
        ],
        &[
            (1, "Planning", 0.0, "", "", 0.0),
            (2, "Kick-off meeting", 0.5, "", "Alex Morgan,Sam Rivera,Jordan Lee", 100.0),
            (2, "Gather requirements", 3.0, "2", "Alex Morgan", 100.0),
            (2, "Site map and content plan", 2.0, "3", "Taylor Kim", 60.0),
            (2, "Requirements signed off", 0.0, "3,4", "", 0.0),
            (1, "Design", 0.0, "", "", 0.0),
            (2, "Wireframes", 4.0, "5", "Sam Rivera", 0.0),
            (2, "Visual design", 5.0, "7", "Sam Rivera", 0.0),
            (2, "Design review", 1.0, "8", "Alex Morgan,Sam Rivera", 0.0),
            (1, "Build", 0.0, "", "", 0.0),
            (2, "Set up hosting", 1.0, "5", "Casey Brooks", 0.0),
            (2, "Front-end pages", 8.0, "9", "Jordan Lee", 0.0),
            (2, "Content entry", 5.0, "4,12SS+3d", "Taylor Kim", 0.0),
            (2, "Contact form and search", 4.0, "11,9", "Casey Brooks", 0.0),
            (1, "Launch", 0.0, "", "", 0.0),
            (2, "Testing and fixes", 4.0, "12,13,14", "Jordan Lee,Casey Brooks", 0.0),
            (2, "Go live", 0.0, "16", "", 0.0),
            (2, "Launch announcement", 1.0, "17", "Taylor Kim", 0.0),
        ],
    );
    for t in p.tasks.iter_mut() {
        if matches!(t.name.as_str(), "Requirements signed off" | "Visual design" | "Go live" | "Front-end pages") {
            t.on_timeline = true;
        }
    }
    p.tasks[16].deadline = Some(monday + chrono::Duration::days(46));
    p.tasks[6].notes = "Cover home, product and contact pages first.".into();
    p
}

pub fn office_move(monday: NaiveDate) -> Project {
    build(
        "Office Move",
        monday,
        &[("Facilities team", "Operations", 35.0), ("IT support", "IT", 45.0), ("Movers", "Vendor", 60.0)],
        &[
            (1, "Preparation", 0.0, "", "", 0.0),
            (2, "Choose new premises", 10.0, "", "Facilities team", 0.0),
            (2, "Sign lease", 0.0, "2", "", 0.0),
            (2, "Plan seating layout", 3.0, "3", "Facilities team", 0.0),
            (1, "Moving", 0.0, "", "", 0.0),
            (2, "Book movers", 1.0, "3", "Facilities team", 0.0),
            (2, "Install network", 4.0, "3", "IT support", 0.0),
            (2, "Pack offices", 3.0, "6", "Movers", 0.0),
            (2, "Move furniture and equipment", 2.0, "8,7", "Movers", 0.0),
            (2, "Set up desks and computers", 2.0, "9", "IT support", 0.0),
            (2, "First day in new office", 0.0, "10", "", 0.0),
        ],
    )
}

pub fn product_release(monday: NaiveDate) -> Project {
    build(
        "Product Release",
        monday,
        &[("Product lead", "Product", 60.0), ("Engineers", "Engineering", 55.0), ("QA", "Quality", 42.0), ("Marketing", "Marketing", 45.0)],
        &[
            (1, "Discovery", 0.0, "", "", 0.0),
            (2, "Customer interviews", 5.0, "", "Product lead", 0.0),
            (2, "Write product brief", 3.0, "2", "Product lead", 0.0),
            (1, "Development", 0.0, "", "", 0.0),
            (2, "Architecture", 4.0, "3", "Engineers", 0.0),
            (2, "Build features", 15.0, "5", "Engineers", 0.0),
            (2, "Beta testing", 6.0, "6", "QA", 0.0),
            (1, "Go to market", 0.0, "", "", 0.0),
            (2, "Pricing and packaging", 4.0, "3", "Product lead,Marketing", 0.0),
            (2, "Launch campaign", 8.0, "9,6SS+5d", "Marketing", 0.0),
            (2, "Release", 0.0, "7,10", "", 0.0),
        ],
    )
}

pub fn event_planning(monday: NaiveDate) -> Project {
    build(
        "Event Planning",
        monday,
        &[("Organizer", "Events", 40.0), ("Designer", "Design", 45.0), ("Catering", "Vendor", 30.0)],
        &[
            (1, "Set up", 0.0, "", "", 0.0),
            (2, "Set budget and goals", 2.0, "", "Organizer", 0.0),
            (2, "Book venue", 3.0, "2", "Organizer", 0.0),
            (2, "Invite speakers", 10.0, "3", "Organizer", 0.0),
            (1, "Promotion", 0.0, "", "", 0.0),
            (2, "Design posters and site", 5.0, "3", "Designer", 0.0),
            (2, "Open registration", 0.0, "6", "", 0.0),
            (1, "Event", 0.0, "", "", 0.0),
            (2, "Arrange catering", 2.0, "3", "Catering", 0.0),
            (2, "Event day", 1.0, "4,7,9", "Organizer,Catering", 0.0),
            (2, "Send thank-you notes", 1.0, "10", "Organizer", 0.0),
        ],
    )
}
