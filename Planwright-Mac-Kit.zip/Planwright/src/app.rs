//! Main window: ribbon, view bar, status bar, commands, undo/redo, files.

use crate::dialogs::*;
use crate::model::*;
use crate::samples;
use crate::schedule;
use chrono::{Datelike, Duration, Local, NaiveDate, NaiveDateTime};
use eframe::egui::{self, Color32, RichText, Vec2};
use std::path::PathBuf;

pub const ACCENT: Color32 = Color32::from_rgb(0x2E, 0x6B, 0x3A);
pub const ACCENT_LIGHT: Color32 = Color32::from_rgb(0xE3, 0xEF, 0xE4);
pub const RIBBON_BG: Color32 = Color32::from_rgb(0xF5, 0xF6, 0xF7);
pub const GRID_LINE: Color32 = Color32::from_rgb(0xD9, 0xDC, 0xE0);
pub const HEADER_BG: Color32 = Color32::from_rgb(0xEE, 0xF0, 0xF2);
pub const SELECT_BG: Color32 = Color32::from_rgb(0xCF, 0xE3, 0xF7);

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum View {
    Gantt,
    Tracking,
    TaskSheet,
    ResourceSheet,
    Calendar,
    Network,
    TeamPlanner,
}

impl View {
    pub const ALL: [View; 7] = [
        View::Gantt,
        View::Tracking,
        View::TaskSheet,
        View::Calendar,
        View::Network,
        View::ResourceSheet,
        View::TeamPlanner,
    ];
    pub fn label(self) -> &'static str {
        match self {
            View::Gantt => "Gantt Chart",
            View::Tracking => "Tracking Gantt",
            View::TaskSheet => "Task Sheet",
            View::ResourceSheet => "Resource Sheet",
            View::Calendar => "Calendar",
            View::Network => "Network Diagram",
            View::TeamPlanner => "Team Planner",
        }
    }
    pub fn icon(self) -> &'static str {
        match self {
            View::Gantt => "📊",
            View::Tracking => "📈",
            View::TaskSheet => "🗒",
            View::ResourceSheet => "👥",
            View::Calendar => "📅",
            View::Network => "🔀",
            View::TeamPlanner => "👤",
        }
    }
    pub fn is_task_view(self) -> bool {
        matches!(self, View::Gantt | View::Tracking | View::TaskSheet | View::Calendar | View::Network)
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Tab {
    Task,
    Resource,
    Project,
    View,
    Format,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Filter {
    All,
    Critical,
    Incomplete,
    Completed,
    Milestones,
    Summary,
    Late,
}

impl Filter {
    pub const ALL: [Filter; 7] = [
        Filter::All,
        Filter::Critical,
        Filter::Incomplete,
        Filter::Completed,
        Filter::Milestones,
        Filter::Summary,
        Filter::Late,
    ];
    pub fn label(self) -> &'static str {
        match self {
            Filter::All => "All Tasks",
            Filter::Critical => "Critical",
            Filter::Incomplete => "Incomplete Tasks",
            Filter::Completed => "Completed Tasks",
            Filter::Milestones => "Milestones",
            Filter::Summary => "Summary Tasks",
            Filter::Late => "Late Tasks",
        }
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum SortBy {
    Id,
    Start,
    Finish,
    Name,
    Duration,
}

#[derive(Clone, Debug)]
pub struct CellEdit {
    pub uid: Option<u32>, // None = the blank row below the last task
    pub col: crate::grid::Col,
    pub buf: String,
    pub focus: bool,
}

#[derive(Clone, Debug)]
pub struct ResEdit {
    pub uid: Option<u32>,
    pub col: usize,
    pub buf: String,
    pub focus: bool,
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub enum DragMode {
    Move,
    Resize,
    Link,
}

#[derive(Clone, Debug)]
pub struct BarDrag {
    pub uid: u32,
    pub mode: DragMode,
    pub origin: egui::Pos2,
    pub start: NaiveDateTime,
    pub dur: i64,
    pub moved: bool,
}

pub struct PlanApp {
    pub p: Project,
    pub file: Option<PathBuf>,
    pub dirty: bool,
    pub undo: Vec<Project>,
    pub redo: Vec<Project>,
    pub clipboard: Vec<Task>,
    pub sel: Vec<u32>,
    pub anchor: Option<u32>,
    pub sel_res: Option<u32>,
    pub view: View,
    pub tab: Tab,
    pub backstage: bool,
    pub edit: Option<CellEdit>,
    pub res_edit: Option<ResEdit>,
    pub px_per_day: f32,
    pub gantt_x: f32,
    pub table_w: f32,
    pub show_timeline: bool,
    pub show_critical: bool,
    pub show_slack: bool,
    pub show_baseline: bool,
    pub show_project_summary: bool,
    pub show_late: bool,
    pub show_view_bar: bool,
    pub show_outline_numbers: bool,
    pub filter: Filter,
    pub sort: SortBy,
    pub outline_limit: Option<u32>,
    pub bar_color: Color32,
    pub status: String,
    pub dlg: Dialogs,
    pub cal_month: NaiveDate,
    pub drag: Option<BarDrag>,
    pub scroll_to_row: Option<usize>,
    pub screenshot: Option<PathBuf>,
    pub frame: u32,
    pub shot_sent: bool,
    pub shot: std::sync::Arc<std::sync::Mutex<Option<std::sync::Arc<egui::ColorImage>>>>,
    pub circular: Option<(usize, usize)>,
    /// One slot per open project tab; the active tab's slot is None (its project is in the fields above).
    pub tabs: Vec<Option<crate::tabs::DocState>>,
    pub active_tab: usize,
    pub allow_quit: bool,
    pub last_title: String,
}

pub fn monday_of(d: NaiveDate) -> NaiveDate {
    d - Duration::days(d.weekday().num_days_from_monday() as i64)
}

impl PlanApp {
    pub fn new(cc: &eframe::CreationContext<'_>, screenshot: Option<PathBuf>) -> Self {
        let mut style = (*cc.egui_ctx.global_style()).clone();
        style.visuals = egui::Visuals::light();
        style.visuals.selection.bg_fill = SELECT_BG;
        style.visuals.selection.stroke.color = Color32::from_rgb(0x1F, 0x5F, 0xAF);
        style.visuals.panel_fill = Color32::WHITE;
        style.visuals.window_fill = Color32::WHITE;
        style.spacing.item_spacing = Vec2::new(6.0, 4.0);
        style.spacing.button_padding = Vec2::new(6.0, 3.0);
        cc.egui_ctx.set_global_style(style);

        let today = Local::now().naive_local().date();
        let mut p = samples::website_launch(monday_of(today) - Duration::days(7));
        schedule::schedule(&mut p);
        let first = p.tasks.get(2).map(|t| t.uid);
        PlanApp {
            p,
            file: None,
            dirty: false,
            undo: vec![],
            redo: vec![],
            clipboard: vec![],
            sel: first.into_iter().collect(),
            anchor: first,
            sel_res: None,
            view: View::Gantt,
            tab: Tab::Task,
            backstage: false,
            edit: None,
            res_edit: None,
            px_per_day: 24.0,
            gantt_x: 0.0,
            table_w: 600.0,
            show_timeline: true,
            show_critical: false,
            show_slack: false,
            show_baseline: false,
            show_project_summary: false,
            show_late: false,
            show_view_bar: true,
            show_outline_numbers: false,
            filter: Filter::All,
            sort: SortBy::Id,
            outline_limit: None,
            bar_color: Color32::from_rgb(0x5B, 0x8F, 0xD6),
            status: "Ready".into(),
            dlg: Dialogs::default(),
            cal_month: NaiveDate::from_ymd_opt(today.year(), today.month(), 1).unwrap(),
            drag: None,
            scroll_to_row: None,
            screenshot,
            frame: 0,
            shot_sent: false,
            shot: Default::default(),
            circular: None,
            tabs: vec![None],
            active_tab: 0,
            allow_quit: false,
            last_title: String::new(),
        }
    }

    // ---------------- core helpers ----------------

    pub fn checkpoint(&mut self) {
        self.undo.push(self.p.clone());
        if self.undo.len() > 100 {
            self.undo.remove(0);
        }
        self.redo.clear();
        self.dirty = true;
    }

    pub fn recalc(&mut self) {
        let r = schedule::schedule(&mut self.p);
        if let Some((a, b)) = r.circular {
            if self.circular != Some((a, b)) {
                self.dlg.message = Some((
                    "Circular relationship".into(),
                    format!(
                        "Tasks {a} and {b} depend on each other in a loop, so dates can't be calculated.\n\nRemove one of the links between them to continue."
                    ),
                ));
            }
        }
        self.circular = r.circular;
    }

    pub fn undo(&mut self) {
        if let Some(prev) = self.undo.pop() {
            self.redo.push(std::mem::replace(&mut self.p, prev));
            self.recalc();
            self.status = "Undo".into();
        }
    }

    pub fn redo(&mut self) {
        if let Some(next) = self.redo.pop() {
            self.undo.push(std::mem::replace(&mut self.p, next));
            self.recalc();
            self.status = "Redo".into();
        }
    }

    pub fn selected_indices(&self) -> Vec<usize> {
        let mut v: Vec<usize> = self.sel.iter().filter_map(|u| self.p.index_of(*u)).collect();
        v.sort();
        v.dedup();
        v
    }

    pub fn subtree_end(&self, i: usize) -> usize {
        let lvl = self.p.tasks[i].level;
        let mut j = i + 1;
        while j < self.p.tasks.len() && self.p.tasks[j].level > lvl {
            j += 1;
        }
        j
    }

    pub fn today() -> NaiveDateTime {
        Local::now().naive_local()
    }

    pub fn today_start(p: &Project) -> NaiveDateTime {
        p.calendar.day_start(Local::now().naive_local().date())
    }

    pub fn new_task_at(&mut self, index: usize, name: &str, dur: i64, estimated: bool) -> u32 {
        let uid = self.p.alloc_uid();
        let level = if index < self.p.tasks.len() {
            self.p.tasks[index].level
        } else if index > 0 {
            let prev = &self.p.tasks[index - 1];
            if prev.calc.summary { prev.level + 1 } else { prev.level }
        } else {
            1
        };
        let start = self.p.calendar.next_work_start(self.p.start);
        let mut t = Task::new(uid, name, start, dur);
        t.level = level;
        t.estimated = estimated;
        t.manual = self.p.new_tasks_manual;
        self.p.tasks.insert(index.min(self.p.tasks.len()), t);
        uid
    }

    // ---------------- commands ----------------

    pub fn insert_task(&mut self) {
        self.checkpoint();
        let at = self.selected_indices().first().copied().unwrap_or(self.p.tasks.len());
        let uid = self.new_task_at(at, "New Task", self.p.default_task_minutes(), true);
        self.sel = vec![uid];
        self.anchor = Some(uid);
        self.recalc();
        self.edit = Some(CellEdit { uid: Some(uid), col: crate::grid::Col::Name, buf: "New Task".into(), focus: true });
    }

    pub fn insert_milestone(&mut self) {
        self.checkpoint();
        let at = self.selected_indices().first().copied().unwrap_or(self.p.tasks.len());
        let uid = self.new_task_at(at, "New Milestone", 0, false);
        self.sel = vec![uid];
        self.recalc();
    }

    pub fn insert_summary(&mut self) {
        let idx = self.selected_indices();
        self.checkpoint();
        if idx.is_empty() {
            let uid = self.new_task_at(self.p.tasks.len(), "New Summary Task", self.p.default_task_minutes(), true);
            self.sel = vec![uid];
        } else {
            let first = idx[0];
            let last_end = self.subtree_end(*idx.last().unwrap());
            let lvl = self.p.tasks[first].level;
            for j in first..last_end {
                self.p.tasks[j].level += 1;
            }
            let uid = self.p.alloc_uid();
            let mut t = Task::new(uid, "New Summary Task", self.p.start, 0);
            t.level = lvl;
            self.p.tasks.insert(first, t);
            self.sel = vec![uid];
        }
        self.recalc();
    }

    pub fn delete_selected(&mut self) {
        let idx = self.selected_indices();
        if idx.is_empty() {
            return;
        }
        self.checkpoint();
        let mut remove = vec![false; self.p.tasks.len()];
        for &i in &idx {
            for j in i..self.subtree_end(i) {
                remove[j] = true;
            }
        }
        let gone: Vec<u32> = self
            .p
            .tasks
            .iter()
            .enumerate()
            .filter(|(i, _)| remove[*i])
            .map(|(_, t)| t.uid)
            .collect();
        let mut k = 0;
        self.p.tasks.retain(|_| {
            let keep = !remove[k];
            k += 1;
            keep
        });
        for t in self.p.tasks.iter_mut() {
            t.links.retain(|l| !gone.contains(&l.pred));
        }
        let next = idx[0].min(self.p.tasks.len().saturating_sub(1));
        self.sel = self.p.tasks.get(next).map(|t| vec![t.uid]).unwrap_or_default();
        self.recalc();
        self.status = format!("Deleted {} task(s)", gone.len());
    }

    pub fn indent(&mut self) {
        let idx = self.selected_indices();
        if idx.is_empty() {
            return;
        }
        self.checkpoint();
        let mut done_until = 0;
        for &i in &idx {
            if i < done_until || i == 0 {
                continue;
            }
            if self.p.tasks[i - 1].level < self.p.tasks[i].level {
                continue;
            }
            let end = self.subtree_end(i);
            for j in i..end {
                self.p.tasks[j].level += 1;
            }
            done_until = end;
        }
        self.recalc();
    }

    pub fn outdent(&mut self) {
        let idx = self.selected_indices();
        if idx.is_empty() {
            return;
        }
        self.checkpoint();
        let mut done_until = 0;
        for &i in &idx {
            if i < done_until || self.p.tasks[i].level <= 1 {
                continue;
            }
            let end = self.subtree_end(i);
            for j in i..end {
                self.p.tasks[j].level -= 1;
            }
            done_until = end;
        }
        self.recalc();
    }

    pub fn link_selected(&mut self) {
        let idx = self.selected_indices();
        if idx.len() < 2 {
            self.status = "Select two or more tasks to link them".into();
            return;
        }
        self.checkpoint();
        for w in idx.windows(2) {
            let pred = self.p.tasks[w[0]].uid;
            let t = &mut self.p.tasks[w[1]];
            if !t.links.iter().any(|l| l.pred == pred) {
                t.links.push(Link { pred, kind: LinkKind::FS, lag: 0 });
            }
        }
        self.recalc();
    }

    pub fn add_link(&mut self, pred: u32, succ: u32) {
        if pred == succ {
            return;
        }
        self.checkpoint();
        if let Some(si) = self.p.index_of(succ) {
            let t = &mut self.p.tasks[si];
            if !t.links.iter().any(|l| l.pred == pred) {
                t.links.push(Link { pred, kind: LinkKind::FS, lag: 0 });
            }
        }
        self.recalc();
    }

    pub fn unlink_selected(&mut self) {
        let idx = self.selected_indices();
        if idx.is_empty() {
            return;
        }
        self.checkpoint();
        let uids: Vec<u32> = idx.iter().map(|&i| self.p.tasks[i].uid).collect();
        if uids.len() == 1 {
            let u = uids[0];
            for t in self.p.tasks.iter_mut() {
                if t.uid == u {
                    t.links.clear();
                } else {
                    t.links.retain(|l| l.pred != u);
                }
            }
        } else {
            for t in self.p.tasks.iter_mut() {
                if uids.contains(&t.uid) {
                    t.links.retain(|l| !uids.contains(&l.pred));
                }
            }
        }
        self.recalc();
    }

    pub fn set_percent(&mut self, pct: f64) {
        let idx = self.selected_indices();
        if idx.is_empty() {
            return;
        }
        self.checkpoint();
        for i in idx {
            if self.p.tasks[i].calc.summary {
                schedule::set_summary_percent(&mut self.p, i, pct);
            } else {
                self.p.tasks[i].percent = pct;
            }
        }
        self.recalc();
    }

    pub fn mark_on_track(&mut self) {
        let idx = self.selected_indices();
        if idx.is_empty() {
            return;
        }
        self.checkpoint();
        let status = self.p.status_date.map(|d| self.p.calendar.day_finish(d)).unwrap_or_else(Self::today);
        for i in idx {
            let t = &self.p.tasks[i];
            if t.calc.summary {
                continue;
            }
            let pct = if status <= t.start {
                0.0
            } else if status >= t.finish || t.dur == 0 {
                100.0
            } else {
                (self.p.calendar.work_between(t.start, status) as f64 / t.dur as f64 * 100.0).round()
            };
            self.p.tasks[i].percent = pct;
        }
        self.recalc();
    }

    pub fn set_manual(&mut self, manual: bool) {
        let idx = self.selected_indices();
        if idx.is_empty() {
            self.p.new_tasks_manual = manual;
            return;
        }
        self.checkpoint();
        for i in idx {
            if !self.p.tasks[i].calc.summary {
                self.p.tasks[i].manual = manual;
            }
        }
        self.recalc();
    }

    pub fn toggle_timeline_for_selected(&mut self) {
        let idx = self.selected_indices();
        if idx.is_empty() {
            return;
        }
        self.checkpoint();
        let on = !self.p.tasks[idx[0]].on_timeline;
        for i in idx {
            self.p.tasks[i].on_timeline = on;
        }
        self.show_timeline = true;
    }

    pub fn set_baseline(&mut self, only_selected: bool) {
        self.checkpoint();
        let idx: Vec<usize> = if only_selected { self.selected_indices() } else { (0..self.p.tasks.len()).collect() };
        for i in idx {
            let t = &mut self.p.tasks[i];
            t.baseline = Some(Baseline { start: t.start, finish: t.finish, dur: t.dur, work: t.calc.work_min, cost: t.calc.cost });
        }
        self.show_baseline = true;
        self.status = "Baseline saved".into();
    }

    pub fn clear_baseline(&mut self, only_selected: bool) {
        self.checkpoint();
        let idx: Vec<usize> = if only_selected { self.selected_indices() } else { (0..self.p.tasks.len()).collect() };
        for i in idx {
            self.p.tasks[i].baseline = None;
        }
        self.status = "Baseline cleared".into();
    }

    pub fn copy(&mut self, cut: bool) {
        let idx = self.selected_indices();
        if idx.is_empty() {
            return;
        }
        let mut out = vec![];
        let mut taken = vec![false; self.p.tasks.len()];
        for &i in &idx {
            for j in i..self.subtree_end(i) {
                if !taken[j] {
                    taken[j] = true;
                    out.push(self.p.tasks[j].clone());
                }
            }
        }
        let min_level = out.iter().map(|t| t.level).min().unwrap_or(1);
        for t in out.iter_mut() {
            t.level = t.level - min_level + 1;
        }
        self.clipboard = out;
        self.status = format!("Copied {} task(s)", self.clipboard.len());
        if cut {
            self.delete_selected();
        }
    }

    pub fn paste(&mut self) {
        if self.clipboard.is_empty() {
            return;
        }
        self.checkpoint();
        let at = self.selected_indices().first().copied().unwrap_or(self.p.tasks.len());
        let base_level = if at < self.p.tasks.len() { self.p.tasks[at].level } else { 1 };
        let mut map = std::collections::HashMap::new();
        let mut items = self.clipboard.clone();
        for t in items.iter_mut() {
            let nu = self.p.alloc_uid();
            map.insert(t.uid, nu);
            t.uid = nu;
            t.level += base_level - 1;
        }
        for t in items.iter_mut() {
            t.links = t
                .links
                .iter()
                .filter_map(|l| map.get(&l.pred).map(|&p| Link { pred: p, ..l.clone() }))
                .collect();
        }
        self.sel = items.iter().map(|t| t.uid).collect();
        for (k, t) in items.into_iter().enumerate() {
            self.p.tasks.insert(at + k, t);
        }
        self.recalc();
    }

    pub fn level_all(&mut self) {
        self.checkpoint();
        let n = schedule::level_resources(&mut self.p);
        self.recalc();
        self.status = if n == 0 { "No over-allocations to level".into() } else { format!("Leveling moved tasks {n} time(s)") };
    }

    pub fn clear_leveling(&mut self) {
        self.checkpoint();
        for t in self.p.tasks.iter_mut() {
            t.level_delay = 0;
        }
        self.recalc();
        self.status = "Leveling cleared".into();
    }

    pub fn scroll_to_selected(&mut self) {
        if let Some(i) = self.selected_indices().first() {
            let t0 = crate::grid::chart_origin(self);
            let days = (self.p.tasks[*i].start - t0).num_minutes() as f32 / 1440.0;
            self.gantt_x = (days * self.px_per_day - 40.0).max(0.0);
            self.scroll_to_row = Some(*i);
        }
    }

    pub fn zoom_entire_project(&mut self, width: f32) {
        let span = (self.p.finish() - self.p.first_start()).num_days().max(7) as f32 + 14.0;
        self.px_per_day = (width / span).clamp(2.0, 80.0);
        self.gantt_x = 0.0;
    }

    pub fn visible_rows(&self) -> Vec<usize> {
        let mut rows: Vec<usize> = (0..self.p.tasks.len())
            .filter(|&i| {
                let t = &self.p.tasks[i];
                if !t.calc.visible && self.filter == Filter::All {
                    return false;
                }
                if let Some(l) = self.outline_limit {
                    if t.level > l {
                        return false;
                    }
                }
                match self.filter {
                    Filter::All => true,
                    Filter::Critical => t.calc.critical,
                    Filter::Incomplete => !t.complete(),
                    Filter::Completed => t.complete(),
                    Filter::Milestones => t.is_milestone(),
                    Filter::Summary => t.calc.summary,
                    Filter::Late => t.calc.late,
                }
            })
            .collect();
        match self.sort {
            SortBy::Id => {}
            SortBy::Start => rows.sort_by_key(|&i| (self.p.tasks[i].start, i)),
            SortBy::Finish => rows.sort_by_key(|&i| (self.p.tasks[i].finish, i)),
            SortBy::Name => rows.sort_by_key(|&i| (self.p.tasks[i].name.to_lowercase(), i)),
            SortBy::Duration => rows.sort_by_key(|&i| (-self.p.tasks[i].dur, i)),
        }
        rows
    }

    // ---------------- files ----------------

    pub fn new_project(&mut self, p: Project) {
        self.p = p;
        self.file = None;
        self.dirty = false;
        self.undo.clear();
        self.redo.clear();
        self.recalc();
        self.sel = self.p.tasks.first().map(|t| vec![t.uid]).unwrap_or_default();
        self.gantt_x = 0.0;
        self.backstage = false;
    }

    /// Opens one or more files, each in its own tab (a file already open just gets switched to).
    pub fn open(&mut self) {
        let Some(paths) = rfd::FileDialog::new()
            .add_filter("Planwright project or MS Project XML", &["plan", "json", "xml"])
            .pick_files()
        else {
            return;
        };
        for path in paths {
            self.open_path(path);
        }
    }

    pub fn open_path(&mut self, path: PathBuf) {
        // already open? switch to it
        if let Some(i) = (0..self.tabs.len()).find(|&i| {
            if i == self.active_tab {
                self.file.as_ref() == Some(&path)
            } else {
                self.tabs[i].as_ref().and_then(|d| d.file.as_ref()) == Some(&path)
            }
        }) {
            self.switch_tab(i);
            return;
        }
        let is_xml = path.extension().map(|e| e.eq_ignore_ascii_case("xml")).unwrap_or(false);
        let res = if is_xml { crate::io::import_xml(&path) } else { crate::io::load_json(&path) };
        match res {
            Ok(p) => {
                self.open_project(p, if is_xml { None } else { Some(path.clone()) });
                self.status = format!("Opened {}", path.file_name().unwrap_or_default().to_string_lossy());
            }
            Err(e) => self.dlg.message = Some(("Couldn't open the file".into(), e)),
        }
    }

    /// Saves the active tab. Returns true when it was saved.
    pub fn save(&mut self, save_as: bool) -> bool {
        let path = if save_as || self.file.is_none() {
            let Some(p) = rfd::FileDialog::new()
                .add_filter("Planwright project", &["plan"])
                .set_file_name(format!("{}.plan", self.p.title))
                .save_file()
            else {
                return false;
            };
            p
        } else {
            self.file.clone().unwrap()
        };
        match crate::io::save_json(&self.p, &path) {
            Ok(()) => {
                self.file = Some(path.clone());
                self.dirty = false;
                self.status = format!("Saved {}", path.file_name().unwrap_or_default().to_string_lossy());
                self.backstage = false;
                true
            }
            Err(e) => {
                self.dlg.message = Some(("Couldn't save".into(), e));
                false
            }
        }
    }

    pub fn export_xml(&mut self) {
        let Some(path) = rfd::FileDialog::new()
            .add_filter("Microsoft Project XML", &["xml"])
            .set_file_name(format!("{}.xml", self.p.title))
            .save_file()
        else {
            return;
        };
        match crate::io::export_xml(&self.p, &path) {
            Ok(()) => self.status = "Exported as Microsoft Project XML".into(),
            Err(e) => self.dlg.message = Some(("Export failed".into(), e)),
        }
        self.backstage = false;
    }

    pub fn export_csv(&mut self) {
        let Some(path) = rfd::FileDialog::new()
            .add_filter("CSV (Excel)", &["csv"])
            .set_file_name(format!("{}.csv", self.p.title))
            .save_file()
        else {
            return;
        };
        match crate::io::export_csv(&self.p, &path) {
            Ok(()) => self.status = "Exported the task table as CSV".into(),
            Err(e) => self.dlg.message = Some(("Export failed".into(), e)),
        }
        self.backstage = false;
    }

    // ---------------- UI pieces ----------------

    fn keyboard(&mut self, ctx: &egui::Context) {
        if ctx.egui_wants_keyboard_input() {
            return;
        }
        let (cmd, shift, alt) = ctx.input(|i| (i.modifiers.command, i.modifiers.shift, i.modifiers.alt));
        let pressed = |k: egui::Key| ctx.input(|i| i.key_pressed(k));
        if cmd && pressed(egui::Key::Z) {
            if shift {
                self.redo()
            } else {
                self.undo()
            }
        } else if cmd && pressed(egui::Key::Y) {
            self.redo();
        } else if cmd && pressed(egui::Key::S) {
            self.save(shift);
        } else if cmd && pressed(egui::Key::O) {
            self.open();
        } else if cmd && pressed(egui::Key::N) {
            self.new_blank_tab();
        } else if cmd && pressed(egui::Key::F) {
            self.dlg.find = Some(String::new());
        } else if cmd && pressed(egui::Key::C) {
            self.copy(false);
        } else if cmd && pressed(egui::Key::X) {
            self.copy(true);
        } else if cmd && pressed(egui::Key::V) {
            self.paste();
        } else if alt && shift && pressed(egui::Key::ArrowRight) {
            self.indent();
        } else if alt && shift && pressed(egui::Key::ArrowLeft) {
            self.outdent();
        } else if self.view.is_task_view() {
            if pressed(egui::Key::Delete) || (pressed(egui::Key::Backspace) && cmd) {
                self.delete_selected();
            } else if pressed(egui::Key::Insert) {
                self.insert_task();
            } else if pressed(egui::Key::F2) {
                if let Some(i) = self.selected_indices().first() {
                    let t = &self.p.tasks[*i];
                    self.edit = Some(CellEdit { uid: Some(t.uid), col: crate::grid::Col::Name, buf: t.name.clone(), focus: true });
                }
            } else if pressed(egui::Key::ArrowDown) || pressed(egui::Key::ArrowUp) {
                let down = pressed(egui::Key::ArrowDown);
                let rows = self.visible_rows();
                let cur = self.selected_indices().first().and_then(|i| rows.iter().position(|r| r == i));
                let next = match cur {
                    None => 0,
                    Some(c) if down => (c + 1).min(rows.len().saturating_sub(1)),
                    Some(c) => c.saturating_sub(1),
                };
                if let Some(&r) = rows.get(next) {
                    self.sel = vec![self.p.tasks[r].uid];
                    self.anchor = Some(self.p.tasks[r].uid);
                    self.scroll_to_row = Some(r);
                }
            }
        }
    }

    fn tab_bar(&mut self, ui: &mut egui::Ui) {
        ui.horizontal(|ui| {
            ui.spacing_mut().item_spacing.x = 2.0;
            let file_btn = egui::Button::new(RichText::new("  File  ").color(Color32::WHITE).strong())
                .fill(ACCENT)
                .corner_radius(2.0);
            if ui.add(file_btn).clicked() {
                self.backstage = !self.backstage;
            }
            for (t, name) in [
                (Tab::Task, "Task"),
                (Tab::Resource, "Resource"),
                (Tab::Project, "Project"),
                (Tab::View, "View"),
                (Tab::Format, "Format"),
            ] {
                let active = self.tab == t && !self.backstage;
                let txt = if active {
                    RichText::new(format!("  {name}  ")).color(ACCENT).strong()
                } else {
                    RichText::new(format!("  {name}  ")).color(Color32::from_gray(60))
                };
                let b = egui::Button::new(txt)
                    .fill(if active { Color32::WHITE } else { RIBBON_BG })
                    .stroke(if active { egui::Stroke::new(1.0, GRID_LINE) } else { egui::Stroke::NONE });
                if ui.add(b).clicked() {
                    self.tab = t;
                    self.backstage = false;
                }
            }
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                let name = self
                    .file
                    .as_ref()
                    .and_then(|f| f.file_name())
                    .map(|n| n.to_string_lossy().to_string())
                    .unwrap_or_else(|| self.p.title.clone());
                ui.label(RichText::new(format!("{}{}", name, if self.dirty { " •" } else { "" })).color(Color32::from_gray(90)));
                if ui.add_enabled(!self.redo.is_empty(), egui::Button::new("↪").frame(false)).on_hover_text("Redo").clicked() {
                    self.redo();
                }
                if ui.add_enabled(!self.undo.is_empty(), egui::Button::new("↩").frame(false)).on_hover_text("Undo").clicked() {
                    self.undo();
                }
                if ui.add(egui::Button::new("💾").frame(false)).on_hover_text("Save").clicked() {
                    self.save(false);
                }
            });
        });
    }

    fn ribbon(&mut self, ui: &mut egui::Ui) {
        ui.horizontal(|ui| {
            ui.set_min_height(74.0);
            match self.tab {
                Tab::Task => self.ribbon_task(ui),
                Tab::Resource => self.ribbon_resource(ui),
                Tab::Project => self.ribbon_project(ui),
                Tab::View => self.ribbon_view(ui),
                Tab::Format => self.ribbon_format(ui),
            }
        });
    }

    fn ribbon_task(&mut self, ui: &mut egui::Ui) {
        group(ui, "View", |ui| {
            if big(ui, "📊", "Gantt\nChart").clicked() {
                self.view = View::Gantt;
            }
        });
        group(ui, "Clipboard", |ui| {
            if big(ui, "📋", "Paste").clicked() {
                self.paste();
            }
            ui.vertical(|ui| {
                if small(ui, "✂", "Cut").clicked() {
                    self.copy(true);
                }
                if small(ui, "📑", "Copy").clicked() {
                    self.copy(false);
                }
            });
        });
        group(ui, "Schedule", |ui| {
            ui.vertical(|ui| {
                ui.horizontal(|ui| {
                    for p in [0.0, 25.0, 50.0, 75.0, 100.0] {
                        if pct_button(ui, p).on_hover_text(format!("Mark {}% complete", p)).clicked() {
                            self.set_percent(p);
                        }
                    }
                });
                ui.horizontal(|ui| {
                    if small(ui, "✔", "Mark on Track").clicked() {
                        self.mark_on_track();
                    }
                });
                ui.horizontal(|ui| {
                    if small(ui, "🔗", "Link").on_hover_text("Link the selected tasks Finish-to-Start").clicked() {
                        self.link_selected();
                    }
                    if small(ui, "⛓", "Unlink").clicked() {
                        self.unlink_selected();
                    }
                });
            });
            ui.vertical(|ui| {
                if small(ui, "➡", "Indent").on_hover_text("Indent task (Alt+Shift+Right)").clicked() {
                    self.indent();
                }
                if small(ui, "⬅", "Outdent").on_hover_text("Outdent task (Alt+Shift+Left)").clicked() {
                    self.outdent();
                }
            });
        });
        group(ui, "Tasks", |ui| {
            if big(ui, "📌", "Manually\nSchedule").clicked() {
                self.set_manual(true);
            }
            if big(ui, "⚙", "Auto\nSchedule").clicked() {
                self.set_manual(false);
            }
        });
        group(ui, "Insert", |ui| {
            if big(ui, "➕", "Task").clicked() {
                self.insert_task();
            }
            ui.vertical(|ui| {
                if small(ui, "◆", "Milestone").clicked() {
                    self.insert_milestone();
                }
                if small(ui, "▤", "Summary").clicked() {
                    self.insert_summary();
                }
                if small(ui, "⏳", "Deliverable").on_hover_text("Insert a task with a deadline one week out").clicked() {
                    self.insert_task();
                    self.edit = None;
                    if let Some(i) = self.selected_indices().first().copied() {
                        let d = self.p.tasks[i].finish.date() + Duration::days(7);
                        self.p.tasks[i].deadline = Some(d);
                        self.p.tasks[i].name = "New Deliverable".into();
                        self.recalc();
                    }
                }
            });
        });
        group(ui, "Properties", |ui| {
            if big(ui, "ℹ", "Information").clicked() {
                self.open_task_info(0);
            }
            ui.vertical(|ui| {
                if small(ui, "🗒", "Notes").clicked() {
                    self.open_task_info(4);
                }
                if small(ui, "⏱", "Add to Timeline").clicked() {
                    self.toggle_timeline_for_selected();
                }
            });
        });
        group(ui, "Editing", |ui| {
            ui.vertical(|ui| {
                if small(ui, "🔍", "Find").clicked() {
                    self.dlg.find = Some(String::new());
                }
                if small(ui, "🎯", "Scroll to Task").clicked() {
                    self.scroll_to_selected();
                }
            });
        });
    }

    fn ribbon_resource(&mut self, ui: &mut egui::Ui) {
        group(ui, "View", |ui| {
            if big(ui, "👤", "Team\nPlanner").clicked() {
                self.view = View::TeamPlanner;
            }
            if big(ui, "👥", "Resource\nSheet").clicked() {
                self.view = View::ResourceSheet;
            }
        });
        group(ui, "Assignments", |ui| {
            if big(ui, "👪", "Assign\nResources").clicked() {
                self.dlg.assign = true;
            }
        });
        group(ui, "Insert", |ui| {
            if big(ui, "➕", "Add\nResource").clicked() {
                self.checkpoint();
                let uid = self.p.alloc_res_uid();
                let n = self.p.resources.len() + 1;
                self.p.resources.push(Resource::new(uid, &format!("Resource {n}")));
                self.sel_res = Some(uid);
                self.view = View::ResourceSheet;
                self.recalc();
            }
        });
        group(ui, "Properties", |ui| {
            if big(ui, "ℹ", "Information").clicked() {
                if let Some(u) = self.sel_res.or(self.p.resources.first().map(|r| r.uid)) {
                    self.dlg.resource = self.p.resources.iter().find(|r| r.uid == u).cloned();
                }
            }
        });
        group(ui, "Level", |ui| {
            if big(ui, "⚖", "Level\nAll").on_hover_text("Delay tasks so nobody is booked over their Max Units").clicked() {
                self.level_all();
            }
            if big(ui, "↺", "Clear\nLeveling").clicked() {
                self.clear_leveling();
            }
        });
    }

    fn ribbon_project(&mut self, ui: &mut egui::Ui) {
        group(ui, "Properties", |ui| {
            if big(ui, "🗂", "Project\nInformation").clicked() {
                self.dlg.project = Some(ProjectDraft::from(&self.p));
            }
            if big(ui, "📆", "Change\nWorking Time").clicked() {
                self.dlg.working = Some(WorkingDraft::from(&self.p));
            }
            if big(ui, "📈", "Statistics").clicked() {
                self.dlg.stats = true;
            }
        });
        group(ui, "Status", |ui| {
            ui.vertical(|ui| {
                ui.label("Status Date:");
                let id = ui.scope_id().with("status_date");
                let mut txt = ui
                    .data_mut(|d| d.get_temp::<String>(id))
                    .unwrap_or_else(|| self.p.status_date.map(|d| d.format("%m/%d/%y").to_string()).unwrap_or("NA".into()));
                let r = ui.add(egui::TextEdit::singleline(&mut txt).desired_width(80.0));
                if r.changed() {
                    ui.data_mut(|d| d.insert_temp(id, txt.clone()));
                }
                if r.lost_focus() {
                    ui.data_mut(|d| d.remove::<String>(id));
                    self.checkpoint();
                    self.p.status_date = parse_date(&txt);
                    self.recalc();
                }
            });
            if big(ui, "🔄", "Update\nProject").on_hover_text("Mark every task on track up to the status date").clicked() {
                let all: Vec<u32> = self.p.tasks.iter().map(|t| t.uid).collect();
                let keep = std::mem::replace(&mut self.sel, all);
                self.mark_on_track();
                self.sel = keep;
            }
        });
        group(ui, "Baseline", |ui| {
            if big(ui, "📏", "Set\nBaseline").clicked() {
                self.dlg.baseline = Some((true, false));
            }
            if big(ui, "🗑", "Clear\nBaseline").clicked() {
                self.dlg.baseline = Some((false, false));
            }
        });
        group(ui, "Export", |ui| {
            ui.vertical(|ui| {
                if small(ui, "📤", "MS Project XML").clicked() {
                    self.export_xml();
                }
                if small(ui, "📄", "Excel (CSV)").clicked() {
                    self.export_csv();
                }
            });
        });
        group(ui, "Options", |ui| {
            if big(ui, "⚙", "Options").clicked() {
                self.dlg.options = Some(OptionsDraft::from(&self.p));
            }
        });
    }

    fn ribbon_view(&mut self, ui: &mut egui::Ui) {
        group(ui, "Task Views", |ui| {
            for v in [View::Gantt, View::Tracking, View::TaskSheet, View::Calendar, View::Network] {
                if big_toggle(ui, v.icon(), &v.label().replace(' ', "\n"), self.view == v).clicked() {
                    self.view = v;
                }
            }
        });
        group(ui, "Resource Views", |ui| {
            for v in [View::TeamPlanner, View::ResourceSheet] {
                if big_toggle(ui, v.icon(), &v.label().replace(' ', "\n"), self.view == v).clicked() {
                    self.view = v;
                }
            }
        });
        group(ui, "Data", |ui| {
            ui.vertical(|ui| {
                ui.horizontal(|ui| {
                    ui.label("Filter: ");
                    egui::ComboBox::from_id_salt("filter").selected_text(self.filter.label()).width(130.0).show_ui(ui, |ui| {
                        for f in Filter::ALL {
                            ui.selectable_value(&mut self.filter, f, f.label());
                        }
                    });
                });
                ui.horizontal(|ui| {
                    ui.label("Sort:    ");
                    let label = match self.sort {
                        SortBy::Id => "by ID",
                        SortBy::Start => "by Start Date",
                        SortBy::Finish => "by Finish Date",
                        SortBy::Name => "by Name",
                        SortBy::Duration => "by Duration",
                    };
                    egui::ComboBox::from_id_salt("sort").selected_text(label).width(130.0).show_ui(ui, |ui| {
                        ui.selectable_value(&mut self.sort, SortBy::Id, "by ID");
                        ui.selectable_value(&mut self.sort, SortBy::Start, "by Start Date");
                        ui.selectable_value(&mut self.sort, SortBy::Finish, "by Finish Date");
                        ui.selectable_value(&mut self.sort, SortBy::Name, "by Name");
                        ui.selectable_value(&mut self.sort, SortBy::Duration, "by Duration");
                    });
                });
                ui.horizontal(|ui| {
                    ui.label("Outline:");
                    let label = match self.outline_limit {
                        None => "All Subtasks".to_string(),
                        Some(l) => format!("Level {l}"),
                    };
                    egui::ComboBox::from_id_salt("outline").selected_text(label).width(130.0).show_ui(ui, |ui| {
                        ui.selectable_value(&mut self.outline_limit, None, "All Subtasks");
                        for l in 1..=5 {
                            ui.selectable_value(&mut self.outline_limit, Some(l), format!("Level {l}"));
                        }
                    });
                });
            });
        });
        group(ui, "Zoom", |ui| {
            ui.vertical(|ui| {
                ui.horizontal(|ui| {
                    if small(ui, "➖", "").on_hover_text("Zoom out").clicked() {
                        self.px_per_day = (self.px_per_day / 1.5).max(2.0);
                    }
                    if small(ui, "➕", "").on_hover_text("Zoom in").clicked() {
                        self.px_per_day = (self.px_per_day * 1.5).min(120.0);
                    }
                });
                ui.horizontal(|ui| {
                    for (lbl, ppd) in [("Days", 40.0), ("Weeks", 18.0), ("Months", 5.0)] {
                        if ui.small_button(lbl).clicked() {
                            self.px_per_day = ppd;
                        }
                    }
                });
                if small(ui, "↔", "Entire Project").clicked() {
                    let w = ui.ctx().content_rect().width() - self.table_w - 120.0;
                    self.zoom_entire_project(w);
                }
            });
        });
        group(ui, "Split View", |ui| {
            ui.vertical(|ui| {
                ui.checkbox(&mut self.show_timeline, "Timeline");
                ui.checkbox(&mut self.show_view_bar, "View Bar");
            });
        });
    }

    fn ribbon_format(&mut self, ui: &mut egui::Ui) {
        group(ui, "Bar Styles", |ui| {
            ui.vertical(|ui| {
                ui.checkbox(&mut self.show_critical, "Critical Tasks");
                ui.checkbox(&mut self.show_slack, "Slack");
                ui.checkbox(&mut self.show_late, "Late Tasks");
            });
            ui.vertical(|ui| {
                ui.checkbox(&mut self.show_baseline, "Baseline");
                ui.checkbox(&mut self.show_project_summary, "Project Summary Task");
                ui.checkbox(&mut self.show_outline_numbers, "Outline Number");
            });
        });
        group(ui, "Gantt Chart Style", |ui| {
            for c in [
                Color32::from_rgb(0x5B, 0x8F, 0xD6),
                Color32::from_rgb(0x4C, 0xA5, 0x6E),
                Color32::from_rgb(0x8E, 0x6C, 0xC8),
                Color32::from_rgb(0xE0, 0x8E, 0x3A),
                Color32::from_rgb(0x3F, 0xA9, 0xB5),
                Color32::from_rgb(0x7A, 0x7F, 0x88),
            ] {
                let (r, resp) = ui.allocate_exact_size(Vec2::new(30.0, 44.0), egui::Sense::click());
                let bar = egui::Rect::from_center_size(r.center(), Vec2::new(24.0, 10.0));
                ui.painter().rect_filled(bar, 2.0, c);
                if self.bar_color == c {
                    ui.painter().rect_stroke(r.shrink(1.0), 3.0, egui::Stroke::new(1.5, ACCENT), egui::StrokeKind::Inside);
                }
                if resp.clicked() {
                    self.bar_color = c;
                }
            }
        });
        group(ui, "Critical Path", |ui| {
            if big_toggle(ui, "🔴", "Highlight\nCritical Path", self.show_critical).clicked() {
                self.show_critical = !self.show_critical;
            }
        });
    }

    fn view_bar(&mut self, ui: &mut egui::Ui) {
        ui.add_space(6.0);
        for v in View::ALL {
            let active = self.view == v;
            let (rect, resp) = ui.allocate_exact_size(Vec2::new(ui.available_width(), 58.0), egui::Sense::click());
            let painter = ui.painter();
            if active {
                painter.rect_filled(rect.shrink2(Vec2::new(4.0, 2.0)), 4.0, ACCENT_LIGHT);
                painter.rect_filled(egui::Rect::from_min_size(rect.min + Vec2::new(0.0, 6.0), Vec2::new(3.0, 46.0)), 1.0, ACCENT);
            } else if resp.hovered() {
                painter.rect_filled(rect.shrink2(Vec2::new(4.0, 2.0)), 4.0, Color32::from_gray(238));
            }
            painter.text(
                rect.center_top() + Vec2::new(0.0, 18.0),
                egui::Align2::CENTER_CENTER,
                v.icon(),
                egui::FontId::proportional(20.0),
                if active { ACCENT } else { Color32::from_gray(80) },
            );
            painter.text(
                rect.center_top() + Vec2::new(0.0, 43.0),
                egui::Align2::CENTER_CENTER,
                v.label(),
                egui::FontId::proportional(10.5),
                Color32::from_gray(50),
            );
            if resp.clicked() {
                self.view = v;
            }
        }
    }

    fn status_bar(&mut self, ui: &mut egui::Ui) {
        ui.horizontal(|ui| {
            ui.label(RichText::new(&self.status).color(Color32::from_gray(70)));
            ui.separator();
            let mode = if self.p.new_tasks_manual { "New Tasks: Manually Scheduled" } else { "New Tasks: Auto Scheduled" };
            if ui
                .add(egui::Label::new(RichText::new(mode).color(Color32::from_gray(70))).sense(egui::Sense::click()))
                .on_hover_text("Click to switch")
                .clicked()
            {
                self.p.new_tasks_manual = !self.p.new_tasks_manual;
            }
            if self.circular.is_some() {
                ui.separator();
                ui.label(RichText::new("⚠ Circular link - dates not updated").color(Color32::from_rgb(0xC0, 0, 0)));
            }
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                let mut z = self.px_per_day.ln();
                if ui.add(egui::Slider::new(&mut z, (2.0f32).ln()..=(120.0f32).ln()).show_value(false)).changed() {
                    self.px_per_day = z.exp();
                }
                ui.label("🔍");
                ui.separator();
                for v in [View::ResourceSheet, View::TaskSheet, View::Gantt] {
                    let b = egui::Button::new(v.icon()).frame(self.view == v);
                    if ui.add(b).on_hover_text(v.label()).clicked() {
                        self.view = v;
                    }
                }
                ui.separator();
                let n = self.p.tasks.len();
                ui.label(RichText::new(format!("{} tasks · finish {}", n, fmt_date(self.p.finish()))).color(Color32::from_gray(90)));
            });
        });
    }

    pub fn open_task_info(&mut self, tab: usize) {
        if let Some(i) = self.selected_indices().first() {
            let mut d = TaskDraft::from(&self.p, *i);
            d.tab = tab;
            self.dlg.task = Some(d);
        }
    }

    fn backstage_ui(&mut self, ui: &mut egui::Ui) {
        let full = ui.available_rect_before_wrap();
        let col = egui::Rect::from_min_size(full.min, Vec2::new(210.0, full.height()));
        ui.painter().rect_filled(col, 0.0, ACCENT);
        let mut menu = ui.new_child(egui::UiBuilder::new().max_rect(col.shrink(14.0)));
        menu.add_space(8.0);
        let item = |ui: &mut egui::Ui, s: &str| {
            ui.add(egui::Button::new(RichText::new(s).color(Color32::WHITE).size(15.0)).frame(false))
        };
        if item(&mut menu, "⬅  Back").clicked() {
            self.backstage = false;
        }
        menu.add_space(16.0);
        if item(&mut menu, "📄  New Tab").clicked() {
            self.new_blank_tab();
        }
        if item(&mut menu, "📂  Open…").clicked() {
            self.open();
        }
        if item(&mut menu, "💾  Save").clicked() {
            self.save(false);
        }
        if item(&mut menu, "💾  Save As…").clicked() {
            self.save(true);
        }
        menu.add_space(12.0);
        if item(&mut menu, "📥  Import MS Project XML…").clicked() {
            self.open();
        }
        if item(&mut menu, "📤  Export MS Project XML…").clicked() {
            self.export_xml();
        }
        if item(&mut menu, "📊  Export to Excel (CSV)…").clicked() {
            self.export_csv();
        }
        menu.add_space(12.0);
        if item(&mut menu, "🗂  Project Information").clicked() {
            self.dlg.project = Some(ProjectDraft::from(&self.p));
            self.backstage = false;
        }
        if item(&mut menu, "⚙  Options").clicked() {
            self.dlg.options = Some(OptionsDraft::from(&self.p));
            self.backstage = false;
        }
        if item(&mut menu, "❓  About").clicked() {
            self.dlg.about = true;
        }

        let body = egui::Rect::from_min_max(egui::pos2(col.right() + 36.0, full.top() + 24.0), full.max);
        let mut ui = ui.new_child(egui::UiBuilder::new().max_rect(body));
        ui.heading(RichText::new("New").size(26.0));
        ui.add_space(12.0);
        let monday = monday_of(Local::now().naive_local().date());
        let tiles: Vec<(&str, &str, fn(NaiveDate) -> Project)> = vec![
            ("Blank Project", "Start from an empty plan", samples::blank),
            ("Website Launch", "Design, build and go live", samples::website_launch),
            ("Office Move", "Plan a move to new premises", samples::office_move),
            ("Product Release", "From idea to shipping", samples::product_release),
            ("Event Planning", "Venue, speakers and the big day", samples::event_planning),
        ];
        ui.horizontal_wrapped(|ui| {
            for (title, sub, f) in tiles {
                let (r, resp) = ui.allocate_exact_size(Vec2::new(170.0, 150.0), egui::Sense::click());
                let fill = if resp.hovered() { ACCENT_LIGHT } else { Color32::from_gray(246) };
                ui.painter().rect_filled(r, 6.0, fill);
                ui.painter().rect_stroke(r, 6.0, egui::Stroke::new(1.0, GRID_LINE), egui::StrokeKind::Inside);
                for k in 0..4 {
                    let y = r.top() + 22.0 + k as f32 * 14.0;
                    let x0 = r.left() + 18.0 + k as f32 * 22.0;
                    let c = if title == "Blank Project" { Color32::from_gray(225) } else { self.bar_color };
                    ui.painter().rect_filled(egui::Rect::from_min_size(egui::pos2(x0, y), Vec2::new(54.0, 8.0)), 2.0, c);
                }
                ui.painter().text(r.left_bottom() + Vec2::new(12.0, -38.0), egui::Align2::LEFT_CENTER, title, egui::FontId::proportional(14.0), Color32::from_gray(30));
                ui.painter().text(r.left_bottom() + Vec2::new(12.0, -18.0), egui::Align2::LEFT_CENTER, sub, egui::FontId::proportional(10.5), Color32::from_gray(100));
                if resp.clicked() {
                    self.open_project(f(monday), None);
                }
            }
        });
        ui.add_space(20.0);
        if let Some(f) = &self.file {
            ui.label(RichText::new(format!("Current file: {}", f.display())).color(Color32::from_gray(90)));
        }
    }
}

// ---------------- ribbon widgets ----------------

pub fn group(ui: &mut egui::Ui, title: &str, add: impl FnOnce(&mut egui::Ui)) {
    ui.vertical(|ui| {
        let inner = ui
            .horizontal(|ui| {
                ui.set_min_height(58.0);
                add(ui);
            })
            .response
            .rect;
        let w = inner.width().max(40.0);
        let (r, _) = ui.allocate_exact_size(Vec2::new(w, 13.0), egui::Sense::hover());
        ui.painter().text(r.center(), egui::Align2::CENTER_CENTER, title, egui::FontId::proportional(10.0), Color32::from_gray(110));
    });
    ui.add_space(3.0);
    let (sep, _) = ui.allocate_exact_size(Vec2::new(1.0, 72.0), egui::Sense::hover());
    ui.painter().line_segment([sep.center_top(), sep.center_bottom()], egui::Stroke::new(1.0, GRID_LINE));
    ui.add_space(3.0);
}

pub fn big(ui: &mut egui::Ui, icon: &str, label: &str) -> egui::Response {
    big_toggle(ui, icon, label, false)
}

pub fn big_toggle(ui: &mut egui::Ui, icon: &str, label: &str, on: bool) -> egui::Response {
    let (r, resp) = ui.allocate_exact_size(Vec2::new(64.0, 58.0), egui::Sense::click());
    if on {
        ui.painter().rect_filled(r, 4.0, ACCENT_LIGHT);
        ui.painter().rect_stroke(r, 4.0, egui::Stroke::new(1.0, ACCENT), egui::StrokeKind::Inside);
    } else if resp.hovered() {
        ui.painter().rect_filled(r, 4.0, Color32::from_gray(228));
    }
    ui.painter().text(r.center_top() + Vec2::new(0.0, 15.0), egui::Align2::CENTER_CENTER, icon, egui::FontId::proportional(20.0), ACCENT);
    for (k, l) in label.split('\n').enumerate() {
        ui.painter().text(
            r.center_top() + Vec2::new(0.0, 34.0 + k as f32 * 11.0),
            egui::Align2::CENTER_CENTER,
            l,
            egui::FontId::proportional(10.5),
            Color32::from_gray(40),
        );
    }
    resp
}

pub fn small(ui: &mut egui::Ui, icon: &str, label: &str) -> egui::Response {
    let text = if label.is_empty() { icon.to_string() } else { format!("{icon} {label}") };
    ui.add(egui::Button::new(RichText::new(text).size(12.0)).frame(false).min_size(Vec2::new(0.0, 18.0)))
}

fn pct_button(ui: &mut egui::Ui, p: f64) -> egui::Response {
    let (r, resp) = ui.allocate_exact_size(Vec2::new(22.0, 18.0), egui::Sense::click());
    if resp.hovered() {
        ui.painter().rect_filled(r, 2.0, Color32::from_gray(228));
    }
    let bar = egui::Rect::from_min_size(r.min + Vec2::new(3.0, 5.0), Vec2::new(16.0, 8.0));
    ui.painter().rect_filled(bar, 1.0, Color32::from_rgb(0xB8, 0xCF, 0xEE));
    let done = egui::Rect::from_min_size(bar.min, Vec2::new(16.0 * p as f32 / 100.0, 8.0));
    ui.painter().rect_filled(done, 1.0, Color32::from_rgb(0x2B, 0x5C, 0x9E));
    resp
}

impl PlanApp {
    fn handle_screenshot(&mut self, ctx: &egui::Context) {
        let Some(path) = self.screenshot.clone() else { return };
        self.frame += 1;
        ctx.request_repaint();
        if self.frame == 120 && !self.shot_sent {
            let slot = self.shot.clone();
            let c2 = ctx.clone();
            ctx.request_screenshot(move |img| {
                *slot.lock().unwrap() = Some(img);
                c2.request_repaint();
            });
            self.shot_sent = true;
        }
        let shot = self.shot.lock().unwrap().take();
        if let Some(img) = shot {
            let [w, h] = img.size;
            let mut buf = Vec::with_capacity(w * h * 4);
            for px in &img.pixels {
                buf.extend_from_slice(&px.to_array());
            }
            if let Some(parent) = path.parent() {
                let _ = std::fs::create_dir_all(parent);
            }
            if let Some(rgba) = image::RgbaImage::from_raw(w as u32, h as u32, buf) {
                if let Err(e) = rgba.save(&path) {
                    eprintln!("could not save screenshot: {e}");
                }
            }
            ctx.send_viewport_cmd(egui::ViewportCommand::Close);
        }
        if self.frame > 900 {
            ctx.send_viewport_cmd(egui::ViewportCommand::Close);
        }
    }
}

impl eframe::App for PlanApp {
    fn ui(&mut self, root: &mut egui::Ui, _frame: &mut eframe::Frame) {
        let ctx = root.ctx().clone();
        let ctx = &ctx;
        self.handle_screenshot(ctx);
        if !ctx.egui_wants_keyboard_input() {
            self.tab_keyboard(ctx);
        }
        self.keyboard(ctx);

        let title = format!(
            "{}{} - Planwright",
            crate::tabs::tab_name(&self.p, &self.file),
            if self.dirty { " •" } else { "" }
        );
        if title != self.last_title {
            ctx.send_viewport_cmd(egui::ViewportCommand::Title(title.clone()));
            self.last_title = title;
        }

        egui::Panel::top("project_tabs")
            .exact_size(32.0)
            .resizable(false)
            .frame(egui::Frame::new().fill(Color32::from_rgb(0xE4, 0xE7, 0xEA)))
            .show(root, |ui| self.tab_strip(ui));

        egui::Panel::top("ribbon")
            .frame(egui::Frame::new().fill(RIBBON_BG).inner_margin(egui::Margin::symmetric(8, 4)))
            .show(root, |ui| {
                self.tab_bar(ui);
                if !self.backstage {
                    ui.add_space(2.0);
                    self.ribbon(ui);
                }
            });

        egui::Panel::bottom("status")
            .frame(egui::Frame::new().fill(RIBBON_BG).inner_margin(egui::Margin::symmetric(8, 3)))
            .show(root, |ui| self.status_bar(ui));

        if self.backstage {
            egui::CentralPanel::default().frame(egui::Frame::new().fill(Color32::WHITE)).show(root, |ui| self.backstage_ui(ui));
        } else {
            if self.show_view_bar {
                egui::Panel::left("viewbar")
                    .exact_size(84.0)
                    .resizable(false)
                    .frame(egui::Frame::new().fill(Color32::from_rgb(0xFA, 0xFB, 0xFB)))
                    .show(root, |ui| self.view_bar(ui));
            }
            egui::CentralPanel::default().frame(egui::Frame::new().fill(Color32::WHITE)).show(root, |ui| match self.view {
                View::Gantt | View::Tracking | View::TaskSheet => crate::grid::task_view(self, ui),
                View::ResourceSheet => crate::views::resource_sheet(self, ui),
                View::Calendar => crate::views::calendar_view(self, ui),
                View::Network => crate::views::network_view(self, ui),
                View::TeamPlanner => crate::views::team_planner(self, ui),
            });
        }

        crate::dialogs::show_dialogs(self, ctx);
        self.tab_dialogs(ctx);
    }
}
