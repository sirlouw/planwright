//! The task table and the Gantt chart beside it (Gantt Chart, Tracking Gantt
//! and Task Sheet views), plus the optional Timeline band above.

use crate::app::*;
use crate::model::*;
use chrono::{Datelike, Duration, NaiveDate, NaiveDateTime};
use eframe::egui::{self, Align2, Color32, FontId, Pos2, Rect, Sense, Stroke, Vec2};

pub const ROW_H: f32 = 22.0;
pub const HEAD_H: f32 = 40.0;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Col {
    Indicators,
    Mode,
    Name,
    Duration,
    Start,
    Finish,
    Preds,
    Resources,
    Percent,
    Work,
    Cost,
    Slack,
    BaseStart,
    BaseFinish,
}

impl Col {
    pub fn title(self) -> &'static str {
        match self {
            Col::Indicators => "ℹ",
            Col::Mode => "Mode",
            Col::Name => "Task Name",
            Col::Duration => "Duration",
            Col::Start => "Start",
            Col::Finish => "Finish",
            Col::Preds => "Predecessors",
            Col::Resources => "Resource Names",
            Col::Percent => "% Comp.",
            Col::Work => "Work",
            Col::Cost => "Cost",
            Col::Slack => "Total Slack",
            Col::BaseStart => "Baseline Start",
            Col::BaseFinish => "Baseline Finish",
        }
    }
    pub fn width(self) -> f32 {
        match self {
            Col::Indicators => 26.0,
            Col::Mode => 40.0,
            Col::Name => 210.0,
            Col::Duration => 70.0,
            Col::Start => 94.0,
            Col::Finish => 94.0,
            Col::Preds => 90.0,
            Col::Resources => 130.0,
            Col::Percent => 62.0,
            Col::Work => 70.0,
            Col::Cost => 84.0,
            Col::Slack => 76.0,
            Col::BaseStart | Col::BaseFinish => 100.0,
        }
    }
    pub fn editable(self) -> bool {
        !matches!(self, Col::Indicators | Col::Mode | Col::Work | Col::Cost | Col::Slack | Col::BaseStart | Col::BaseFinish)
    }
}

pub fn columns(view: View) -> Vec<Col> {
    match view {
        View::Tracking => vec![
            Col::Indicators,
            Col::Name,
            Col::Duration,
            Col::Start,
            Col::Finish,
            Col::Percent,
            Col::BaseStart,
            Col::BaseFinish,
        ],
        View::TaskSheet => vec![
            Col::Indicators,
            Col::Mode,
            Col::Name,
            Col::Duration,
            Col::Start,
            Col::Finish,
            Col::Preds,
            Col::Resources,
            Col::Percent,
            Col::Work,
            Col::Cost,
            Col::Slack,
        ],
        _ => vec![
            Col::Indicators,
            Col::Mode,
            Col::Name,
            Col::Duration,
            Col::Start,
            Col::Finish,
            Col::Preds,
            Col::Resources,
        ],
    }
}

/// Left edge of the chart's time axis: a Sunday a week before the project.
pub fn chart_origin(app: &PlanApp) -> NaiveDateTime {
    let first = app.p.first_start().min(app.p.start).date() - Duration::days(7);
    let back = first.weekday().num_days_from_sunday() as i64;
    (first - Duration::days(back)).and_hms_opt(0, 0, 0).unwrap()
}

fn x_of(t0: NaiveDateTime, ppd: f32, d: NaiveDateTime) -> f32 {
    (d - t0).num_minutes() as f32 / 1440.0 * ppd
}

fn date_at(t0: NaiveDateTime, ppd: f32, x: f32) -> NaiveDateTime {
    t0 + Duration::minutes((x / ppd * 1440.0) as i64)
}

fn cell_text(app: &PlanApp, t: &Task, col: Col) -> String {
    let p = &app.p;
    match col {
        Col::Indicators | Col::Mode => String::new(),
        Col::Name => t.name.clone(),
        Col::Duration => {
            if t.calc.summary {
                p.fmt_duration(t.dur, false)
            } else {
                p.fmt_duration(t.dur, t.estimated)
            }
        }
        Col::Start => fmt_date(t.start),
        Col::Finish => fmt_date(t.finish),
        Col::Preds => p.fmt_preds(t),
        Col::Resources => p.fmt_resources(t),
        Col::Percent => format!("{}%", fmt_num(t.percent.round())),
        Col::Work => fmt_work(t.calc.work_min),
        Col::Cost => p.money(t.calc.cost),
        Col::Slack => p.fmt_duration(t.calc.total_slack, false),
        Col::BaseStart => t.baseline.as_ref().map(|b| fmt_date(b.start)).unwrap_or("NA".into()),
        Col::BaseFinish => t.baseline.as_ref().map(|b| fmt_date(b.finish)).unwrap_or("NA".into()),
    }
}

fn edit_text(app: &PlanApp, t: &Task, col: Col) -> String {
    match col {
        Col::Percent => fmt_num(t.percent),
        _ => cell_text(app, t, col),
    }
}

/// Applies a typed cell value. Returns an error message for the status bar.
fn commit_cell(app: &mut PlanApp, uid: Option<u32>, col: Col, text: &str) -> Result<(), String> {
    let text = text.trim().to_string();
    let i = match uid {
        Some(u) => match app.p.index_of(u) {
            Some(i) => i,
            None => return Ok(()),
        },
        None => {
            if text.is_empty() {
                return Ok(());
            }
            // typing into the blank row creates a task
            app.checkpoint();
            let n = app.p.tasks.len();
            let dur = app.p.default_task_minutes();
            let uid = app.new_task_at(n, "", dur, true);
            app.sel = vec![uid];
            app.recalc();
            n
        }
    };
    let before = app.p.tasks[i].clone();
    if uid.is_some() {
        app.checkpoint();
    }
    let cal = app.p.calendar.clone();
    let res: Result<(), String> = (|| {
        match col {
            Col::Name => app.p.tasks[i].name = text.clone(),
            Col::Duration => {
                if app.p.tasks[i].calc.summary {
                    return Err("A summary task's duration comes from its subtasks".into());
                }
                let (m, est) = app.p.parse_duration(&text).ok_or("Type a duration like 3d, 4h or 2w")?;
                if m < 0 {
                    return Err("Duration can't be negative".into());
                }
                app.p.tasks[i].dur = m;
                app.p.tasks[i].estimated = est;
            }
            Col::Start => {
                let d = parse_date(&text).ok_or("Type a date like 11/30/26")?;
                let t = &mut app.p.tasks[i];
                let dt = cal.day_start(d);
                if t.manual {
                    t.start = dt;
                } else {
                    // Task::SetFieldStart IL_021b: typed start -> constraint type 4 (Start No Earlier Than)
                    t.constraint = Constraint::SNET;
                    t.constraint_date = Some(dt);
                    // IL_0235-IL_02b9: a single plain FS link (no lag) whose predecessor finishes
                    // after the typed date is removed, so the typed date can hold
                    if t.links.len() == 1 && t.links[0].kind == LinkKind::FS && t.links[0].lag == 0 {
                        let pred = t.links[0].pred;
                        let pred_finish = app.p.index_of(pred).and_then(|k| app.p.tasks[k].calc.ef).map(|f| f.date());
                        if pred_finish.map(|f| f > d).unwrap_or(false) {
                            app.p.tasks[i].links.clear();
                            app.status = "The link was removed so the task can start on the date you typed".into();
                        }
                    }
                }
            }
            Col::Finish => {
                let d = parse_date(&text).ok_or("Type a date like 11/30/26")?;
                let t = &mut app.p.tasks[i];
                let fin = cal.day_finish(d);
                if fin < t.start {
                    return Err("Finish can't be before start".into());
                }
                if t.calc.summary {
                    return Err("A summary task's finish comes from its subtasks".into());
                }
                t.dur = cal.work_between(t.start, fin).max(0);
                t.estimated = false;
            }
            Col::Preds => {
                let links = app.p.parse_preds(&text)?;
                let me = app.p.tasks[i].uid;
                if links.iter().any(|l| l.pred == me) {
                    return Err("A task can't be its own predecessor".into());
                }
                app.p.tasks[i].links = links;
            }
            Col::Resources => {
                let a = app.p.parse_resources(&text);
                app.p.tasks[i].assign = a;
            }
            Col::Percent => {
                let v: f64 = text.trim_end_matches('%').trim().replace(',', ".").parse().map_err(|_| "Type a percentage 0-100")?;
                if app.p.tasks[i].calc.summary {
                    crate::schedule::set_summary_percent(&mut app.p, i, v.clamp(0.0, 100.0));
                } else {
                    app.p.tasks[i].percent = v.clamp(0.0, 100.0);
                }
            }
            _ => {}
        }
        Ok(())
    })();
    if res.is_err() && uid.is_some() {
        app.undo.pop();
        app.p.tasks[i] = before;
    }
    app.recalc();
    res
}

pub fn task_view(app: &mut PlanApp, ui: &mut egui::Ui) {
    let full = ui.available_rect_before_wrap();
    ui.allocate_rect(full, Sense::hover());
    let mut area = full;

    let has_chart = app.view != View::TaskSheet;
    if has_chart && app.show_timeline {
        let band = Rect::from_min_size(area.min, Vec2::new(area.width(), 64.0));
        timeline_band(app, ui, band);
        area.min.y = band.max.y;
    }

    let cols = columns(app.view);
    let cols_w: f32 = 36.0 + cols.iter().map(|c| c.width()).sum::<f32>();
    let table_w = if has_chart { app.table_w.clamp(180.0, (area.width() - 120.0).max(180.0)) } else { area.width() };
    let table_rect = Rect::from_min_size(area.min, Vec2::new(table_w, area.height()));
    let chart_rect = Rect::from_min_max(Pos2::new(table_rect.right() + 5.0, area.top()), area.max);

    // splitter
    if has_chart {
        let split = Rect::from_min_max(Pos2::new(table_rect.right(), area.top()), Pos2::new(table_rect.right() + 5.0, area.bottom()));
        let r = ui.interact(split, ui.scope_id().with("splitter"), Sense::drag());
        if r.dragged() {
            app.table_w = (app.table_w + r.drag_delta().x).clamp(180.0, cols_w.max(200.0));
        }
        let c = if r.hovered() || r.dragged() { Color32::from_gray(170) } else { Color32::from_gray(215) };
        ui.painter().rect_filled(split, 0.0, c);
        if r.hovered() {
            ui.ctx().set_cursor_icon(egui::CursorIcon::ResizeHorizontal);
        }
    }

    let rows = app.visible_rows();
    let t0 = chart_origin(app);
    let ppd = app.px_per_day;

    // ----- headers -----
    let painter = ui.painter().clone();
    let head = Rect::from_min_size(table_rect.min, Vec2::new(table_rect.width(), HEAD_H));
    let tp = painter.with_clip_rect(head);
    tp.rect_filled(head, 0.0, HEADER_BG);
    let mut x = head.left() + 36.0;
    tp.line_segment([Pos2::new(x, head.top()), Pos2::new(x, head.bottom())], Stroke::new(1.0, GRID_LINE));
    for c in &cols {
        let w = c.width();
        tp.text(
            Pos2::new(x + 5.0, head.center().y + 6.0),
            Align2::LEFT_CENTER,
            c.title(),
            FontId::proportional(12.0),
            Color32::from_gray(40),
        );
        x += w;
        tp.line_segment([Pos2::new(x, head.top()), Pos2::new(x, head.bottom())], Stroke::new(1.0, GRID_LINE));
    }
    tp.line_segment([head.left_bottom(), head.right_bottom()], Stroke::new(1.0, Color32::from_gray(190)));

    if has_chart {
        timescale(app, ui, Rect::from_min_size(chart_rect.min, Vec2::new(chart_rect.width(), HEAD_H)), t0);
    }

    // ----- horizontal scroll of the chart (wheel/trackpad x, shift+wheel) -----
    let body_chart = Rect::from_min_max(Pos2::new(chart_rect.left(), chart_rect.top() + HEAD_H), chart_rect.max);
    if has_chart {
        let hovered = ui.rect_contains_pointer(body_chart) || ui.rect_contains_pointer(Rect::from_min_size(chart_rect.min, Vec2::new(chart_rect.width(), HEAD_H)));
        if hovered {
            let (dx, dy, shift) = ui.input(|i| (i.smooth_scroll_delta.x, i.smooth_scroll_delta.y, i.modifiers.shift));
            if dx != 0.0 {
                app.gantt_x = (app.gantt_x - dx).max(0.0);
            } else if shift && dy != 0.0 {
                app.gantt_x = (app.gantt_x - dy).max(0.0);
            }
        }
    }

    // ----- body -----
    let body = Rect::from_min_max(Pos2::new(area.left(), area.top() + HEAD_H), Pos2::new(area.right(), area.bottom() - if has_chart { 14.0 } else { 0.0 }));
    let mut body_ui = ui.new_child(egui::UiBuilder::new().max_rect(body));
    let extra_rows = ((body.height() / ROW_H) as usize).saturating_sub(rows.len()).max(3);
    let total_rows = rows.len() + extra_rows;
    let mut sa = egui::ScrollArea::vertical().id_salt("task_rows").auto_shrink([false, false]);
    if let Some(target) = app.scroll_to_row.take() {
        if let Some(pos) = rows.iter().position(|r| *r == target) {
            sa = sa.vertical_scroll_offset((pos as f32 * ROW_H - body.height() / 3.0).max(0.0));
        }
    }
    sa.show_viewport(&mut body_ui, |ui, viewport| {
        let origin = ui.max_rect().min;
        let content_h = total_rows as f32 * ROW_H;
        ui.set_min_height(content_h);
        ui.set_min_width(body.width() - 14.0);
        let first = (viewport.min.y / ROW_H).floor().max(0.0) as usize;
        let last = ((viewport.max.y / ROW_H).ceil() as usize + 1).min(total_rows);
        let left = table_rect.left();
        let tclip = Rect::from_min_max(Pos2::new(left, body.top()), Pos2::new(table_rect.right(), body.bottom()));
        let cclip = Rect::from_min_max(Pos2::new(chart_rect.left(), body.top()), Pos2::new(chart_rect.right(), body.bottom()));
        let row_y = |r: usize| origin.y + r as f32 * ROW_H;

        // chart background: non-working days, week lines, today
        if has_chart {
            chart_background(app, ui, cclip, t0);
        }

        for r in first..last {
            let y = row_y(r);
            let task_i = rows.get(r).copied();
            let row_rect = Rect::from_min_size(Pos2::new(left, y), Vec2::new(table_rect.width(), ROW_H));
            let selected = task_i.map(|i| app.sel.contains(&app.p.tasks[i].uid)).unwrap_or(false);
            draw_table_row(app, ui, &cols, row_rect, tclip, task_i, r, selected);
            if has_chart {
                if let Some(i) = task_i {
                    let rr = Rect::from_min_size(Pos2::new(chart_rect.left(), y), Vec2::new(chart_rect.width(), ROW_H));
                    if selected {
                        ui.painter().with_clip_rect(cclip).rect_filled(rr, 0.0, Color32::from_rgba_unmultiplied(0xCF, 0xE3, 0xF7, 90));
                    }
                    draw_bar(app, ui, i, rr, cclip, t0);
                }
            }
        }

        if has_chart {
            draw_links(app, ui, &rows, cclip, t0, chart_rect.left(), &|r| row_y(r));
            draw_link_drag(app, ui, cclip, &rows, &|r| row_y(r));
        }
    });

    // horizontal scrollbar under the chart
    if has_chart {
        let sb = Rect::from_min_max(Pos2::new(chart_rect.left(), area.bottom() - 12.0), Pos2::new(chart_rect.right(), area.bottom()));
        let span = x_of(t0, ppd, app.p.finish().max(app.p.first_start()) + Duration::days(60));
        let total = span.max(sb.width() + 1.0);
        ui.painter().rect_filled(sb, 3.0, Color32::from_gray(240));
        let thumb_w = (sb.width() / total * sb.width()).max(30.0);
        let max_off = (total - sb.width()).max(1.0);
        app.gantt_x = app.gantt_x.min(max_off);
        let tx = sb.left() + app.gantt_x / max_off * (sb.width() - thumb_w);
        let thumb = Rect::from_min_size(Pos2::new(tx, sb.top() + 2.0), Vec2::new(thumb_w, 8.0));
        let resp = ui.interact(sb, ui.scope_id().with("hscroll"), Sense::click_and_drag());
        if resp.dragged() {
            app.gantt_x = (app.gantt_x + resp.drag_delta().x * max_off / (sb.width() - thumb_w).max(1.0)).clamp(0.0, max_off);
        }
        ui.painter().rect_filled(thumb, 4.0, if resp.hovered() { Color32::from_gray(150) } else { Color32::from_gray(185) });
    }
}

fn indicator_icons(app: &PlanApp, t: &Task) -> Vec<(&'static str, Color32, String)> {
    let mut v = vec![];
    if t.complete() {
        v.push(("✔", Color32::from_rgb(0x2E, 0x8B, 0x3A), "This task was completed".to_string()));
    }
    if t.constraint != Constraint::ASAP && t.constraint != Constraint::ALAP && !t.manual {
        let txt = format!(
            "This task has a '{}' constraint on {}",
            t.constraint.label(),
            t.constraint_date.map(fmt_date).unwrap_or_default()
        );
        let c = if t.constraint.inflexible() { Color32::from_rgb(0xC0, 0x30, 0x30) } else { Color32::from_rgb(0x3A, 0x6E, 0xB5) };
        v.push(("📌", c, txt));
    }
    if t.calc.missed_deadline {
        v.push(("⚑", Color32::from_rgb(0xC0, 0x30, 0x30), "This task finishes after its deadline".into()));
    }
    if t.calc.overallocated {
        v.push(("⚠", Color32::from_rgb(0xC0, 0x30, 0x30), "A resource on this task is over-allocated".into()));
    }
    if t.calc.conflict {
        v.push(("⚠", Color32::from_rgb(0xD0, 0x80, 0x10), "A constraint conflicts with this task's links".into()));
    }
    if !t.notes.is_empty() {
        v.push(("🗒", Color32::from_gray(90), t.notes.clone()));
    }
    let _ = app;
    v
}

#[allow(clippy::too_many_arguments)]
fn draw_table_row(app: &mut PlanApp, ui: &mut egui::Ui, cols: &[Col], row: Rect, clip: Rect, task_i: Option<usize>, r: usize, selected: bool) {
    let painter = ui.painter().with_clip_rect(clip);
    let bg = if selected {
        SELECT_BG
    } else if r % 2 == 1 {
        Color32::from_rgb(0xFB, 0xFB, 0xFC)
    } else {
        Color32::WHITE
    };
    painter.rect_filled(row, 0.0, bg);
    // ID cell
    let id_rect = Rect::from_min_size(row.min, Vec2::new(36.0, ROW_H));
    painter.rect_filled(id_rect, 0.0, if selected { Color32::from_rgb(0xB9, 0xD5, 0xF2) } else { HEADER_BG });
    painter.line_segment([row.left_bottom(), row.right_bottom()], Stroke::new(1.0, Color32::from_gray(232)));
    let Some(i) = task_i else {
        // blank row: clicking the name cell starts a new task
        let mut x = row.left() + 36.0;
        for c in cols {
            let cr = Rect::from_min_size(Pos2::new(x, row.top()), Vec2::new(c.width(), ROW_H));
            painter.line_segment([cr.right_top(), cr.right_bottom()], Stroke::new(1.0, Color32::from_gray(236)));
            if *c == Col::Name && r == app.visible_rows().len() {
                let editing = app.edit.as_ref().map(|e| e.uid.is_none()).unwrap_or(false);
                if editing {
                    cell_editor(app, ui, cr);
                } else {
                    let resp = ui.interact(cr.intersect(clip), ui.scope_id().with(("blank", r)), Sense::click());
                    if resp.hovered() {
                        painter.text(cr.left_center() + Vec2::new(5.0, 0.0), Align2::LEFT_CENTER, "Type a new task name…", FontId::proportional(12.0), Color32::from_gray(160));
                    }
                    if resp.clicked() {
                        app.sel.clear();
                        app.edit = Some(CellEdit { uid: None, col: Col::Name, buf: String::new(), focus: true });
                    }
                }
            }
            x += c.width();
        }
        return;
    };
    let t = app.p.tasks[i].clone();
    painter.text(id_rect.center(), Align2::CENTER_CENTER, t.calc.id.to_string(), FontId::proportional(11.5), Color32::from_gray(80));
    let id_resp = ui.interact(id_rect.intersect(clip), ui.scope_id().with(("idcell", t.uid)), Sense::click());
    if id_resp.clicked() {
        select_click(app, ui, t.uid);
    }
    if id_resp.double_clicked() {
        app.sel = vec![t.uid];
        app.open_task_info(0);
    }
    row_context_menu(app, &id_resp, t.uid);

    let text_color = if app.show_critical && t.calc.critical && !t.calc.summary {
        Color32::from_rgb(0xC0, 0x00, 0x00)
    } else if !t.active {
        Color32::from_gray(150)
    } else {
        Color32::from_gray(25)
    };
    let mut x = row.left() + 36.0;
    for &c in cols {
        let cr = Rect::from_min_size(Pos2::new(x, row.top()), Vec2::new(c.width(), ROW_H));
        x += c.width();
        painter.line_segment([cr.right_top(), cr.right_bottom()], Stroke::new(1.0, Color32::from_gray(236)));
        if cr.left() > clip.right() {
            continue;
        }
        let editing = app.edit.as_ref().map(|e| e.uid == Some(t.uid) && e.col == c).unwrap_or(false);
        if editing {
            cell_editor(app, ui, cr);
            continue;
        }
        let resp = ui.interact(cr.intersect(clip), ui.scope_id().with(("cell", t.uid, c as u8)), Sense::click());
        if resp.clicked() {
            let was_only = app.sel.len() == 1 && app.sel[0] == t.uid;
            select_click(app, ui, t.uid);
            if was_only && c == Col::Name {
                app.edit = Some(CellEdit { uid: Some(t.uid), col: c, buf: edit_text(app, &t, c), focus: true });
            }
        }
        if resp.double_clicked() {
            if c.editable() && !(t.calc.summary && matches!(c, Col::Duration | Col::Finish)) {
                app.edit = Some(CellEdit { uid: Some(t.uid), col: c, buf: edit_text(app, &t, c), focus: true });
            } else {
                app.sel = vec![t.uid];
                app.open_task_info(0);
            }
        }
        row_context_menu(app, &resp, t.uid);
        match c {
            Col::Indicators => {
                let icons = indicator_icons(app, &t);
                if let Some((ic, col, _)) = icons.first() {
                    painter.text(cr.center(), Align2::CENTER_CENTER, *ic, FontId::proportional(12.0), *col);
                }
                if !icons.is_empty() {
                    let tip = icons.iter().map(|(_, _, s)| s.as_str()).collect::<Vec<_>>().join("\n");
                    resp.on_hover_text(tip);
                }
            }
            Col::Mode => {
                let (ic, tip, col) = if t.manual {
                    ("📌", "Manually Scheduled", Color32::from_rgb(0x2C, 0x8A, 0x9A))
                } else {
                    ("➡", "Auto Scheduled", Color32::from_rgb(0x3A, 0x6E, 0xB5))
                };
                painter.text(cr.center(), Align2::CENTER_CENTER, ic, FontId::proportional(12.0), col);
                resp.on_hover_text(tip);
            }
            Col::Name => {
                let indent = (t.level.saturating_sub(1)) as f32 * 14.0;
                let mut tx = cr.left() + 5.0 + indent;
                if t.calc.summary {
                    let tri = if t.collapsed { "▶" } else { "◢" };
                    let tr = Rect::from_min_size(Pos2::new(tx - 2.0, cr.top() + 3.0), Vec2::new(14.0, 16.0));
                    painter.text(tr.center(), Align2::CENTER_CENTER, tri, FontId::proportional(9.0), Color32::from_gray(70));
                    let tri_resp = ui.interact(tr.intersect(clip), ui.scope_id().with(("collapse", t.uid)), Sense::click());
                    if tri_resp.clicked() {
                        if let Some(k) = app.p.index_of(t.uid) {
                            app.p.tasks[k].collapsed = !app.p.tasks[k].collapsed;
                            app.recalc();
                        }
                    }
                    tx += 14.0;
                }
                let mut name = t.name.clone();
                if app.show_outline_numbers {
                    name = format!("{} {}", t.calc.wbs, name);
                }
                let font = if t.calc.summary { FontId::new(12.5, egui::FontFamily::Proportional) } else { FontId::proportional(12.5) };
                let galley = painter.layout_no_wrap(name, font, text_color);
                let text_clip = clip.intersect(cr.shrink2(Vec2::new(1.0, 0.0)));
                painter.with_clip_rect(text_clip).galley(Pos2::new(tx, cr.center().y - galley.size().y / 2.0), galley.clone(), text_color);
                if t.calc.summary {
                    // fake bold
                    painter.with_clip_rect(text_clip).galley(Pos2::new(tx + 0.6, cr.center().y - galley.size().y / 2.0), galley, text_color);
                }
            }
            _ => {
                let s = cell_text(app, &t, c);
                let right = matches!(c, Col::Work | Col::Cost | Col::Percent);
                let text_clip = clip.intersect(cr.shrink2(Vec2::new(2.0, 0.0)));
                let col = if matches!(c, Col::Start | Col::Finish) && t.manual { Color32::from_rgb(0x1F, 0x6F, 0x7F) } else { text_color };
                if right {
                    painter.with_clip_rect(text_clip).text(cr.right_center() - Vec2::new(6.0, 0.0), Align2::RIGHT_CENTER, s, FontId::proportional(12.0), col);
                } else {
                    painter.with_clip_rect(text_clip).text(cr.left_center() + Vec2::new(5.0, 0.0), Align2::LEFT_CENTER, s, FontId::proportional(12.0), col);
                }
            }
        }
    }
}

fn cell_editor(app: &mut PlanApp, ui: &mut egui::Ui, cr: Rect) {
    let Some(mut e) = app.edit.clone() else { return };
    let mut child = ui.new_child(egui::UiBuilder::new().max_rect(cr.shrink(1.0)));
    let te = egui::TextEdit::singleline(&mut e.buf).desired_width(cr.width() - 4.0).font(FontId::proportional(12.5)).margin(egui::Margin::symmetric(3, 2));
    let resp = child.add(te);
    if e.focus {
        resp.request_focus();
        e.focus = false;
    }
    let (enter, esc, tab) = ui.input(|i| (i.key_pressed(egui::Key::Enter), i.key_pressed(egui::Key::Escape), i.key_pressed(egui::Key::Tab)));
    if esc {
        app.edit = None;
        return;
    }
    if resp.lost_focus() || enter || tab {
        app.edit = None;
        match commit_cell(app, e.uid, e.col, &e.buf) {
            Ok(()) => {}
            Err(msg) => app.status = format!("⚠ {msg}"),
        }
        // Enter moves to the next row, like a spreadsheet
        if enter && e.col == Col::Name && e.uid.is_none() {
            app.edit = Some(CellEdit { uid: None, col: Col::Name, buf: String::new(), focus: true });
        }
        return;
    }
    app.edit = Some(e);
}

fn select_click(app: &mut PlanApp, ui: &egui::Ui, uid: u32) {
    let (cmd, shift) = ui.input(|i| (i.modifiers.command, i.modifiers.shift));
    if shift {
        if let (Some(a), Some(b)) = (app.anchor.and_then(|u| app.p.index_of(u)), app.p.index_of(uid)) {
            let rows = app.visible_rows();
            let pa = rows.iter().position(|r| *r == a);
            let pb = rows.iter().position(|r| *r == b);
            if let (Some(pa), Some(pb)) = (pa, pb) {
                let (lo, hi) = (pa.min(pb), pa.max(pb));
                app.sel = rows[lo..=hi].iter().map(|&k| app.p.tasks[k].uid).collect();
                return;
            }
        }
    }
    if cmd {
        if let Some(pos) = app.sel.iter().position(|u| *u == uid) {
            app.sel.remove(pos);
        } else {
            app.sel.push(uid);
        }
    } else {
        app.sel = vec![uid];
    }
    app.anchor = Some(uid);
    app.edit = None;
}

fn row_context_menu(app: &mut PlanApp, resp: &egui::Response, uid: u32) {
    resp.context_menu(|ui| {
        if !app.sel.contains(&uid) {
            app.sel = vec![uid];
        }
        if ui.button("ℹ  Task Information…").clicked() {
            app.open_task_info(0);
            ui.close();
        }
        if ui.button("🗒  Notes…").clicked() {
            app.open_task_info(4);
            ui.close();
        }
        ui.separator();
        if ui.button("➕  Insert Task").clicked() {
            app.insert_task();
            ui.close();
        }
        if ui.button("◆  Insert Milestone").clicked() {
            app.insert_milestone();
            ui.close();
        }
        if ui.button("🗑  Delete Task").clicked() {
            app.delete_selected();
            ui.close();
        }
        ui.separator();
        if ui.button("➡  Indent").clicked() {
            app.indent();
            ui.close();
        }
        if ui.button("⬅  Outdent").clicked() {
            app.outdent();
            ui.close();
        }
        if ui.button("🔗  Link Tasks").clicked() {
            app.link_selected();
            ui.close();
        }
        ui.separator();
        if ui.button("✂  Cut").clicked() {
            app.copy(true);
            ui.close();
        }
        if ui.button("🗐  Copy").clicked() {
            app.copy(false);
            ui.close();
        }
        if ui.button("📋  Paste").clicked() {
            app.paste();
            ui.close();
        }
        ui.separator();
        if ui.button("📌  Manually Schedule").clicked() {
            app.set_manual(true);
            ui.close();
        }
        if ui.button("⚙  Auto Schedule").clicked() {
            app.set_manual(false);
            ui.close();
        }
        if ui.button("⏱  Add to Timeline").clicked() {
            app.toggle_timeline_for_selected();
            ui.close();
        }
        if ui.button("👪  Assign Resources…").clicked() {
            app.dlg.assign = true;
            ui.close();
        }
    });
}

// ---------------- chart ----------------

fn timescale(app: &PlanApp, ui: &egui::Ui, rect: Rect, t0: NaiveDateTime) {
    let p = ui.painter().with_clip_rect(rect);
    p.rect_filled(rect, 0.0, HEADER_BG);
    let ppd = app.px_per_day;
    let mid = rect.top() + HEAD_H / 2.0;
    p.line_segment([Pos2::new(rect.left(), mid), Pos2::new(rect.right(), mid)], Stroke::new(1.0, GRID_LINE));
    p.line_segment([rect.left_bottom(), rect.right_bottom()], Stroke::new(1.0, Color32::from_gray(190)));
    let first_day = (app.gantt_x / ppd).floor() as i64 - 1;
    let days_visible = (rect.width() / ppd).ceil() as i64 + 3;
    let x0 = rect.left() - app.gantt_x;
    let font = FontId::proportional(11.0);
    let tc = Color32::from_gray(50);
    let date = |k: i64| (t0 + Duration::days(k)).date();
    if ppd >= 14.0 {
        // top: weeks starting Sunday, bottom: days
        for k in first_day..first_day + days_visible {
            let d = date(k);
            let x = x0 + k as f32 * ppd;
            if d.weekday().num_days_from_sunday() == 0 {
                p.line_segment([Pos2::new(x, rect.top()), Pos2::new(x, mid)], Stroke::new(1.0, GRID_LINE));
                p.text(Pos2::new(x + 4.0, rect.top() + HEAD_H / 4.0), Align2::LEFT_CENTER, d.format("%b %-d, '%y").to_string(), font.clone(), tc);
            }
            p.line_segment([Pos2::new(x, mid), Pos2::new(x, rect.bottom())], Stroke::new(1.0, GRID_LINE));
            let lbl = if ppd >= 34.0 {
                d.format("%a %-d").to_string()
            } else {
                ["S", "M", "T", "W", "T", "F", "S"][d.weekday().num_days_from_sunday() as usize].to_string()
            };
            if ppd >= 34.0 && ppd < 46.0 {
                p.text(Pos2::new(x + ppd / 2.0, mid + HEAD_H / 4.0), Align2::CENTER_CENTER, d.format("%-d").to_string(), font.clone(), tc);
            } else {
                p.text(Pos2::new(x + ppd / 2.0, mid + HEAD_H / 4.0), Align2::CENTER_CENTER, lbl, font.clone(), tc);
            }
        }
    } else if ppd >= 4.0 {
        // top: months, bottom: weeks
        for k in first_day..first_day + days_visible {
            let d = date(k);
            let x = x0 + k as f32 * ppd;
            if d.day() == 1 {
                p.line_segment([Pos2::new(x, rect.top()), Pos2::new(x, mid)], Stroke::new(1.0, GRID_LINE));
                p.text(Pos2::new(x + 4.0, rect.top() + HEAD_H / 4.0), Align2::LEFT_CENTER, d.format("%B %Y").to_string(), font.clone(), tc);
            }
            if d.weekday().num_days_from_sunday() == 0 {
                p.line_segment([Pos2::new(x, mid), Pos2::new(x, rect.bottom())], Stroke::new(1.0, GRID_LINE));
                if ppd * 7.0 > 26.0 {
                    p.text(Pos2::new(x + 3.0, mid + HEAD_H / 4.0), Align2::LEFT_CENTER, d.format("%-d").to_string(), font.clone(), tc);
                }
            }
        }
    } else {
        // top: years, bottom: months
        for k in first_day..first_day + days_visible {
            let d = date(k);
            let x = x0 + k as f32 * ppd;
            if d.ordinal() == 1 {
                p.line_segment([Pos2::new(x, rect.top()), Pos2::new(x, mid)], Stroke::new(1.0, GRID_LINE));
                p.text(Pos2::new(x + 4.0, rect.top() + HEAD_H / 4.0), Align2::LEFT_CENTER, d.format("%Y").to_string(), font.clone(), tc);
            }
            if d.day() == 1 {
                p.line_segment([Pos2::new(x, mid), Pos2::new(x, rect.bottom())], Stroke::new(1.0, GRID_LINE));
                p.text(Pos2::new(x + 3.0, mid + HEAD_H / 4.0), Align2::LEFT_CENTER, d.format("%b").to_string(), font.clone(), tc);
            }
        }
    }
}

fn chart_background(app: &PlanApp, ui: &egui::Ui, clip: Rect, t0: NaiveDateTime) {
    let p = ui.painter().with_clip_rect(clip);
    let ppd = app.px_per_day;
    let x0 = clip.left() - app.gantt_x;
    let first_day = (app.gantt_x / ppd).floor() as i64 - 1;
    let days_visible = (clip.width() / ppd).ceil() as i64 + 3;
    for k in first_day..first_day + days_visible {
        let d = (t0 + Duration::days(k)).date();
        let x = x0 + k as f32 * ppd;
        if ppd >= 4.0 && !app.p.calendar.is_working_day(d) {
            p.rect_filled(Rect::from_min_max(Pos2::new(x, clip.top()), Pos2::new(x + ppd, clip.bottom())), 0.0, Color32::from_rgb(0xF1, 0xF2, 0xF4));
        }
        if ppd < 14.0 && d.weekday().num_days_from_sunday() == 0 && ppd >= 4.0 {
            p.line_segment([Pos2::new(x, clip.top()), Pos2::new(x, clip.bottom())], Stroke::new(1.0, Color32::from_gray(238)));
        }
    }
    // today and status date
    let today = PlanApp::today();
    let tx = x0 + x_of(t0, ppd, today);
    dashed_v(&p, tx, clip.top(), clip.bottom(), Color32::from_rgb(0xE0, 0x8E, 0x3A));
    if let Some(sd) = app.p.status_date {
        let sx = x0 + x_of(t0, ppd, app.p.calendar.day_finish(sd));
        dashed_v(&p, sx, clip.top(), clip.bottom(), Color32::from_rgb(0x2E, 0x6B, 0x3A));
    }
    // project start
    let px = x0 + x_of(t0, ppd, app.p.start);
    p.line_segment([Pos2::new(px, clip.top()), Pos2::new(px, clip.bottom())], Stroke::new(1.0, Color32::from_rgb(0x9C, 0xB8, 0xDA)));
}

fn dashed_v(p: &egui::Painter, x: f32, top: f32, bottom: f32, c: Color32) {
    let mut y = top;
    while y < bottom {
        p.line_segment([Pos2::new(x, y), Pos2::new(x, (y + 4.0).min(bottom))], Stroke::new(1.2, c));
        y += 7.0;
    }
}

fn darker(c: Color32, f: f32) -> Color32 {
    Color32::from_rgb((c.r() as f32 * f) as u8, (c.g() as f32 * f) as u8, (c.b() as f32 * f) as u8)
}

fn lighter(c: Color32, f: f32) -> Color32 {
    let l = |v: u8| (v as f32 + (255.0 - v as f32) * f) as u8;
    Color32::from_rgb(l(c.r()), l(c.g()), l(c.b()))
}

pub const CRIT: Color32 = Color32::from_rgb(0xE0, 0x5A, 0x5A);

fn bar_x(app: &PlanApp, t0: NaiveDateTime, left: f32, d: NaiveDateTime) -> f32 {
    left - app.gantt_x + x_of(t0, app.px_per_day, d)
}

fn draw_bar(app: &mut PlanApp, ui: &mut egui::Ui, i: usize, row: Rect, clip: Rect, t0: NaiveDateTime) {
    let t = app.p.tasks[i].clone();
    let p = ui.painter().with_clip_rect(clip);
    let left = row.left();
    let xs = bar_x(app, t0, left, t.start);
    let xf = bar_x(app, t0, left, t.finish).max(xs + 1.0);
    let cy = row.center().y;
    let tracking = app.view == View::Tracking;
    let crit = (app.show_critical || tracking) && t.calc.critical;
    let base_col = if crit { CRIT } else { app.bar_color };

    // baseline under the bar
    if (app.show_baseline || tracking) && t.baseline.is_some() {
        let b = t.baseline.as_ref().unwrap();
        let bs = bar_x(app, t0, left, b.start);
        let bf = bar_x(app, t0, left, b.finish).max(bs + 1.0);
        if b.dur == 0 && !t.calc.summary {
            diamond(&p, Pos2::new(bs, cy + 6.0), 4.0, Color32::from_gray(150));
        } else {
            p.rect_filled(Rect::from_min_max(Pos2::new(bs, cy + 3.0), Pos2::new(bf, cy + 8.0)), 1.0, Color32::from_gray(175));
        }
    }
    let shift = if (app.show_baseline || tracking) && t.baseline.is_some() { -3.0 } else { 0.0 };
    let cy = cy + shift;

    // slack line
    if app.show_slack && !t.calc.summary {
        if let Some(lf) = t.calc.lf {
            let xl = bar_x(app, t0, left, lf);
            if xl > xf + 1.0 {
                p.line_segment([Pos2::new(xf, cy + 4.0), Pos2::new(xl, cy + 4.0)], Stroke::new(1.5, Color32::from_rgb(0x2E, 0x8B, 0x57)));
                p.line_segment([Pos2::new(xl, cy + 1.0), Pos2::new(xl, cy + 7.0)], Stroke::new(1.5, Color32::from_rgb(0x2E, 0x8B, 0x57)));
            }
        }
    }

    let mut label_x = xf + 6.0;
    let hit;
    if t.calc.summary {
        let dark = if crit { Color32::from_rgb(0xA0, 0x20, 0x20) } else { Color32::from_gray(40) };
        let r = Rect::from_min_max(Pos2::new(xs, cy - 6.0), Pos2::new(xf, cy));
        p.rect_filled(r, 0.0, lighter(dark, 0.55));
        let done = Rect::from_min_max(r.min, Pos2::new(xs + (xf - xs) * (t.percent as f32 / 100.0), r.max.y));
        p.rect_filled(done, 0.0, dark);
        for x in [xs, xf] {
            let pts = vec![Pos2::new(x - 5.0, cy - 6.0), Pos2::new(x + 5.0, cy - 6.0), Pos2::new(x, cy + 4.0)];
            p.add(egui::Shape::convex_polygon(pts, dark, Stroke::NONE));
        }
        hit = Rect::from_min_max(Pos2::new(xs - 5.0, cy - 8.0), Pos2::new(xf + 5.0, cy + 5.0));
    } else if t.is_milestone() {
        let c = if crit { Color32::from_rgb(0xB0, 0x20, 0x20) } else { Color32::from_gray(30) };
        diamond(&p, Pos2::new(xs, cy), 6.5, c);
        p.text(Pos2::new(xs + 10.0, cy), Align2::LEFT_CENTER, t.start.format("%-m/%-d").to_string(), FontId::proportional(11.0), Color32::from_gray(40));
        label_x = xs + 44.0;
        hit = Rect::from_center_size(Pos2::new(xs, cy), Vec2::splat(14.0));
    } else {
        let r = Rect::from_min_max(Pos2::new(xs, cy - 6.0), Pos2::new(xf, cy + 6.0));
        if t.manual {
            let fill = lighter(Color32::from_rgb(0x3F, 0xA9, 0xB5), 0.45);
            p.rect_filled(r, 1.0, fill);
            p.rect_filled(Rect::from_min_size(r.min, Vec2::new(3.0, r.height())), 0.0, Color32::from_rgb(0x2C, 0x7F, 0x8A));
            p.rect_filled(Rect::from_min_size(Pos2::new(r.right() - 3.0, r.top()), Vec2::new(3.0, r.height())), 0.0, Color32::from_rgb(0x2C, 0x7F, 0x8A));
        } else if !t.active {
            p.rect_stroke(r, 1.0, Stroke::new(1.0, base_col), egui::StrokeKind::Inside);
        } else {
            let fill = if app.show_late && t.calc.late { Color32::from_rgb(0xE8, 0xA3, 0x3D) } else { lighter(base_col, 0.15) };
            p.rect_filled(r, 2.0, fill);
            p.rect_stroke(r, 2.0, Stroke::new(1.0, darker(base_col, 0.75)), egui::StrokeKind::Inside);
        }
        if t.percent > 0.0 {
            let w = (xf - xs) * (t.percent as f32 / 100.0);
            let pr = Rect::from_min_size(Pos2::new(xs, cy - 2.0), Vec2::new(w, 4.0));
            p.rect_filled(pr, 0.0, darker(base_col, 0.45));
        }
        if t.calc.missed_deadline || t.deadline.is_some() {
            if let Some(d) = t.deadline {
                let dx = bar_x(app, t0, left, app.p.calendar.day_finish(d));
                let c = Color32::from_rgb(0x2E, 0x8B, 0x3A);
                let pts = vec![Pos2::new(dx - 5.0, cy - 9.0), Pos2::new(dx + 5.0, cy - 9.0), Pos2::new(dx, cy - 3.0)];
                p.add(egui::Shape::convex_polygon(pts, c, Stroke::NONE));
                p.line_segment([Pos2::new(dx, cy - 9.0), Pos2::new(dx, cy + 8.0)], Stroke::new(1.0, c));
            }
        }
        hit = r.expand2(Vec2::new(2.0, 3.0));
    }
    // resource names to the right of the bar
    let names = app.p.fmt_resources(&t);
    if !names.is_empty() {
        p.text(Pos2::new(label_x, cy), Align2::LEFT_CENTER, names, FontId::proportional(11.0), Color32::from_gray(60));
    }

    // ----- interaction -----
    let hit = hit.intersect(clip);
    if hit.width() <= 0.0 {
        return;
    }
    let resp = ui.interact(hit, ui.scope_id().with(("bar", t.uid)), Sense::click_and_drag());
    let hover_pos = resp.hover_pos();
    let near_end = hover_pos.map(|hp| (hp.x - xf).abs() < 5.0).unwrap_or(false) && !t.calc.summary && !t.is_milestone();
    if resp.hovered() && app.drag.is_none() {
        ui.ctx().set_cursor_icon(if near_end { egui::CursorIcon::ResizeHorizontal } else { egui::CursorIcon::Grab });
    }
    resp.clone().on_hover_ui(|ui| {
        ui.label(egui::RichText::new(&t.name).strong());
        egui::Grid::new("tip").num_columns(2).show(ui, |ui| {
            ui.label("Start:");
            ui.label(fmt_date_long(t.start));
            ui.end_row();
            ui.label("Finish:");
            ui.label(fmt_date_long(t.finish));
            ui.end_row();
            ui.label("Duration:");
            ui.label(app.p.fmt_duration(t.dur, t.estimated));
            ui.end_row();
            ui.label("Complete:");
            ui.label(format!("{}%", fmt_num(t.percent)));
            ui.end_row();
            if !t.calc.summary {
                ui.label("Total slack:");
                ui.label(app.p.fmt_duration(t.calc.total_slack, false));
                ui.end_row();
            }
        });
        if !t.calc.summary {
            ui.label(egui::RichText::new("Drag to move · drag the end to resize · drag up/down onto another task to link").small().weak());
        }
    });
    if resp.clicked() {
        select_click(app, ui, t.uid);
    }
    if resp.double_clicked() {
        app.sel = vec![t.uid];
        app.open_task_info(0);
    }
    row_context_menu(app, &resp, t.uid);
    if resp.drag_started() && !t.calc.summary {
        let origin = resp.interact_pointer_pos().unwrap_or(hit.center());
        app.drag = Some(BarDrag {
            uid: t.uid,
            mode: if near_end { DragMode::Resize } else { DragMode::Move },
            origin,
            start: t.start,
            dur: t.dur,
            moved: false,
        });
    }
    if let Some(d) = app.drag.clone() {
        if d.uid != t.uid {
            return;
        }
        let Some(pos) = ui.ctx().pointer_latest_pos() else { return };
        let dx = pos.x - d.origin.x;
        let dy = pos.y - d.origin.y;
        let mut d = d;
        if d.mode == DragMode::Move && dy.abs() > ROW_H * 0.8 && dy.abs() > dx.abs() {
            d.mode = DragMode::Link;
        }
        let ppd = app.px_per_day;
        let step = if ppd >= 40.0 { 0.5 } else { 1.0 };
        let days = ((dx / ppd) / step).round() * step;
        match d.mode {
            DragMode::Move => {
                let new_start = d.start + Duration::minutes((days * 1440.0) as i64);
                let gx = bar_x(app, t0, left, new_start);
                let gf = bar_x(app, t0, left, app.p.calendar.add_minutes(app.p.calendar.next_work_start(new_start), d.dur));
                p.rect_stroke(Rect::from_min_max(Pos2::new(gx, cy - 7.0), Pos2::new(gf, cy + 7.0)), 2.0, Stroke::new(1.5, Color32::from_gray(60)), egui::StrokeKind::Outside);
                pointer_note(ui, &format!("Start: {}", fmt_date(app.p.calendar.next_work_start(new_start))));
            }
            DragMode::Resize => {
                let new_fin_x = xf + dx;
                let p2 = Pos2::new(new_fin_x.max(xs + 2.0), cy);
                p.rect_stroke(Rect::from_min_max(Pos2::new(xs, cy - 7.0), Pos2::new(p2.x, cy + 7.0)), 2.0, Stroke::new(1.5, Color32::from_gray(60)), egui::StrokeKind::Outside);
                let fin = date_at(t0, ppd, new_fin_x - (left - app.gantt_x));
                let dur = app.p.calendar.work_between(t.start, fin).max(0);
                let dur = ((dur as f64 / app.p.minutes_per_day as f64 / step as f64).round() * step as f64 * app.p.minutes_per_day as f64) as i64;
                pointer_note(ui, &format!("Duration: {}", app.p.fmt_duration(dur.max(0), false)));
            }
            DragMode::Link => {}
        }
        d.moved = dx.abs() > 2.0 || dy.abs() > 2.0;
        let released = ui.input(|i| i.pointer.any_released());
        if released {
            app.drag = None;
            if !d.moved {
                return;
            }
            match d.mode {
                DragMode::Move => {
                    if days != 0.0 {
                        let ns = app.p.calendar.next_work_start(d.start + Duration::minutes((days * 1440.0) as i64));
                        app.checkpoint();
                        if let Some(k) = app.p.index_of(d.uid) {
                            let tk = &mut app.p.tasks[k];
                            if tk.manual {
                                tk.start = ns;
                            } else {
                                tk.constraint = Constraint::SNET;
                                tk.constraint_date = Some(ns);
                            }
                        }
                        app.recalc();
                        app.status = "Moved the task (it now starts no earlier than the new date)".into();
                    }
                }
                DragMode::Resize => {
                    let fin = date_at(t0, ppd, xf + dx - (left - app.gantt_x));
                    let dur = app.p.calendar.work_between(t.start, fin).max(0);
                    let dur = ((dur as f64 / app.p.minutes_per_day as f64 / step as f64).round() * step as f64 * app.p.minutes_per_day as f64) as i64;
                    app.checkpoint();
                    if let Some(k) = app.p.index_of(d.uid) {
                        app.p.tasks[k].dur = dur.max(0);
                        app.p.tasks[k].estimated = false;
                    }
                    app.recalc();
                }
                DragMode::Link => {
                    let rows = app.visible_rows();
                    // find the row under the pointer from the scroll content
                    if let Some(target) = app.dlg.link_target.take() {
                        if let Some(&ti) = rows.get(target) {
                            let succ = app.p.tasks[ti].uid;
                            app.add_link(d.uid, succ);
                            app.status = "Linked the tasks (Finish-to-Start)".into();
                        }
                    }
                }
            }
        } else {
            app.drag = Some(d);
        }
    }
}

fn draw_link_drag(app: &mut PlanApp, ui: &mut egui::Ui, clip: Rect, rows: &[usize], row_y: &dyn Fn(usize) -> f32) {
    let Some(d) = app.drag.clone() else { return };
    if d.mode != DragMode::Link {
        return;
    }
    let Some(pos) = ui.ctx().pointer_latest_pos() else { return };
    let p = ui.painter().with_clip_rect(clip);
    p.line_segment([d.origin, pos], Stroke::new(1.5, Color32::from_rgb(0x1F, 0x5F, 0xAF)));
    // which row is under the pointer?
    let mut target = None;
    for (r, &ti) in rows.iter().enumerate() {
        let y = row_y(r);
        if pos.y >= y && pos.y < y + ROW_H {
            if app.p.tasks[ti].uid != d.uid {
                target = Some(r);
                p.rect_stroke(Rect::from_min_max(Pos2::new(clip.left(), y), Pos2::new(clip.right(), y + ROW_H)), 0.0, Stroke::new(1.0, Color32::from_rgb(0x1F, 0x5F, 0xAF)), egui::StrokeKind::Inside);
                let name = app.p.tasks[ti].name.clone();
                let from = app.p.index_of(d.uid).map(|k| app.p.tasks[k].name.clone()).unwrap_or_default();
                pointer_note(ui, &format!("Finish-to-Start link\nFrom: {from}\nTo: {name}"));
            }
        }
    }
    app.dlg.link_target = target;
}

/// A small note box next to the mouse pointer, drawn above everything else.
fn pointer_note(ui: &egui::Ui, text: &str) {
    let Some(pos) = ui.ctx().pointer_latest_pos() else { return };
    let layer = egui::LayerId::new(egui::Order::Tooltip, ui.make_persistent_id("pointer_note"));
    let p = ui.ctx().layer_painter(layer);
    let galley = p.layout_no_wrap(text.to_string(), FontId::proportional(12.0), Color32::from_gray(25));
    let r = Rect::from_min_size(pos + Vec2::new(14.0, 16.0), galley.size() + Vec2::new(12.0, 8.0));
    p.rect_filled(r, 4.0, Color32::from_rgb(0xFF, 0xFF, 0xF4));
    p.rect_stroke(r, 4.0, Stroke::new(1.0, Color32::from_gray(170)), egui::StrokeKind::Inside);
    p.galley(r.min + Vec2::new(6.0, 4.0), galley, Color32::from_gray(25));
}

fn diamond(p: &egui::Painter, c: Pos2, r: f32, col: Color32) {
    let pts = vec![Pos2::new(c.x, c.y - r), Pos2::new(c.x + r, c.y), Pos2::new(c.x, c.y + r), Pos2::new(c.x - r, c.y)];
    p.add(egui::Shape::convex_polygon(pts, col, Stroke::NONE));
}

fn draw_links(app: &PlanApp, ui: &egui::Ui, rows: &[usize], clip: Rect, t0: NaiveDateTime, left: f32, row_y: &dyn Fn(usize) -> f32) {
    let p = ui.painter().with_clip_rect(clip);
    let pos_of: std::collections::HashMap<usize, usize> = rows.iter().enumerate().map(|(r, &i)| (i, r)).collect();
    let shift = if app.show_baseline || app.view == View::Tracking { -3.0 } else { 0.0 };
    for (&si, &sr) in &pos_of {
        let s = &app.p.tasks[si];
        for l in &s.links {
            let Some(pi) = app.p.index_of(l.pred) else { continue };
            let Some(&pr) = pos_of.get(&pi) else { continue };
            let pt = &app.p.tasks[pi];
            let yp = row_y(pr) + ROW_H / 2.0 + shift;
            let ys = row_y(sr) + ROW_H / 2.0 + shift;
            if (yp < clip.top() - 400.0 && ys < clip.top() - 400.0) || (yp > clip.bottom() + 400.0 && ys > clip.bottom() + 400.0) {
                continue;
            }
            let crit = (app.show_critical || app.view == View::Tracking) && pt.calc.critical && s.calc.critical;
            let col = if crit { Color32::from_rgb(0xC0, 0x20, 0x20) } else { Color32::from_rgb(0x1F, 0x5F, 0xAF) };
            let st = Stroke::new(1.0, col);
            let pxs = bar_x(app, t0, left, pt.start);
            let pxf = bar_x(app, t0, left, pt.finish);
            let sxs = bar_x(app, t0, left, s.start);
            let sxf = bar_x(app, t0, left, s.finish);
            let down = ys > yp;
            let (from_x, to_x, from_end, to_start) = match l.kind {
                LinkKind::FS => (pxf, sxs, true, true),
                LinkKind::SS => (pxs, sxs, false, true),
                LinkKind::FF => (pxf, sxf, true, false),
                LinkKind::SF => (pxs, sxf, false, false),
            };
            let edge_y = if down { ys - 6.0 } else { ys + 6.0 };
            if to_start && from_end && to_x >= from_x + 4.0 {
                // classic elbow: right then down onto the bar's start
                let ax = to_x + 3.0;
                p.line_segment([Pos2::new(from_x, yp), Pos2::new(ax, yp)], st);
                p.line_segment([Pos2::new(ax, yp), Pos2::new(ax, edge_y)], st);
                arrow(&p, Pos2::new(ax, edge_y), if down { Vec2::new(0.0, 1.0) } else { Vec2::new(0.0, -1.0) }, col);
            } else {
                let out = if from_end { from_x + 7.0 } else { from_x - 7.0 };
                let inn = if to_start { to_x - 7.0 } else { to_x + 7.0 };
                let mid_y = if down { row_y(sr) } else { row_y(sr) + ROW_H };
                let pts = [
                    Pos2::new(from_x, yp),
                    Pos2::new(out, yp),
                    Pos2::new(out, mid_y),
                    Pos2::new(inn, mid_y),
                    Pos2::new(inn, ys),
                    Pos2::new(to_x, ys),
                ];
                for w in pts.windows(2) {
                    p.line_segment([w[0], w[1]], st);
                }
                arrow(&p, Pos2::new(to_x, ys), if to_start { Vec2::new(1.0, 0.0) } else { Vec2::new(-1.0, 0.0) }, col);
            }
        }
    }
}

fn arrow(p: &egui::Painter, tip: Pos2, dir: Vec2, col: Color32) {
    let n = Vec2::new(-dir.y, dir.x);
    let base = tip - dir * 5.0;
    p.add(egui::Shape::convex_polygon(vec![tip, base + n * 3.0, base - n * 3.0], col, Stroke::NONE));
}

// ---------------- timeline band ----------------

fn timeline_band(app: &mut PlanApp, ui: &mut egui::Ui, rect: Rect) {
    let p = ui.painter().with_clip_rect(rect);
    p.rect_filled(rect, 0.0, Color32::from_rgb(0xF7, 0xF9, 0xFB));
    p.line_segment([rect.left_bottom(), rect.right_bottom()], Stroke::new(1.0, Color32::from_gray(200)));
    p.text(rect.left_top() + Vec2::new(8.0, 10.0), Align2::LEFT_CENTER, "TIMELINE", FontId::proportional(10.0), Color32::from_gray(120));
    let start = app.p.first_start();
    let finish = app.p.finish().max(start + Duration::days(1));
    let bar = Rect::from_min_max(Pos2::new(rect.left() + 110.0, rect.top() + 24.0), Pos2::new(rect.right() - 110.0, rect.top() + 46.0));
    let span = (finish - start).num_minutes().max(1) as f32;
    let xof = |d: NaiveDateTime| bar.left() + (d - start).num_minutes() as f32 / span * bar.width();
    p.rect_filled(bar, 3.0, Color32::from_rgb(0xE4, 0xEA, 0xF2));
    // month ticks
    let mut d = NaiveDate::from_ymd_opt(start.year(), start.month(), 1).unwrap();
    while d.and_hms_opt(0, 0, 0).unwrap() <= finish {
        let x = xof(d.and_hms_opt(0, 0, 0).unwrap());
        if x >= bar.left() {
            p.line_segment([Pos2::new(x, bar.top()), Pos2::new(x, bar.bottom())], Stroke::new(1.0, Color32::from_gray(205)));
            p.text(Pos2::new(x + 3.0, bar.top() + 5.0), Align2::LEFT_CENTER, d.format("%b").to_string(), FontId::proportional(9.5), Color32::from_gray(120));
        }
        d = if d.month() == 12 { NaiveDate::from_ymd_opt(d.year() + 1, 1, 1).unwrap() } else { NaiveDate::from_ymd_opt(d.year(), d.month() + 1, 1).unwrap() };
    }
    p.text(Pos2::new(bar.left() - 8.0, bar.center().y - 6.0), Align2::RIGHT_CENTER, "Start", FontId::proportional(10.0), Color32::from_gray(110));
    p.text(Pos2::new(bar.left() - 8.0, bar.center().y + 7.0), Align2::RIGHT_CENTER, start.format("%a %-m/%-d/%y").to_string(), FontId::proportional(11.0), Color32::from_gray(40));
    p.text(Pos2::new(bar.right() + 8.0, bar.center().y - 6.0), Align2::LEFT_CENTER, "Finish", FontId::proportional(10.0), Color32::from_gray(110));
    p.text(Pos2::new(bar.right() + 8.0, bar.center().y + 7.0), Align2::LEFT_CENTER, finish.format("%a %-m/%-d/%y").to_string(), FontId::proportional(11.0), Color32::from_gray(40));
    let palette = [
        Color32::from_rgb(0x7F, 0xA8, 0xE0),
        Color32::from_rgb(0x8F, 0xCB, 0x9B),
        Color32::from_rgb(0xF2, 0xC0, 0x7A),
        Color32::from_rgb(0xC3, 0xA6, 0xE3),
        Color32::from_rgb(0x88, 0xD0, 0xD8),
    ];
    let mut k = 0;
    let mut any = false;
    for t in app.p.tasks.iter().filter(|t| t.on_timeline) {
        any = true;
        if t.is_milestone() {
            let x = xof(t.start);
            diamond(&p, Pos2::new(x, bar.top() - 1.0), 5.0, Color32::from_gray(40));
            p.text(Pos2::new(x, rect.top() + 9.0), Align2::CENTER_CENTER, format!("{} {}", t.name, t.start.format("%-m/%-d")), FontId::proportional(10.0), Color32::from_gray(40));
        } else {
            let r = Rect::from_min_max(Pos2::new(xof(t.start), bar.top() + 1.0), Pos2::new(xof(t.finish).max(xof(t.start) + 2.0), bar.bottom() - 1.0));
            p.rect_filled(r, 2.0, palette[k % palette.len()]);
            let tc = p.with_clip_rect(r.intersect(rect));
            tc.text(r.left_center() + Vec2::new(4.0, 0.0), Align2::LEFT_CENTER, &t.name, FontId::proportional(10.5), Color32::from_gray(25));
            k += 1;
        }
    }
    if !any {
        p.text(bar.center(), Align2::CENTER_CENTER, "Add tasks with Task ▸ Add to Timeline", FontId::proportional(10.5), Color32::from_gray(140));
    }
    let today = PlanApp::today();
    if today >= start && today <= finish {
        let x = xof(today);
        p.line_segment([Pos2::new(x, bar.top() - 3.0), Pos2::new(x, bar.bottom() + 3.0)], Stroke::new(1.5, Color32::from_rgb(0xE0, 0x8E, 0x3A)));
        p.text(Pos2::new(x, bar.bottom() + 9.0), Align2::CENTER_CENTER, "Today", FontId::proportional(9.5), Color32::from_rgb(0xC0, 0x70, 0x20));
    }
    let resp = ui.interact(rect, ui.scope_id().with("timeline"), Sense::click());
    resp.context_menu(|ui| {
        if ui.button("Add selected tasks to the timeline").clicked() {
            app.toggle_timeline_for_selected();
            ui.close();
        }
        if ui.button("Hide the timeline").clicked() {
            app.show_timeline = false;
            ui.close();
        }
    });
}
