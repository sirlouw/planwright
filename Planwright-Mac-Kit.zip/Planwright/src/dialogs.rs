//! Dialog windows: Task Information, Resource Information, Assign Resources,
//! Project Information, Change Working Time, Statistics, Baseline, Options,
//! Find, About and messages.

use crate::app::*;
use crate::calendar::{Exception, WorkCalendar};
use crate::model::*;
use chrono::{NaiveDate, NaiveDateTime};
use eframe::egui::{self, Color32, RichText};

#[derive(Default)]
pub struct Dialogs {
    pub task: Option<TaskDraft>,
    pub resource: Option<Resource>,
    pub assign: bool,
    pub assign_units: std::collections::HashMap<u32, String>,
    pub project: Option<ProjectDraft>,
    pub working: Option<WorkingDraft>,
    pub stats: bool,
    pub baseline: Option<(bool, bool)>, // (set?, selected only?)
    pub options: Option<OptionsDraft>,
    pub find: Option<String>,
    pub about: bool,
    pub message: Option<(String, String)>,
    pub link_target: Option<usize>,
    pub close_tab: Option<usize>,
    pub quit: bool,
}

#[derive(Clone)]
pub struct TaskDraft {
    pub uid: u32,
    pub tab: usize,
    pub name: String,
    pub percent: f64,
    pub priority: u32,
    pub manual: bool,
    pub active: bool,
    pub summary: bool,
    pub dur_text: String,
    pub start_text: String,
    pub finish_text: String,
    pub constraint: Constraint,
    pub constraint_text: String,
    pub deadline_text: String,
    pub milestone: bool,
    pub links: Vec<(String, LinkKind, String)>, // (pred id, type, lag)
    pub assign: Vec<(String, String)>,        // (resource name, units %)
    pub notes: String,
    pub fixed_cost: String,
    pub on_timeline: bool,
    pub error: Option<String>,
}

impl TaskDraft {
    pub fn from(p: &Project, i: usize) -> Self {
        let t = &p.tasks[i];
        TaskDraft {
            uid: t.uid,
            tab: 0,
            name: t.name.clone(),
            percent: t.percent,
            priority: t.priority,
            manual: t.manual,
            active: t.active,
            summary: t.calc.summary,
            dur_text: p.fmt_duration(t.dur, t.estimated),
            start_text: t.start.format("%m/%d/%y").to_string(),
            finish_text: t.finish.format("%m/%d/%y").to_string(),
            constraint: t.constraint,
            constraint_text: t.constraint_date.map(|d| d.format("%m/%d/%y").to_string()).unwrap_or("NA".into()),
            deadline_text: t.deadline.map(|d| d.format("%m/%d/%y").to_string()).unwrap_or("NA".into()),
            milestone: t.milestone_flag || (t.dur == 0 && !t.calc.summary),
            links: t
                .links
                .iter()
                .filter_map(|l| {
                    let pi = p.index_of(l.pred)?;
                    Some((p.tasks[pi].calc.id.to_string(), l.kind, if l.lag == 0 { "0d".to_string() } else { p.fmt_lag(l.lag).trim_start_matches('+').to_string() }))
                })
                .collect(),
            assign: t
                .assign
                .iter()
                .filter_map(|a| {
                    let r = &p.resources[p.res_index(a.res)?];
                    Some((r.name.clone(), fmt_num(a.units * 100.0)))
                })
                .collect(),
            notes: t.notes.clone(),
            fixed_cost: fmt_num(t.fixed_cost),
            on_timeline: t.on_timeline,
            error: None,
        }
    }
}

#[derive(Clone)]
pub struct ProjectDraft {
    pub title: String,
    pub manager: String,
    pub company: String,
    pub start: String,
    pub status: String,
    pub calendar: String,
    pub notes: String,
    pub error: Option<String>,
}

impl ProjectDraft {
    pub fn from(p: &Project) -> Self {
        ProjectDraft {
            title: p.title.clone(),
            manager: p.manager.clone(),
            company: p.company.clone(),
            start: p.start.format("%m/%d/%y").to_string(),
            status: p.status_date.map(|d| d.format("%m/%d/%y").to_string()).unwrap_or("NA".into()),
            calendar: p.calendar.name.clone(),
            notes: p.notes.clone(),
            error: None,
        }
    }
}

#[derive(Clone)]
pub struct WorkingDraft {
    pub cal: WorkCalendar,
    pub hours: [String; 7],
    pub ex_name: String,
    pub ex_from: String,
    pub ex_to: String,
    pub error: Option<String>,
}

fn fmt_hours(iv: &[(u32, u32)]) -> String {
    iv.iter()
        .map(|(s, e)| format!("{:02}:{:02}-{:02}:{:02}", s / 60, s % 60, e / 60, e % 60))
        .collect::<Vec<_>>()
        .join(", ")
}

fn parse_hours(s: &str) -> Result<Vec<(u32, u32)>, String> {
    let mut out = vec![];
    for part in s.split(',') {
        let p = part.trim();
        if p.is_empty() {
            continue;
        }
        let (a, b) = p.split_once('-').ok_or(format!("'{p}' should look like 08:00-12:00"))?;
        let pm = |x: &str| -> Result<u32, String> {
            let x = x.trim();
            let (h, m) = x.split_once(':').unwrap_or((x, "0"));
            let h: u32 = h.trim().parse().map_err(|_| format!("bad time '{x}'"))?;
            let m: u32 = m.trim().parse().map_err(|_| format!("bad time '{x}'"))?;
            if h > 24 || m > 59 {
                return Err(format!("bad time '{x}'"));
            }
            Ok(h * 60 + m)
        };
        let (s, e) = (pm(a)?, pm(b)?);
        if e <= s {
            return Err(format!("'{p}' ends before it starts"));
        }
        out.push((s, e));
    }
    out.sort();
    Ok(out)
}

impl WorkingDraft {
    pub fn from(p: &Project) -> Self {
        let cal = p.calendar.clone();
        let hours = std::array::from_fn(|k| fmt_hours(&cal.week[k]));
        WorkingDraft { cal, hours, ex_name: "Holiday".into(), ex_from: String::new(), ex_to: String::new(), error: None }
    }
}

#[derive(Clone)]
pub struct OptionsDraft {
    pub hours_per_day: f64,
    pub hours_per_week: f64,
    pub days_per_month: i64,
    pub critical_slack_days: i64,
    pub new_manual: bool,
    pub currency: String,
}

impl OptionsDraft {
    pub fn from(p: &Project) -> Self {
        OptionsDraft {
            hours_per_day: p.minutes_per_day as f64 / 60.0,
            hours_per_week: p.minutes_per_week as f64 / 60.0,
            days_per_month: p.days_per_month,
            critical_slack_days: p.critical_slack_days,
            new_manual: p.new_tasks_manual,
            currency: p.currency.clone(),
        }
    }
}

fn date_or_na(s: &str) -> Result<Option<NaiveDate>, String> {
    let t = s.trim();
    if t.is_empty() || t.eq_ignore_ascii_case("na") {
        return Ok(None);
    }
    parse_date(t).map(Some).ok_or(format!("'{t}' isn't a date (try 11/30/26)"))
}

fn apply_task(app: &mut PlanApp, d: &TaskDraft) -> Result<(), String> {
    let Some(i) = app.p.index_of(d.uid) else { return Ok(()) };
    let before = app.p.clone();
    let cal = app.p.calendar.clone();
    let res = (|| -> Result<(), String> {
        let summary = app.p.tasks[i].calc.summary;
        // predecessors
        let mut links = vec![];
        for (id, kind, lag) in &d.links {
            if id.trim().is_empty() {
                continue;
            }
            let id: usize = id.trim().parse().map_err(|_| format!("'{id}' isn't a task ID"))?;
            let pred = app.p.tasks.iter().find(|t| t.calc.id == id).ok_or(format!("There is no task {id}"))?;
            if pred.uid == d.uid {
                return Err("A task can't be its own predecessor".into());
            }
            let lag_m = if lag.trim().is_empty() { 0 } else { app.p.parse_duration(lag).ok_or(format!("Can't read the lag '{lag}'"))?.0 };
            links.push(Link { pred: pred.uid, kind: *kind, lag: lag_m });
        }
        // resources
        let mut assign = vec![];
        for (name, units) in &d.assign {
            if name.trim().is_empty() {
                continue;
            }
            let u: f64 = units.trim().trim_end_matches('%').replace(',', ".").parse().unwrap_or(100.0);
            let mut a = app.p.parse_resources(name.trim());
            if let Some(x) = a.pop() {
                let kind = app.p.res_index(x.res).map(|k| app.p.resources[k].kind).unwrap_or(ResKind::Work);
                assign.push(Assignment { res: x.res, units: if kind == ResKind::Work { u / 100.0 } else { u } });
            }
        }
        let (dur, est) = if summary { (app.p.tasks[i].dur, false) } else { app.p.parse_duration(&d.dur_text).ok_or("Type a duration like 3d, 4h or 2w")? };
        let start = date_or_na(&d.start_text)?;
        let cdate = date_or_na(&d.constraint_text)?;
        let deadline = date_or_na(&d.deadline_text)?;
        if d.constraint.needs_date() && cdate.is_none() {
            return Err(format!("'{}' needs a constraint date", d.constraint.label()));
        }
        let fixed_cost: f64 = d.fixed_cost.trim().replace(',', ".").parse().unwrap_or(0.0);
        let t = &mut app.p.tasks[i];
        let start_changed = start.map(|s| s != t.start.date()).unwrap_or(false);
        t.name = d.name.clone();
        t.percent = d.percent.clamp(0.0, 100.0);
        t.priority = d.priority.min(1000);
        t.manual = d.manual && !summary;
        t.active = d.active;
        t.links = links;
        t.assign = assign;
        t.notes = d.notes.clone();
        t.fixed_cost = fixed_cost;
        t.on_timeline = d.on_timeline;
        t.deadline = deadline;
        if !summary {
            t.dur = if d.milestone && dur > 0 && !t.milestone_flag { 0 } else { dur };
            t.milestone_flag = d.milestone && t.dur > 0;
            t.estimated = est;
        }
        t.constraint = d.constraint;
        t.constraint_date = cdate.map(|c| if d.constraint.is_finish() { cal.day_finish(c) } else { cal.day_start(c) });
        if start_changed && !summary {
            let s = cal.day_start(start.unwrap());
            if t.manual {
                t.start = s;
            } else if !d.constraint.needs_date() || d.constraint == Constraint::SNET {
                t.constraint = Constraint::SNET;
                t.constraint_date = Some(s);
            }
        }
        Ok(())
    })();
    match res {
        Ok(()) => {
            app.undo.push(before);
            app.redo.clear();
            app.dirty = true;
            app.recalc();
            Ok(())
        }
        Err(e) => {
            app.p = before;
            Err(e)
        }
    }
}

fn modal<R>(ctx: &egui::Context, title: &str, open: &mut bool, width: f32, add: impl FnOnce(&mut egui::Ui) -> R) -> Option<R> {
    egui::Window::new(title)
        .open(open)
        .collapsible(false)
        .resizable(false)
        .default_width(width)
        .anchor(egui::Align2::CENTER_CENTER, egui::Vec2::ZERO)
        .show(ctx, add)
        .and_then(|r| r.inner)
}

fn buttons(ui: &mut egui::Ui) -> (bool, bool) {
    let mut ok = false;
    let mut cancel = false;
    ui.add_space(6.0);
    ui.separator();
    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
        if ui.button("Cancel").clicked() {
            cancel = true;
        }
        if ui.add(egui::Button::new(RichText::new("   OK   ").color(Color32::WHITE)).fill(ACCENT)).clicked() {
            ok = true;
        }
    });
    (ok, cancel)
}

pub fn show_dialogs(app: &mut PlanApp, ctx: &egui::Context) {
    task_info(app, ctx);
    resource_info(app, ctx);
    assign_dialog(app, ctx);
    project_info(app, ctx);
    working_time(app, ctx);
    stats(app, ctx);
    baseline(app, ctx);
    options(app, ctx);
    find(app, ctx);
    about(app, ctx);
    message(app, ctx);
}

fn task_info(app: &mut PlanApp, ctx: &egui::Context) {
    let Some(mut d) = app.dlg.task.take() else { return };
    let mut open = true;
    let mut result = (false, false);
    let names: Vec<String> = app.p.resources.iter().map(|r| r.name.clone()).collect();
    let task_names: Vec<(usize, String)> = app.p.tasks.iter().map(|t| (t.calc.id, t.name.clone())).collect();
    modal(ctx, "Task Information", &mut open, 560.0, |ui| {
        ui.horizontal(|ui| {
            for (k, t) in ["General", "Predecessors", "Resources", "Advanced", "Notes"].iter().enumerate() {
                ui.selectable_value(&mut d.tab, k, *t);
            }
        });
        ui.separator();
        ui.horizontal(|ui| {
            ui.label("Name:");
            ui.add(egui::TextEdit::singleline(&mut d.name).desired_width(300.0));
            ui.label("Duration:");
            ui.add_enabled(!d.summary, egui::TextEdit::singleline(&mut d.dur_text).desired_width(80.0));
        });
        ui.add_space(6.0);
        match d.tab {
            0 => {
                egui::Grid::new("ti_gen").num_columns(4).spacing([12.0, 8.0]).show(ui, |ui| {
                    ui.label("Percent complete:");
                    ui.add_enabled(!d.summary, egui::DragValue::new(&mut d.percent).range(0.0..=100.0).suffix("%").speed(1.0));
                    ui.label("Priority:");
                    ui.add(egui::DragValue::new(&mut d.priority).range(0..=1000));
                    ui.end_row();
                    ui.label("Schedule mode:");
                    ui.add_enabled_ui(!d.summary, |ui| {
                        ui.horizontal(|ui| {
                            ui.radio_value(&mut d.manual, true, "Manually");
                            ui.radio_value(&mut d.manual, false, "Auto");
                        });
                    });
                    ui.checkbox(&mut d.active, "Active");
                    ui.checkbox(&mut d.on_timeline, "Show on Timeline");
                    ui.end_row();
                    ui.label("Start:");
                    ui.add_enabled(!d.summary, egui::TextEdit::singleline(&mut d.start_text).desired_width(100.0));
                    ui.label("Finish:");
                    ui.add_enabled(false, egui::TextEdit::singleline(&mut d.finish_text).desired_width(100.0));
                    ui.end_row();
                });
                if !d.manual && !d.summary {
                    ui.label(RichText::new("Changing the start of an auto-scheduled task sets a 'Start No Earlier Than' constraint.").small().weak());
                }
            }
            1 => {
                egui::Grid::new("ti_preds").num_columns(4).striped(true).spacing([10.0, 4.0]).show(ui, |ui| {
                    ui.strong("ID");
                    ui.strong("Task Name");
                    ui.strong("Type");
                    ui.strong("Lag");
                    ui.end_row();
                    let mut remove = None;
                    for (k, (id, kind, lag)) in d.links.iter_mut().enumerate() {
                        ui.add(egui::TextEdit::singleline(id).desired_width(36.0));
                        let nm = id.trim().parse::<usize>().ok().and_then(|n| task_names.iter().find(|(i, _)| *i == n)).map(|(_, s)| s.clone()).unwrap_or_default();
                        ui.label(nm);
                        egui::ComboBox::from_id_salt(("lk", k)).selected_text(kind.label()).width(170.0).show_ui(ui, |ui| {
                            for lk in LinkKind::ALL {
                                ui.selectable_value(kind, lk, lk.label());
                            }
                        });
                        ui.horizontal(|ui| {
                            ui.add(egui::TextEdit::singleline(lag).desired_width(60.0));
                            if ui.small_button("✖").clicked() {
                                remove = Some(k);
                            }
                        });
                        ui.end_row();
                    }
                    if let Some(k) = remove {
                        d.links.remove(k);
                    }
                });
                if ui.button("➕ Add predecessor").clicked() {
                    d.links.push((String::new(), LinkKind::FS, "0d".into()));
                }
                ui.label(RichText::new("Lag can be negative (lead), e.g. -2d.").small().weak());
            }
            2 => {
                egui::Grid::new("ti_res").num_columns(2).striped(true).spacing([10.0, 4.0]).show(ui, |ui| {
                    ui.strong("Resource Name");
                    ui.strong("Units");
                    ui.end_row();
                    let mut remove = None;
                    for (k, (name, units)) in d.assign.iter_mut().enumerate() {
                        egui::ComboBox::from_id_salt(("rn", k)).selected_text(name.clone()).width(220.0).show_ui(ui, |ui| {
                            for n in &names {
                                ui.selectable_value(name, n.clone(), n);
                            }
                        });
                        ui.horizontal(|ui| {
                            ui.add(egui::TextEdit::singleline(units).desired_width(60.0));
                            ui.label("%");
                            if ui.small_button("✖").clicked() {
                                remove = Some(k);
                            }
                        });
                        ui.end_row();
                    }
                    if let Some(k) = remove {
                        d.assign.remove(k);
                    }
                });
                ui.horizontal(|ui| {
                    if ui.button("➕ Add resource").clicked() {
                        let n = names.iter().find(|n| !d.assign.iter().any(|(a, _)| a == *n)).cloned().unwrap_or_else(|| "New Resource".into());
                        d.assign.push((n, "100".into()));
                    }
                    ui.label(RichText::new("For material resources the number is a quantity.").small().weak());
                });
            }
            3 => {
                egui::Grid::new("ti_adv").num_columns(2).spacing([12.0, 8.0]).show(ui, |ui| {
                    ui.label("Deadline:");
                    ui.add(egui::TextEdit::singleline(&mut d.deadline_text).desired_width(100.0));
                    ui.end_row();
                    ui.label("Constraint type:");
                    egui::ComboBox::from_id_salt("ctype").selected_text(d.constraint.label()).width(200.0).show_ui(ui, |ui| {
                        for c in Constraint::ALL {
                            ui.selectable_value(&mut d.constraint, c, c.label());
                        }
                    });
                    ui.end_row();
                    ui.label("Constraint date:");
                    ui.add_enabled(d.constraint.needs_date(), egui::TextEdit::singleline(&mut d.constraint_text).desired_width(100.0));
                    ui.end_row();
                    ui.label("Fixed cost:");
                    ui.add(egui::TextEdit::singleline(&mut d.fixed_cost).desired_width(100.0));
                    ui.end_row();
                    ui.label("");
                    ui.add_enabled(!d.summary, egui::Checkbox::new(&mut d.milestone, "Mark task as milestone"));
                    ui.end_row();
                });
            }
            _ => {
                ui.add(egui::TextEdit::multiline(&mut d.notes).desired_rows(10).desired_width(f32::INFINITY));
            }
        }
        if let Some(e) = &d.error {
            ui.colored_label(Color32::from_rgb(0xC0, 0, 0), e);
        }
        result = buttons(ui);
    });
    if result.0 {
        match apply_task(app, &d) {
            Ok(()) => return,
            Err(e) => d.error = Some(e),
        }
    }
    if open && !result.1 {
        app.dlg.task = Some(d);
    }
}

fn resource_info(app: &mut PlanApp, ctx: &egui::Context) {
    let Some(mut r) = app.dlg.resource.take() else { return };
    let mut open = true;
    let mut result = (false, false);
    let cur = app.p.currency.clone();
    modal(ctx, "Resource Information", &mut open, 440.0, |ui| {
        egui::Grid::new("ri").num_columns(2).spacing([12.0, 8.0]).show(ui, |ui| {
            ui.label("Resource name:");
            ui.text_edit_singleline(&mut r.name);
            ui.end_row();
            ui.label("Email:");
            ui.text_edit_singleline(&mut r.email);
            ui.end_row();
            ui.label("Initials:");
            ui.text_edit_singleline(&mut r.initials);
            ui.end_row();
            ui.label("Group:");
            ui.text_edit_singleline(&mut r.group);
            ui.end_row();
            ui.label("Type:");
            ui.horizontal(|ui| {
                ui.radio_value(&mut r.kind, ResKind::Work, "Work");
                ui.radio_value(&mut r.kind, ResKind::Material, "Material");
                ui.radio_value(&mut r.kind, ResKind::Cost, "Cost");
            });
            ui.end_row();
            if r.kind == ResKind::Material {
                ui.label("Material label:");
                ui.text_edit_singleline(&mut r.material_label);
                ui.end_row();
            }
            if r.kind == ResKind::Work {
                ui.label("Max. units:");
                let mut pct = r.max_units * 100.0;
                if ui.add(egui::DragValue::new(&mut pct).range(0.0..=10000.0).suffix("%")).changed() {
                    r.max_units = pct / 100.0;
                }
                ui.end_row();
            }
            ui.label("Standard rate:");
            ui.add(egui::DragValue::new(&mut r.std_rate).range(0.0..=1e9).prefix(cur.clone()).speed(0.5));
            ui.end_row();
            ui.label("Overtime rate:");
            ui.add(egui::DragValue::new(&mut r.ovt_rate).range(0.0..=1e9).prefix(cur.clone()).speed(0.5));
            ui.end_row();
            ui.label("Cost/use:");
            ui.add(egui::DragValue::new(&mut r.cost_per_use).range(0.0..=1e9).prefix(cur.clone()).speed(0.5));
            ui.end_row();
            ui.label("Accrue at:");
            ui.horizontal(|ui| {
                ui.radio_value(&mut r.accrue, Accrue::Start, "Start");
                ui.radio_value(&mut r.accrue, Accrue::Prorated, "Prorated");
                ui.radio_value(&mut r.accrue, Accrue::End, "End");
            });
            ui.end_row();
            ui.label("Notes:");
            ui.add(egui::TextEdit::multiline(&mut r.notes).desired_rows(3));
            ui.end_row();
        });
        result = buttons(ui);
    });
    if result.0 {
        if let Some(k) = app.p.res_index(r.uid) {
            app.checkpoint();
            let calc = app.p.resources[k].calc.clone();
            app.p.resources[k] = Resource { calc, ..r };
            app.recalc();
        }
        return;
    }
    if open && !result.1 {
        app.dlg.resource = Some(r);
    }
}

fn assign_dialog(app: &mut PlanApp, ctx: &egui::Context) {
    if !app.dlg.assign {
        return;
    }
    let mut open = true;
    let idx = app.selected_indices();
    let task_label = match idx.len() {
        0 => "No task selected".to_string(),
        1 => format!("Task: {}", app.p.tasks[idx[0]].name),
        n => format!("{n} tasks selected"),
    };
    let mut action: Option<(u32, bool, f64)> = None;
    let mut add_name: Option<String> = None;
    let res: Vec<(u32, String, ResKind, bool)> = app
        .p
        .resources
        .iter()
        .map(|r| (r.uid, r.name.clone(), r.kind, idx.iter().all(|&i| app.p.tasks[i].assign.iter().any(|a| a.res == r.uid)) && !idx.is_empty()))
        .collect();
    egui::Window::new("Assign Resources").open(&mut open).collapsible(false).resizable(false).default_width(420.0).show(ctx, |ui| {
        ui.label(RichText::new(&task_label).strong());
        ui.add_space(4.0);
        egui::ScrollArea::vertical().max_height(260.0).show(ui, |ui| {
            egui::Grid::new("asg").num_columns(4).striped(true).spacing([10.0, 4.0]).show(ui, |ui| {
                ui.strong("");
                ui.strong("Resource Name");
                ui.strong("Units");
                ui.strong("");
                ui.end_row();
                for (uid, name, kind, assigned) in &res {
                    ui.label(if *assigned { "✔" } else { "" });
                    ui.label(name);
                    let e = app.dlg.assign_units.entry(*uid).or_insert_with(|| if *kind == ResKind::Work { "100%".into() } else { "1".into() });
                    ui.add(egui::TextEdit::singleline(e).desired_width(56.0));
                    let units = {
                        let v: f64 = e.trim().trim_end_matches('%').replace(',', ".").parse().unwrap_or(100.0);
                        if *kind == ResKind::Work { v / 100.0 } else { v }
                    };
                    ui.horizontal(|ui| {
                        if ui.add_enabled(!idx.is_empty(), egui::Button::new("Assign")).clicked() {
                            action = Some((*uid, true, units));
                        }
                        if ui.add_enabled(*assigned, egui::Button::new("Remove")).clicked() {
                            action = Some((*uid, false, 0.0));
                        }
                    });
                    ui.end_row();
                }
            });
        });
        ui.separator();
        ui.horizontal(|ui| {
            let id = ui.scope_id().with("newres");
            let mut name: String = ui.data_mut(|d| d.get_temp(id)).unwrap_or_default();
            let r = ui.add(egui::TextEdit::singleline(&mut name).hint_text("New resource name").desired_width(200.0));
            if r.changed() {
                ui.data_mut(|d| d.insert_temp(id, name.clone()));
            }
            if ui.button("➕ Add").clicked() && !name.trim().is_empty() {
                add_name = Some(name.trim().to_string());
                ui.data_mut(|d| d.insert_temp(id, String::new()));
            }
        });
    });
    if let Some(n) = add_name {
        app.checkpoint();
        let uid = app.p.alloc_res_uid();
        app.p.resources.push(Resource::new(uid, &n));
        app.recalc();
    }
    if let Some((uid, assign, units)) = action {
        app.checkpoint();
        for i in idx {
            if app.p.tasks[i].calc.summary {
                continue;
            }
            let t = &mut app.p.tasks[i];
            t.assign.retain(|a| a.res != uid);
            if assign {
                t.assign.push(Assignment { res: uid, units });
            }
        }
        app.recalc();
    }
    app.dlg.assign = open;
}

fn project_info(app: &mut PlanApp, ctx: &egui::Context) {
    let Some(mut d) = app.dlg.project.take() else { return };
    let mut open = true;
    let mut result = (false, false);
    let mut want_stats = false;
    let finish = app.p.finish();
    modal(ctx, "Project Information", &mut open, 460.0, |ui| {
        egui::Grid::new("pi").num_columns(2).spacing([12.0, 8.0]).show(ui, |ui| {
            ui.label("Title:");
            ui.text_edit_singleline(&mut d.title);
            ui.end_row();
            ui.label("Manager:");
            ui.text_edit_singleline(&mut d.manager);
            ui.end_row();
            ui.label("Company:");
            ui.text_edit_singleline(&mut d.company);
            ui.end_row();
            ui.label("Start date:");
            ui.add(egui::TextEdit::singleline(&mut d.start).desired_width(100.0));
            ui.end_row();
            ui.label("Finish date:");
            ui.label(fmt_date(finish));
            ui.end_row();
            ui.label("Status date:");
            ui.add(egui::TextEdit::singleline(&mut d.status).desired_width(100.0));
            ui.end_row();
            ui.label("Calendar:");
            egui::ComboBox::from_id_salt("pcal").selected_text(d.calendar.clone()).show_ui(ui, |ui| {
                for n in ["Standard", "24 Hours", "Night Shift"] {
                    ui.selectable_value(&mut d.calendar, n.to_string(), n);
                }
            });
            ui.end_row();
            ui.label("Schedule from:");
            ui.label("Project Start Date");
            ui.end_row();
            ui.label("Notes:");
            ui.add(egui::TextEdit::multiline(&mut d.notes).desired_rows(3));
            ui.end_row();
        });
        if let Some(e) = &d.error {
            ui.colored_label(Color32::from_rgb(0xC0, 0, 0), e);
        }
        if ui.button("📈 Statistics…").clicked() {
            want_stats = true;
        }
        result = buttons(ui);
    });
    if want_stats {
        app.dlg.stats = true;
    }
    if result.0 {
        let start = parse_date(&d.start);
        let status = date_or_na(&d.status);
        match (start, status) {
            (None, _) => d.error = Some("Type the start date like 11/30/26".into()),
            (_, Err(e)) => d.error = Some(e),
            (Some(s), Ok(st)) => {
                app.checkpoint();
                app.p.title = d.title.clone();
                app.p.manager = d.manager.clone();
                app.p.company = d.company.clone();
                app.p.notes = d.notes.clone();
                app.p.status_date = st;
                if d.calendar != app.p.calendar.name {
                    let ex = app.p.calendar.exceptions.clone();
                    app.p.calendar = match d.calendar.as_str() {
                        "24 Hours" => WorkCalendar::twenty_four_hours(),
                        "Night Shift" => WorkCalendar::night_shift(),
                        _ => WorkCalendar::standard(),
                    };
                    app.p.calendar.exceptions = ex;
                }
                app.p.start = app.p.calendar.day_start(s);
                app.recalc();
                return;
            }
        }
    }
    if open && !result.1 {
        app.dlg.project = Some(d);
    }
}

fn working_time(app: &mut PlanApp, ctx: &egui::Context) {
    let Some(mut d) = app.dlg.working.take() else { return };
    let mut open = true;
    let mut result = (false, false);
    modal(ctx, "Change Working Time", &mut open, 520.0, |ui| {
        ui.label(RichText::new(format!("Calendar: {}", d.cal.name)).strong());
        ui.add_space(4.0);
        ui.label("Work weeks - working hours for each day (empty = non-working):");
        egui::Grid::new("wt").num_columns(2).spacing([12.0, 6.0]).show(ui, |ui| {
            for (k, day) in ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"].iter().enumerate() {
                ui.label(*day);
                ui.horizontal(|ui| {
                    ui.add(egui::TextEdit::singleline(&mut d.hours[k]).desired_width(220.0).hint_text("Non-working"));
                    if ui.small_button("Working").on_hover_text("08:00-12:00, 13:00-17:00").clicked() {
                        d.hours[k] = "08:00-12:00, 13:00-17:00".into();
                    }
                    if ui.small_button("Off").clicked() {
                        d.hours[k].clear();
                    }
                });
                ui.end_row();
            }
        });
        ui.add_space(8.0);
        ui.label(RichText::new("Exceptions (days off)").strong());
        let mut remove = None;
        egui::Grid::new("exc").num_columns(4).striped(true).show(ui, |ui| {
            for (k, e) in d.cal.exceptions.iter().enumerate() {
                ui.label(&e.name);
                ui.label(e.from.format("%a %m/%d/%y").to_string());
                ui.label(e.to.format("%a %m/%d/%y").to_string());
                if ui.small_button("✖").clicked() {
                    remove = Some(k);
                }
                ui.end_row();
            }
        });
        if let Some(k) = remove {
            d.cal.exceptions.remove(k);
        }
        ui.horizontal(|ui| {
            ui.add(egui::TextEdit::singleline(&mut d.ex_name).desired_width(110.0));
            ui.add(egui::TextEdit::singleline(&mut d.ex_from).hint_text("from 12/24/26").desired_width(90.0));
            ui.add(egui::TextEdit::singleline(&mut d.ex_to).hint_text("to (optional)").desired_width(90.0));
            if ui.button("➕ Add").clicked() {
                match parse_date(&d.ex_from) {
                    Some(f) => {
                        let t = parse_date(&d.ex_to).unwrap_or(f).max(f);
                        d.cal.exceptions.push(Exception { name: d.ex_name.clone(), from: f, to: t });
                        d.ex_from.clear();
                        d.ex_to.clear();
                        d.error = None;
                    }
                    None => d.error = Some("Type the exception's first day like 12/24/26".into()),
                }
            }
        });
        if let Some(e) = &d.error {
            ui.colored_label(Color32::from_rgb(0xC0, 0, 0), e);
        }
        result = buttons(ui);
    });
    if result.0 {
        let mut week: [Vec<(u32, u32)>; 7] = Default::default();
        let mut err = None;
        for k in 0..7 {
            match parse_hours(&d.hours[k]) {
                Ok(v) => week[k] = v,
                Err(e) => err = Some(e),
            }
        }
        if week.iter().all(|w| w.is_empty()) {
            err = Some("At least one day must have working time".into());
        }
        match err {
            Some(e) => d.error = Some(e),
            None => {
                app.checkpoint();
                d.cal.week = week;
                app.p.calendar = d.cal.clone();
                app.p.start = app.p.calendar.next_work_start(app.p.start);
                app.recalc();
                return;
            }
        }
    }
    if open && !result.1 {
        app.dlg.working = Some(d);
    }
}

fn stats(app: &mut PlanApp, ctx: &egui::Context) {
    if !app.dlg.stats {
        return;
    }
    let mut open = true;
    let p = &app.p;
    let leaves: Vec<&Task> = p.tasks.iter().filter(|t| !t.calc.summary).collect();
    let start = p.first_start();
    let finish = p.finish();
    let b_start = leaves.iter().filter_map(|t| t.baseline.as_ref().map(|b| b.start)).min();
    let b_finish = leaves.iter().filter_map(|t| t.baseline.as_ref().map(|b| b.finish)).max();
    let a_start = leaves.iter().filter(|t| t.percent > 0.0).map(|t| t.start).min();
    let a_finish: Option<NaiveDateTime> = if !leaves.is_empty() && leaves.iter().all(|t| t.complete()) { Some(finish) } else { None };
    let dur = p.calendar.work_between(start, finish);
    let total_dur: f64 = leaves.iter().map(|t| t.dur as f64).sum();
    let done_dur: f64 = leaves.iter().map(|t| t.dur as f64 * t.percent / 100.0).sum();
    let pct_dur = if total_dur > 0.0 { done_dur / total_dur * 100.0 } else { 0.0 };
    let work: f64 = leaves.iter().map(|t| t.calc.work_min).sum();
    let done_work: f64 = leaves.iter().map(|t| t.calc.work_min * t.percent / 100.0).sum();
    let pct_work = if work > 0.0 { done_work / work * 100.0 } else { 0.0 };
    let cost: f64 = leaves.iter().map(|t| t.calc.cost).sum();
    let done_cost: f64 = leaves.iter().map(|t| t.calc.cost * t.percent / 100.0).sum();
    let b_cost: f64 = leaves.iter().filter_map(|t| t.baseline.as_ref().map(|b| b.cost)).sum();
    let b_work: f64 = leaves.iter().filter_map(|t| t.baseline.as_ref().map(|b| b.work)).sum();
    let b_dur = match (b_start, b_finish) {
        (Some(s), Some(f)) => Some(p.calendar.work_between(s, f)),
        _ => None,
    };
    let na = || "NA".to_string();
    let title = p.title.clone();
    let critical = leaves.iter().filter(|t| t.calc.critical).count();
    let rows_dates = [
        ("Current", fmt_date(start), fmt_date(finish)),
        ("Baseline", b_start.map(fmt_date).unwrap_or_else(na), b_finish.map(fmt_date).unwrap_or_else(na)),
        ("Actual", a_start.map(fmt_date).unwrap_or_else(na), a_finish.map(fmt_date).unwrap_or_else(na)),
        (
            "Variance",
            b_start.map(|b| p.fmt_duration(p.calendar.work_between(b, start), false)).unwrap_or("0 days".into()),
            b_finish.map(|b| p.fmt_duration(p.calendar.work_between(b, finish), false)).unwrap_or("0 days".into()),
        ),
    ];
    let rows_totals = [
        ("Current", p.fmt_duration(dur, false), fmt_work(work), p.money(cost)),
        ("Baseline", b_dur.map(|d| p.fmt_duration(d, false)).unwrap_or("0 days".into()), fmt_work(b_work), p.money(b_cost)),
        ("Actual", p.fmt_duration((dur as f64 * pct_dur / 100.0) as i64, false), fmt_work(done_work), p.money(done_cost)),
        ("Remaining", p.fmt_duration((dur as f64 * (1.0 - pct_dur / 100.0)) as i64, false), fmt_work(work - done_work), p.money(cost - done_cost)),
    ];
    egui::Window::new(format!("Project Statistics for '{title}'")).open(&mut open).collapsible(false).resizable(false).default_width(520.0).show(ctx, |ui| {
        egui::Grid::new("st1").num_columns(3).striped(true).spacing([30.0, 6.0]).show(ui, |ui| {
            ui.label("");
            ui.strong("Start");
            ui.strong("Finish");
            ui.end_row();
            for (a, b, c) in &rows_dates {
                ui.strong(*a);
                ui.label(b);
                ui.label(c);
                ui.end_row();
            }
        });
        ui.add_space(10.0);
        egui::Grid::new("st2").num_columns(4).striped(true).spacing([30.0, 6.0]).show(ui, |ui| {
            ui.label("");
            ui.strong("Duration");
            ui.strong("Work");
            ui.strong("Cost");
            ui.end_row();
            for (a, b, c, d) in &rows_totals {
                ui.strong(*a);
                ui.label(b);
                ui.label(c);
                ui.label(d);
                ui.end_row();
            }
        });
        ui.add_space(8.0);
        ui.label(format!("Percent complete:   Duration: {}%    Work: {}%", pct_dur.round(), pct_work.round()));
        ui.label(format!("{} tasks, {} on the critical path", leaves.len(), critical));
    });
    app.dlg.stats = open;
}

fn baseline(app: &mut PlanApp, ctx: &egui::Context) {
    let Some((set, mut selected)) = app.dlg.baseline else { return };
    let mut open = true;
    let mut result = (false, false);
    modal(ctx, if set { "Set Baseline" } else { "Clear Baseline" }, &mut open, 360.0, |ui| {
        ui.label(if set { "Save the current dates, work and cost as the baseline for:" } else { "Clear the baseline for:" });
        ui.radio_value(&mut selected, false, "Entire project");
        ui.radio_value(&mut selected, true, "Selected tasks");
        result = buttons(ui);
    });
    if result.0 {
        if set {
            app.set_baseline(selected);
        } else {
            app.clear_baseline(selected);
        }
        app.dlg.baseline = None;
        return;
    }
    app.dlg.baseline = if open && !result.1 { Some((set, selected)) } else { None };
}

fn options(app: &mut PlanApp, ctx: &egui::Context) {
    let Some(mut d) = app.dlg.options.take() else { return };
    let mut open = true;
    let mut result = (false, false);
    modal(ctx, "Options", &mut open, 420.0, |ui| {
        ui.label(RichText::new("Schedule").strong());
        egui::Grid::new("opt").num_columns(2).spacing([12.0, 6.0]).show(ui, |ui| {
            ui.label("New tasks created:");
            ui.horizontal(|ui| {
                ui.radio_value(&mut d.new_manual, false, "Auto Scheduled");
                ui.radio_value(&mut d.new_manual, true, "Manually Scheduled");
            });
            ui.end_row();
            ui.label("Hours per day:");
            ui.add(egui::DragValue::new(&mut d.hours_per_day).range(1.0..=24.0).speed(0.5));
            ui.end_row();
            ui.label("Hours per week:");
            ui.add(egui::DragValue::new(&mut d.hours_per_week).range(1.0..=168.0).speed(1.0));
            ui.end_row();
            ui.label("Days per month:");
            ui.add(egui::DragValue::new(&mut d.days_per_month).range(1..=31));
            ui.end_row();
            ui.label("Tasks are critical if slack ≤");
            ui.add(egui::DragValue::new(&mut d.critical_slack_days).range(0..=100).suffix(" days"));
            ui.end_row();
            ui.label("Currency symbol:");
            ui.add(egui::TextEdit::singleline(&mut d.currency).desired_width(50.0));
            ui.end_row();
        });
        result = buttons(ui);
    });
    if result.0 {
        app.checkpoint();
        app.p.new_tasks_manual = d.new_manual;
        app.p.minutes_per_day = (d.hours_per_day * 60.0).round() as i64;
        app.p.minutes_per_week = (d.hours_per_week * 60.0).round() as i64;
        app.p.days_per_month = d.days_per_month;
        app.p.critical_slack_days = d.critical_slack_days;
        app.p.currency = d.currency.clone();
        app.recalc();
        return;
    }
    if open && !result.1 {
        app.dlg.options = Some(d);
    }
}

fn find(app: &mut PlanApp, ctx: &egui::Context) {
    let Some(mut q) = app.dlg.find.take() else { return };
    let mut open = true;
    let mut go = false;
    egui::Window::new("Find").open(&mut open).collapsible(false).resizable(false).default_width(320.0).show(ctx, |ui| {
        ui.horizontal(|ui| {
            ui.label("Task name contains:");
            let r = ui.text_edit_singleline(&mut q);
            if r.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter)) {
                go = true;
            }
            r.request_focus();
        });
        if ui.button("Find Next").clicked() {
            go = true;
        }
    });
    if go && !q.trim().is_empty() {
        let needle = q.to_lowercase();
        let start = app.selected_indices().first().map(|i| i + 1).unwrap_or(0);
        let n = app.p.tasks.len();
        let hit = (0..n).map(|k| (start + k) % n).find(|&i| app.p.tasks[i].name.to_lowercase().contains(&needle));
        match hit {
            Some(i) => {
                let mut par = app.p.tasks[i].calc.parent;
                while let Some(pi) = par {
                    app.p.tasks[pi].collapsed = false;
                    par = app.p.tasks[pi].calc.parent;
                }
                app.recalc();
                app.sel = vec![app.p.tasks[i].uid];
                app.scroll_to_selected();
                app.status = format!("Found task {}", app.p.tasks[i].calc.id);
            }
            None => app.status = format!("No task matches '{q}'"),
        }
    }
    if open {
        app.dlg.find = Some(q);
    }
}

fn about(app: &mut PlanApp, ctx: &egui::Context) {
    if !app.dlg.about {
        return;
    }
    let mut open = true;
    modal(ctx, "About Planwright", &mut open, 360.0, |ui| {
        ui.heading(RichText::new("Planwright").color(ACCENT));
        ui.label("A desktop project planner: task outline, Gantt chart, links and critical path, resources, baselines and Microsoft Project XML exchange.");
        ui.label(RichText::new(format!("Version {}", env!("CARGO_PKG_VERSION"))).weak());
    });
    app.dlg.about = open;
}

fn message(app: &mut PlanApp, ctx: &egui::Context) {
    let Some((title, text)) = app.dlg.message.clone() else { return };
    let mut open = true;
    let mut ok = false;
    modal(ctx, &title, &mut open, 380.0, |ui| {
        ui.label(&text);
        ui.add_space(6.0);
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            if ui.add(egui::Button::new(RichText::new("   OK   ").color(Color32::WHITE)).fill(ACCENT)).clicked() {
                ok = true;
            }
        });
    });
    if ok || !open {
        app.dlg.message = None;
    }
}
