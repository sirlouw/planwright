//! Resource Sheet, Calendar, Network Diagram and Team Planner views.

use crate::app::*;
use crate::model::*;
use chrono::{Datelike, Duration, NaiveDate};
use eframe::egui::{self, Align2, Color32, FontId, Pos2, Rect, Sense, Stroke, Vec2};

// ---------------- Resource Sheet ----------------

const RES_COLS: [(&str, f32); 14] = [
    ("Resource Name", 170.0),
    ("Type", 70.0),
    ("Material Label", 90.0),
    ("Initials", 60.0),
    ("Group", 90.0),
    ("Max.", 60.0),
    ("Std. Rate", 90.0),
    ("Ovt. Rate", 90.0),
    ("Cost/Use", 80.0),
    ("Accrue At", 76.0),
    ("Base Calendar", 96.0),
    ("Email", 150.0),
    ("Work", 80.0),
    ("Cost", 96.0),
];

fn res_cell(p: &Project, r: &Resource, c: usize) -> String {
    match c {
        0 => r.name.clone(),
        1 => r.kind.label().into(),
        2 => r.material_label.clone(),
        3 => r.initials.clone(),
        4 => r.group.clone(),
        5 => {
            if r.kind == ResKind::Work {
                format!("{}%", fmt_num(r.max_units * 100.0))
            } else {
                String::new()
            }
        }
        6 => match r.kind {
            ResKind::Work => format!("{}/hr", p.money(r.std_rate)),
            ResKind::Material => p.money(r.std_rate),
            ResKind::Cost => String::new(),
        },
        7 => {
            if r.kind == ResKind::Work {
                format!("{}/hr", p.money(r.ovt_rate))
            } else {
                String::new()
            }
        }
        8 => p.money(r.cost_per_use),
        9 => r.accrue.label().into(),
        10 => p.calendar.name.clone(),
        11 => r.email.clone(),
        12 => match r.kind {
            ResKind::Work => fmt_work(r.calc.work_min),
            ResKind::Material => format!("{} {}", fmt_num(r.calc.work_min), r.material_label),
            ResKind::Cost => String::new(),
        },
        13 => p.money(r.calc.cost),
        _ => String::new(),
    }
}

fn res_edit_text(r: &Resource, c: usize) -> String {
    match c {
        5 => fmt_num(r.max_units * 100.0),
        6 => fmt_num(r.std_rate),
        7 => fmt_num(r.ovt_rate),
        8 => fmt_num(r.cost_per_use),
        0 => r.name.clone(),
        2 => r.material_label.clone(),
        3 => r.initials.clone(),
        4 => r.group.clone(),
        11 => r.email.clone(),
        _ => String::new(),
    }
}

fn num(s: &str) -> Option<f64> {
    let cleaned: String = s.chars().filter(|c| c.is_ascii_digit() || *c == '.' || *c == ',' || *c == '-').collect();
    cleaned.replace(',', ".").parse().ok()
}

fn commit_res(app: &mut PlanApp, uid: Option<u32>, c: usize, text: &str) {
    let text = text.trim();
    let ri = match uid {
        Some(u) => match app.p.res_index(u) {
            Some(i) => i,
            None => return,
        },
        None => {
            if text.is_empty() {
                return;
            }
            app.checkpoint();
            let u = app.p.alloc_res_uid();
            app.p.resources.push(Resource::new(u, text));
            app.sel_res = Some(u);
            app.recalc();
            return;
        }
    };
    app.checkpoint();
    let r = &mut app.p.resources[ri];
    match c {
        0 if !text.is_empty() => r.name = text.into(),
        2 => r.material_label = text.into(),
        3 => r.initials = text.into(),
        4 => r.group = text.into(),
        5 => {
            if let Some(v) = num(text) {
                r.max_units = (v / 100.0).max(0.0)
            }
        }
        6 => {
            if let Some(v) = num(text) {
                r.std_rate = v.max(0.0)
            }
        }
        7 => {
            if let Some(v) = num(text) {
                r.ovt_rate = v.max(0.0)
            }
        }
        8 => {
            if let Some(v) = num(text) {
                r.cost_per_use = v.max(0.0)
            }
        }
        11 => r.email = text.into(),
        _ => {}
    }
    app.recalc();
}

pub fn resource_sheet(app: &mut PlanApp, ui: &mut egui::Ui) {
    let full = ui.available_rect_before_wrap();
    ui.allocate_rect(full, Sense::hover());
    let head = Rect::from_min_size(full.min, Vec2::new(full.width(), 30.0));
    let p = ui.painter().with_clip_rect(full);
    p.rect_filled(head, 0.0, HEADER_BG);
    let mut x = head.left() + 36.0;
    p.text(Pos2::new(head.left() + 26.0, head.center().y), Align2::CENTER_CENTER, "ℹ", FontId::proportional(12.0), Color32::from_gray(60));
    for (t, w) in RES_COLS {
        p.line_segment([Pos2::new(x, head.top()), Pos2::new(x, head.bottom())], Stroke::new(1.0, GRID_LINE));
        p.text(Pos2::new(x + 5.0, head.center().y), Align2::LEFT_CENTER, t, FontId::proportional(12.0), Color32::from_gray(40));
        x += w;
    }
    p.line_segment([head.left_bottom(), head.right_bottom()], Stroke::new(1.0, Color32::from_gray(190)));
    let body = Rect::from_min_max(Pos2::new(full.left(), head.bottom()), full.max);
    let mut child = ui.new_child(egui::UiBuilder::new().max_rect(body));
    egui::ScrollArea::vertical().id_salt("res_rows").auto_shrink([false, false]).show(&mut child, |ui| {
        let n = app.p.resources.len();
        let rows = n + ((body.height() / 22.0) as usize).saturating_sub(n).max(2);
        for r in 0..rows {
            let (row, _) = ui.allocate_exact_size(Vec2::new(body.width(), 22.0), Sense::hover());
            let res = app.p.resources.get(r).cloned();
            let selected = res.as_ref().map(|x| Some(x.uid) == app.sel_res).unwrap_or(false);
            let painter = ui.painter().with_clip_rect(body);
            painter.rect_filled(row, 0.0, if selected { SELECT_BG } else if r % 2 == 1 { Color32::from_rgb(0xFB, 0xFB, 0xFC) } else { Color32::WHITE });
            let idr = Rect::from_min_size(row.min, Vec2::new(36.0, 22.0));
            painter.rect_filled(idr, 0.0, HEADER_BG);
            painter.line_segment([row.left_bottom(), row.right_bottom()], Stroke::new(1.0, Color32::from_gray(232)));
            if let Some(res) = &res {
                painter.text(idr.center() - Vec2::new(6.0, 0.0), Align2::CENTER_CENTER, res.calc.id.to_string(), FontId::proportional(11.5), Color32::from_gray(80));
                if res.calc.overallocated {
                    painter.text(idr.right_center() - Vec2::new(5.0, 0.0), Align2::CENTER_CENTER, "⚠", FontId::proportional(11.0), Color32::from_rgb(0xC0, 0x30, 0x30));
                }
            }
            let mut x = row.left() + 36.0;
            for (c, (_, w)) in RES_COLS.iter().enumerate() {
                let cr = Rect::from_min_size(Pos2::new(x, row.top()), Vec2::new(*w, 22.0));
                x += w;
                painter.line_segment([cr.right_top(), cr.right_bottom()], Stroke::new(1.0, Color32::from_gray(236)));
                let editing = app.res_edit.as_ref().map(|e| e.uid == res.as_ref().map(|r| r.uid) && e.col == c).unwrap_or(false);
                if editing {
                    let mut e = app.res_edit.clone().unwrap();
                    let mut cu = ui.new_child(egui::UiBuilder::new().max_rect(cr.shrink(1.0)));
                    let resp = cu.add(egui::TextEdit::singleline(&mut e.buf).desired_width(cr.width() - 4.0).margin(egui::Margin::symmetric(3, 2)));
                    if e.focus {
                        resp.request_focus();
                        e.focus = false;
                    }
                    let (enter, esc) = ui.input(|i| (i.key_pressed(egui::Key::Enter), i.key_pressed(egui::Key::Escape)));
                    if esc {
                        app.res_edit = None;
                    } else if resp.lost_focus() || enter {
                        app.res_edit = None;
                        commit_res(app, e.uid, e.col, &e.buf);
                    } else {
                        app.res_edit = Some(e);
                    }
                    continue;
                }
                let resp = ui.interact(cr.intersect(body), ui.scope_id().with(("rc", r, c)), Sense::click());
                match &res {
                    Some(rs) => {
                        let over = rs.calc.overallocated;
                        let col = if over { Color32::from_rgb(0xC0, 0x00, 0x00) } else { Color32::from_gray(25) };
                        let s = res_cell(&app.p, rs, c);
                        let right = matches!(c, 5 | 6 | 7 | 8 | 12 | 13);
                        let pc = painter.with_clip_rect(cr.shrink2(Vec2::new(2.0, 0.0)).intersect(body));
                        if right {
                            pc.text(cr.right_center() - Vec2::new(6.0, 0.0), Align2::RIGHT_CENTER, s, FontId::proportional(12.0), col);
                        } else {
                            pc.text(cr.left_center() + Vec2::new(5.0, 0.0), Align2::LEFT_CENTER, s, FontId::proportional(12.0), col);
                        }
                        if resp.clicked() {
                            app.sel_res = Some(rs.uid);
                            match c {
                                1 => {
                                    app.checkpoint();
                                    let k = app.p.res_index(rs.uid).unwrap();
                                    let rr = &mut app.p.resources[k];
                                    rr.kind = match rr.kind {
                                        ResKind::Work => ResKind::Material,
                                        ResKind::Material => ResKind::Cost,
                                        ResKind::Cost => ResKind::Work,
                                    };
                                    app.recalc();
                                }
                                9 => {
                                    app.checkpoint();
                                    let k = app.p.res_index(rs.uid).unwrap();
                                    let rr = &mut app.p.resources[k];
                                    rr.accrue = match rr.accrue {
                                        Accrue::Start => Accrue::Prorated,
                                        Accrue::Prorated => Accrue::End,
                                        Accrue::End => Accrue::Start,
                                    };
                                }
                                _ => {}
                            }
                        }
                        if resp.double_clicked() {
                            if matches!(c, 0 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 11) {
                                app.res_edit = Some(ResEdit { uid: Some(rs.uid), col: c, buf: res_edit_text(rs, c), focus: true });
                            } else if !matches!(c, 1 | 9) {
                                app.dlg.resource = Some(rs.clone());
                            }
                        }
                        if matches!(c, 1 | 9) {
                            resp.clone().on_hover_text("Click to change");
                        }
                        let uid = rs.uid;
                        resp.context_menu(|ui| {
                            if ui.button("ℹ  Resource Information…").clicked() {
                                app.dlg.resource = app.p.resources.iter().find(|r| r.uid == uid).cloned();
                                ui.close();
                            }
                            if ui.button("🗑  Delete Resource").clicked() {
                                app.checkpoint();
                                app.p.resources.retain(|r| r.uid != uid);
                                for t in app.p.tasks.iter_mut() {
                                    t.assign.retain(|a| a.res != uid);
                                }
                                app.recalc();
                                ui.close();
                            }
                        });
                    }
                    None => {
                        if c == 0 && r == n {
                            if resp.hovered() {
                                painter.text(cr.left_center() + Vec2::new(5.0, 0.0), Align2::LEFT_CENTER, "Type a new resource…", FontId::proportional(12.0), Color32::from_gray(160));
                            }
                            if resp.clicked() {
                                app.res_edit = Some(ResEdit { uid: None, col: 0, buf: String::new(), focus: true });
                            }
                        }
                    }
                }
            }
        }
    });
}

// ---------------- Calendar ----------------

pub fn calendar_view(app: &mut PlanApp, ui: &mut egui::Ui) {
    let month = app.cal_month;
    ui.horizontal(|ui| {
        ui.add_space(8.0);
        if ui.button("◀").clicked() {
            app.cal_month = add_months(month, -1);
        }
        if ui.button("Today").clicked() {
            let t = PlanApp::today().date();
            app.cal_month = NaiveDate::from_ymd_opt(t.year(), t.month(), 1).unwrap();
        }
        if ui.button("▶").clicked() {
            app.cal_month = add_months(month, 1);
        }
        ui.add_space(10.0);
        ui.heading(month.format("%B %Y").to_string());
    });
    let full = ui.available_rect_before_wrap();
    ui.allocate_rect(full, Sense::hover());
    let p = ui.painter().with_clip_rect(full);
    let head_h = 24.0;
    let cw = full.width() / 7.0;
    let ch = (full.height() - head_h) / 6.0;
    for (k, d) in ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"].iter().enumerate() {
        let r = Rect::from_min_size(Pos2::new(full.left() + k as f32 * cw, full.top()), Vec2::new(cw, head_h));
        p.rect_filled(r, 0.0, HEADER_BG);
        p.text(r.center(), Align2::CENTER_CENTER, *d, FontId::proportional(12.0), Color32::from_gray(50));
    }
    let first = month - Duration::days(month.weekday().num_days_from_sunday() as i64);
    let tasks: Vec<usize> = (0..app.p.tasks.len()).filter(|&i| !app.p.tasks[i].calc.summary).collect();
    for w in 0..6 {
        for k in 0..7 {
            let d = first + Duration::days((w * 7 + k) as i64);
            let r = Rect::from_min_size(Pos2::new(full.left() + k as f32 * cw, full.top() + head_h + w as f32 * ch), Vec2::new(cw, ch));
            let in_month = d.month() == month.month();
            let bg = if !app.p.calendar.is_working_day(d) {
                Color32::from_rgb(0xF1, 0xF2, 0xF4)
            } else if in_month {
                Color32::WHITE
            } else {
                Color32::from_rgb(0xFA, 0xFA, 0xFA)
            };
            p.rect_filled(r, 0.0, bg);
            p.rect_stroke(r, 0.0, Stroke::new(1.0, GRID_LINE), egui::StrokeKind::Inside);
            let today = PlanApp::today().date() == d;
            p.text(
                r.right_top() + Vec2::new(-6.0, 9.0),
                Align2::RIGHT_CENTER,
                d.day().to_string(),
                FontId::proportional(if today { 13.0 } else { 11.5 }),
                if today { ACCENT } else if in_month { Color32::from_gray(50) } else { Color32::from_gray(160) },
            );
            let mut y = r.top() + 20.0;
            let mut shown = 0;
            let todays: Vec<usize> = tasks.iter().copied().filter(|&i| {
                let t = &app.p.tasks[i];
                t.start.date() <= d && (t.finish.date() >= d || (t.dur == 0 && t.start.date() == d))
            }).collect();
            for &i in &todays {
                if y + 16.0 > r.bottom() - 2.0 {
                    let more = todays.len() - shown;
                    p.text(Pos2::new(r.left() + 6.0, r.bottom() - 8.0), Align2::LEFT_CENTER, format!("+{more} more"), FontId::proportional(10.0), Color32::from_gray(110));
                    break;
                }
                let t = &app.p.tasks[i];
                let br = Rect::from_min_size(Pos2::new(r.left() + 3.0, y), Vec2::new(cw - 6.0, 15.0));
                let crit = app.show_critical && t.calc.critical;
                let fill = if t.is_milestone() {
                    Color32::from_gray(235)
                } else if crit {
                    Color32::from_rgb(0xF4, 0xC4, 0xC4)
                } else {
                    Color32::from_rgb(0xCD, 0xDE, 0xF5)
                };
                p.rect_filled(br, 2.0, fill);
                let label = if t.is_milestone() { format!("◆ {}", t.name) } else { t.name.clone() };
                p.with_clip_rect(br.intersect(full)).text(br.left_center() + Vec2::new(4.0, 0.0), Align2::LEFT_CENTER, label, FontId::proportional(10.5), Color32::from_gray(25));
                let resp = ui.interact(br.intersect(full), ui.scope_id().with(("calt", i, d)), Sense::click());
                if resp.clicked() {
                    app.sel = vec![t.uid];
                }
                if resp.double_clicked() {
                    app.sel = vec![t.uid];
                    app.open_task_info(0);
                }
                y += 17.0;
                shown += 1;
            }
        }
    }
}

fn add_months(d: NaiveDate, n: i32) -> NaiveDate {
    let m0 = d.year() * 12 + d.month() as i32 - 1 + n;
    NaiveDate::from_ymd_opt(m0.div_euclid(12), (m0.rem_euclid(12) + 1) as u32, 1).unwrap()
}

// ---------------- Network Diagram ----------------

pub fn network_view(app: &mut PlanApp, ui: &mut egui::Ui) {
    let n = app.p.tasks.len();
    let leaves: Vec<usize> = (0..n).filter(|&i| !app.p.tasks[i].calc.summary).collect();
    // column = longest chain of predecessors
    let mut col = vec![0usize; n];
    for _ in 0..n.min(200) {
        let mut changed = false;
        for &i in &leaves {
            for l in &app.p.tasks[i].links {
                if let Some(pi) = app.p.index_of(l.pred) {
                    if !app.p.tasks[pi].calc.summary && col[pi] + 1 > col[i] {
                        col[i] = col[pi] + 1;
                        changed = true;
                    }
                }
            }
        }
        if !changed {
            break;
        }
    }
    let mut per_col: Vec<Vec<usize>> = vec![];
    for &i in &leaves {
        let c = col[i];
        while per_col.len() <= c {
            per_col.push(vec![]);
        }
        per_col[c].push(i);
    }
    let (bw, bh, gx, gy) = (190.0, 82.0, 60.0, 26.0);
    let max_rows = per_col.iter().map(|c| c.len()).max().unwrap_or(0);
    let size = Vec2::new(per_col.len() as f32 * (bw + gx) + 40.0, max_rows as f32 * (bh + gy) + 40.0);
    egui::ScrollArea::both().id_salt("network").auto_shrink([false, false]).show(ui, |ui| {
        let (area, _) = ui.allocate_exact_size(size.max(ui.available_size()), Sense::hover());
        let p = ui.painter().clone();
        let mut pos = vec![None; n];
        for (c, items) in per_col.iter().enumerate() {
            for (r, &i) in items.iter().enumerate() {
                pos[i] = Some(Rect::from_min_size(area.min + Vec2::new(20.0 + c as f32 * (bw + gx), 20.0 + r as f32 * (bh + gy)), Vec2::new(bw, bh)));
            }
        }
        // links first
        for &i in &leaves {
            let Some(to) = pos[i] else { continue };
            for l in &app.p.tasks[i].links {
                let Some(pi) = app.p.index_of(l.pred) else { continue };
                let Some(from) = pos[pi] else { continue };
                let crit = app.p.tasks[i].calc.critical && app.p.tasks[pi].calc.critical;
                let c = if crit { Color32::from_rgb(0xC0, 0x20, 0x20) } else { Color32::from_rgb(0x1F, 0x5F, 0xAF) };
                let a = from.right_center();
                let b = to.left_center();
                let mx = a.x + gx / 2.0;
                p.line_segment([a, Pos2::new(mx, a.y)], Stroke::new(1.2, c));
                p.line_segment([Pos2::new(mx, a.y), Pos2::new(mx, b.y)], Stroke::new(1.2, c));
                p.line_segment([Pos2::new(mx, b.y), b], Stroke::new(1.2, c));
                p.add(egui::Shape::convex_polygon(vec![b, b + Vec2::new(-6.0, -3.5), b + Vec2::new(-6.0, 3.5)], c, Stroke::NONE));
            }
        }
        for &i in &leaves {
            let Some(r) = pos[i] else { continue };
            let t = &app.p.tasks[i];
            let crit = t.calc.critical;
            let border = if crit { Color32::from_rgb(0xC0, 0x20, 0x20) } else { Color32::from_rgb(0x1F, 0x5F, 0xAF) };
            let fill = if app.sel.contains(&t.uid) {
                SELECT_BG
            } else if crit {
                Color32::from_rgb(0xFD, 0xEE, 0xEE)
            } else {
                Color32::from_rgb(0xEE, 0xF4, 0xFC)
            };
            if t.is_milestone() {
                p.rect_filled(r, 14.0, fill);
                p.rect_stroke(r, 14.0, Stroke::new(1.5, border), egui::StrokeKind::Inside);
            } else {
                p.rect_filled(r, 3.0, fill);
                p.rect_stroke(r, 3.0, Stroke::new(1.5, border), egui::StrokeKind::Inside);
            }
            let pc = p.with_clip_rect(r.shrink(3.0));
            pc.text(r.left_top() + Vec2::new(8.0, 12.0), Align2::LEFT_CENTER, &t.name, FontId::proportional(12.5), Color32::from_gray(20));
            p.line_segment([r.left_top() + Vec2::new(0.0, 24.0), r.right_top() + Vec2::new(0.0, 24.0)], Stroke::new(1.0, border.gamma_multiply(0.5)));
            let f = FontId::proportional(10.5);
            let g = Color32::from_gray(60);
            pc.text(r.left_top() + Vec2::new(8.0, 34.0), Align2::LEFT_CENTER, format!("Start: {}", fmt_date(t.start)), f.clone(), g);
            pc.text(r.right_top() + Vec2::new(-8.0, 34.0), Align2::RIGHT_CENTER, format!("ID: {}", t.calc.id), f.clone(), g);
            pc.text(r.left_top() + Vec2::new(8.0, 50.0), Align2::LEFT_CENTER, format!("Finish: {}", fmt_date(t.finish)), f.clone(), g);
            pc.text(r.right_top() + Vec2::new(-8.0, 50.0), Align2::RIGHT_CENTER, format!("Dur: {}", app.p.fmt_duration(t.dur, t.estimated)), f.clone(), g);
            let res = app.p.fmt_resources(t);
            pc.text(r.left_top() + Vec2::new(8.0, 66.0), Align2::LEFT_CENTER, if res.is_empty() { format!("{}% complete", fmt_num(t.percent)) } else { format!("Res: {res}") }, f, g);
            if t.complete() {
                p.line_segment([r.left_top(), r.right_bottom()], Stroke::new(1.0, border.gamma_multiply(0.4)));
            }
            let resp = ui.interact(r, ui.scope_id().with(("net", t.uid)), Sense::click());
            if resp.clicked() {
                app.sel = vec![t.uid];
            }
            if resp.double_clicked() {
                app.sel = vec![t.uid];
                app.open_task_info(0);
            }
        }
        if leaves.is_empty() {
            p.text(area.center(), Align2::CENTER_CENTER, "No tasks yet", FontId::proportional(14.0), Color32::from_gray(140));
        }
    });
}

// ---------------- Team Planner ----------------

pub fn team_planner(app: &mut PlanApp, ui: &mut egui::Ui) {
    let full = ui.available_rect_before_wrap();
    ui.allocate_rect(full, Sense::hover());
    let name_w = 180.0;
    let lane_h = 44.0;
    let head_h = 30.0;
    let p = ui.painter().with_clip_rect(full);
    let t0 = crate::grid::chart_origin(app);
    let ppd = app.px_per_day.max(14.0);
    let left = full.left() + name_w;
    // horizontal scroll
    if ui.rect_contains_pointer(full) {
        let (dx, dy, shift) = ui.input(|i| (i.smooth_scroll_delta.x, i.smooth_scroll_delta.y, i.modifiers.shift));
        if dx != 0.0 {
            app.gantt_x = (app.gantt_x - dx).max(0.0);
        } else if shift {
            app.gantt_x = (app.gantt_x - dy).max(0.0);
        }
    }
    let gx = app.gantt_x;
    let x_of = |d: chrono::NaiveDateTime| left - gx + (d - t0).num_minutes() as f32 / 1440.0 * ppd;
    // header: days
    let head = Rect::from_min_max(Pos2::new(left, full.top()), Pos2::new(full.right(), full.top() + head_h));
    p.rect_filled(Rect::from_min_size(full.min, Vec2::new(full.width(), head_h)), 0.0, HEADER_BG);
    p.text(Pos2::new(full.left() + 10.0, full.top() + head_h / 2.0), Align2::LEFT_CENTER, "Resource Name", FontId::proportional(12.0), Color32::from_gray(40));
    let hp = p.with_clip_rect(head);
    let first_day = (app.gantt_x / ppd) as i64 - 1;
    let ndays = (full.width() / ppd) as i64 + 3;
    for k in first_day..first_day + ndays {
        let d = (t0 + Duration::days(k)).date();
        let x = left - app.gantt_x + k as f32 * ppd;
        if !app.p.calendar.is_working_day(d) {
            p.with_clip_rect(Rect::from_min_max(Pos2::new(left, full.top() + head_h), full.max))
                .rect_filled(Rect::from_min_max(Pos2::new(x, full.top() + head_h), Pos2::new(x + ppd, full.bottom())), 0.0, Color32::from_rgb(0xF1, 0xF2, 0xF4));
        }
        hp.line_segment([Pos2::new(x, head.top() + 14.0), Pos2::new(x, head.bottom())], Stroke::new(1.0, GRID_LINE));
        if d.weekday().num_days_from_sunday() == 0 || k == first_day + 1 {
            hp.text(Pos2::new(x + 3.0, head.top() + 7.0), Align2::LEFT_CENTER, d.format("%b %-d").to_string(), FontId::proportional(10.0), Color32::from_gray(60));
        }
        hp.text(Pos2::new(x + ppd / 2.0, head.top() + 22.0), Align2::CENTER_CENTER, d.format("%a").to_string().chars().next().unwrap().to_string(), FontId::proportional(10.0), Color32::from_gray(60));
    }
    let mut lanes: Vec<(String, Option<u32>, bool)> = app
        .p
        .resources
        .iter()
        .filter(|r| r.kind == ResKind::Work)
        .map(|r| (r.name.clone(), Some(r.uid), r.calc.overallocated))
        .collect();
    lanes.push(("Unassigned Tasks".into(), None, false));
    let body_clip = Rect::from_min_max(Pos2::new(full.left(), full.top() + head_h), full.max);
    let bp = p.with_clip_rect(body_clip);
    let chart_clip = Rect::from_min_max(Pos2::new(left, full.top() + head_h), full.max);
    let cp = p.with_clip_rect(chart_clip);
    let palette = [
        Color32::from_rgb(0x7F, 0xA8, 0xE0),
        Color32::from_rgb(0x8F, 0xCB, 0x9B),
        Color32::from_rgb(0xF2, 0xC0, 0x7A),
        Color32::from_rgb(0xC3, 0xA6, 0xE3),
        Color32::from_rgb(0x88, 0xD0, 0xD8),
    ];
    for (k, (name, uid, over)) in lanes.iter().enumerate() {
        let y = full.top() + head_h + k as f32 * lane_h;
        let lane = Rect::from_min_size(Pos2::new(full.left(), y), Vec2::new(full.width(), lane_h));
        bp.line_segment([lane.left_bottom(), lane.right_bottom()], Stroke::new(1.0, GRID_LINE));
        let nr = Rect::from_min_size(lane.min, Vec2::new(name_w, lane_h));
        bp.rect_filled(nr, 0.0, if uid.is_none() { Color32::from_rgb(0xF6, 0xF6, 0xF6) } else { Color32::from_rgb(0xFA, 0xFB, 0xFB) });
        let initials: String = name.split_whitespace().filter_map(|w| w.chars().next()).take(2).collect();
        if uid.is_some() {
            bp.circle_filled(nr.left_center() + Vec2::new(22.0, 0.0), 13.0, palette[k % palette.len()]);
            bp.text(nr.left_center() + Vec2::new(22.0, 0.0), Align2::CENTER_CENTER, initials, FontId::proportional(11.0), Color32::WHITE);
        }
        bp.text(nr.left_center() + Vec2::new(42.0, 0.0), Align2::LEFT_CENTER, name, FontId::proportional(12.5), if *over { Color32::from_rgb(0xC0, 0, 0) } else { Color32::from_gray(30) });
        bp.line_segment([nr.right_top(), nr.right_bottom()], Stroke::new(1.0, GRID_LINE));
        // tasks in this lane, stacked when they overlap
        let mut items: Vec<usize> = (0..app.p.tasks.len())
            .filter(|&i| {
                let t = &app.p.tasks[i];
                !t.calc.summary
                    && match uid {
                        Some(u) => t.assign.iter().any(|a| a.res == *u),
                        None => t.assign.is_empty() && !t.is_milestone(),
                    }
            })
            .collect();
        items.sort_by_key(|&i| app.p.tasks[i].start);
        let mut ends: Vec<chrono::NaiveDateTime> = vec![];
        for &i in &items {
            let t = app.p.tasks[i].clone();
            let slot = ends.iter().position(|e| *e <= t.start).unwrap_or_else(|| {
                ends.push(t.start);
                ends.len() - 1
            });
            ends[slot] = t.finish;
            let sub_h = (lane_h - 8.0) / (ends.len().max(1) as f32).max(1.0);
            let _ = sub_h;
            let slot_h = if slot == 0 { 0.0 } else { 9.0 * slot as f32 };
            let r = Rect::from_min_max(Pos2::new(x_of(t.start), y + 6.0 + slot_h), Pos2::new(x_of(t.finish).max(x_of(t.start) + 3.0), y + lane_h - 6.0));
            let fill = if t.calc.overallocated && uid.is_some() {
                Color32::from_rgb(0xF0, 0x9A, 0x9A)
            } else if t.complete() {
                Color32::from_rgb(0xB5, 0xB9, 0xC0)
            } else {
                palette[k % palette.len()]
            };
            cp.rect_filled(r, 3.0, fill);
            cp.rect_stroke(r, 3.0, Stroke::new(1.0, Color32::from_black_alpha(40)), egui::StrokeKind::Inside);
            cp.with_clip_rect(r.intersect(chart_clip)).text(r.left_center() + Vec2::new(5.0, 0.0), Align2::LEFT_CENTER, &t.name, FontId::proportional(11.0), Color32::from_gray(20));
            let resp = ui.interact(r.intersect(chart_clip), ui.scope_id().with(("tp", k, i)), Sense::click());
            if resp.clicked() {
                app.sel = vec![t.uid];
            }
            if resp.double_clicked() {
                app.sel = vec![t.uid];
                app.open_task_info(0);
            }
            resp.on_hover_text(format!("{}\n{} – {}", t.name, fmt_date(t.start), fmt_date(t.finish)));
        }
    }
    let today_x = x_of(PlanApp::today());
    cp.line_segment([Pos2::new(today_x, chart_clip.top()), Pos2::new(today_x, chart_clip.bottom())], Stroke::new(1.2, Color32::from_rgb(0xE0, 0x8E, 0x3A)));
}
