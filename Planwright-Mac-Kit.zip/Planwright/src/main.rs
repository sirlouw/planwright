//! Planwright - a desktop project planner.
//!
//! `planwright --screenshot out.png` opens the window without taking focus,
//! draws about 120 frames, saves a PNG of the window and exits.

#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod app;
mod calendar;
mod dialogs;
mod grid;
mod io;
mod model;
mod samples;
mod schedule;
mod tabs;
mod views;

use eframe::egui;
use std::path::PathBuf;

fn main() -> eframe::Result<()> {
    let args: Vec<String> = std::env::args().collect();
    let mut screenshot: Option<PathBuf> = None;
    let mut open_files: Vec<PathBuf> = vec![];
    let mut k = 1;
    while k < args.len() {
        if args[k] == "--view" && k + 1 < args.len() {
            std::env::set_var("PLANWRIGHT_VIEW", &args[k + 1]);
            k += 2;
            continue;
        }
        if args[k] == "--screenshot" && k + 1 < args.len() {
            screenshot = Some(PathBuf::from(&args[k + 1]));
            k += 2;
            continue;
        }
        if !args[k].starts_with("--") {
            open_files.push(PathBuf::from(&args[k]));
        }
        k += 1;
    }

    let mut viewport = egui::ViewportBuilder::default()
        .with_title("Planwright")
        .with_inner_size([1440.0, 860.0])
        .with_min_inner_size([900.0, 560.0]);
    if let Ok(icon) = eframe::icon_data::from_png_bytes(include_bytes!("../packaging/icon.png")) {
        viewport = viewport.with_icon(icon);
    }
    if screenshot.is_some() {
        viewport = viewport.with_active(false);
        #[cfg(target_os = "windows")]
        {
            viewport = viewport.with_window_level(egui::WindowLevel::AlwaysOnBottom);
        }
    }
    #[allow(unused_mut)]
    let mut options = eframe::NativeOptions { viewport, ..Default::default() };
    // with --screenshot on macOS, open without stealing focus from the person's work
    #[cfg(target_os = "macos")]
    if screenshot.is_some() {
        use winit::platform::macos::EventLoopBuilderExtMacOS;
        options.event_loop_builder = Some(Box::new(|builder| {
            builder.with_activate_ignoring_other_apps(false);
        }));
    }

    eframe::run_native(
        "Planwright",
        options,
        Box::new(move |cc| {
            let mut app = app::PlanApp::new(cc, screenshot);
            if let Ok(v) = std::env::var("PLANWRIGHT_VIEW") {
                let v = v.to_lowercase();
                for view in app::View::ALL {
                    if view.label().to_lowercase().replace(' ', "").starts_with(&v.replace(' ', "")) {
                        app.view = view;
                    }
                }
                if v == "file" {
                    app.backstage = true;
                }
                if v == "critical" {
                    app.show_critical = true;
                    app.show_slack = true;
                }
                if v == "tabs" {
                    // three projects open side by side, the middle one active
                    let monday = app::monday_of(chrono::Local::now().naive_local().date());
                    app.open_project(samples::office_move(monday), None);
                    app.open_project(samples::product_release(monday), None);
                    app.switch_tab(1);
                }
            }
            // files given on the command line each open in their own tab; the first replaces the sample
            for (k, f) in open_files.into_iter().enumerate() {
                if k == 0 {
                    let is_xml = f.extension().map(|e| e.eq_ignore_ascii_case("xml")).unwrap_or(false);
                    let res = if is_xml { io::import_xml(&f) } else { io::load_json(&f) };
                    match res {
                        Ok(p) => {
                            app.new_project(p);
                            if !is_xml {
                                app.file = Some(f);
                            }
                        }
                        Err(e) => app.dlg.message = Some(("Couldn't open the file".into(), e)),
                    }
                } else {
                    app.open_path(f);
                }
            }
            Ok(Box::new(app))
        }),
    )
}
