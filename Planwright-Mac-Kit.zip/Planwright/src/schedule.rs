//! The scheduling engine (see MECHANICS.md). Order follows the original's
//! PDM.SetDates: outline -> cycle check -> early dates (manual, auto) ->
//! late dates -> as-late-as-possible tasks -> summaries -> slack and critical.

use crate::calendar::WorkCalendar;
use crate::model::*;
use chrono::{Local, NaiveDateTime};
use std::collections::VecDeque;

pub struct ScheduleResult {
    pub circular: Option<(usize, usize)>,
}

/// One dependency between two leaf tasks after summary links are spread to their children.
#[derive(Clone)]
#[allow(dead_code)]
struct Edge {
    from_task: usize, // the task named in the link (may be a summary)
    to_leaf: usize,
    kind: LinkKind,
    lag: i64,
}

fn outline(p: &mut Project) {
    let n = p.tasks.len();
    let mut stack: Vec<usize> = vec![];
    let mut counters: Vec<u32> = vec![];
    for i in 0..n {
        let lvl = p.tasks[i].level.max(1) as usize;
        // a task can be at most one level deeper than the one above it
        let lvl = lvl.min(stack.len() + 1);
        p.tasks[i].level = lvl as u32;
        while stack.len() >= lvl {
            stack.pop();
        }
        counters.truncate(lvl);
        while counters.len() < lvl {
            counters.push(0);
        }
        counters[lvl - 1] += 1;
        let wbs = counters.iter().map(|c| c.to_string()).collect::<Vec<_>>().join(".");
        let parent = stack.last().copied();
        let c = &mut p.tasks[i].calc;
        *c = Calc::default();
        c.id = i + 1;
        c.wbs = wbs;
        c.parent = parent;
        stack.push(i);
    }
    for i in 0..n {
        let s = i + 1 < n && p.tasks[i + 1].level > p.tasks[i].level;
        p.tasks[i].calc.summary = s;
    }
    // visibility (collapsed summaries hide their children)
    for i in 0..n {
        let mut vis = true;
        let mut par = p.tasks[i].calc.parent;
        while let Some(pi) = par {
            if p.tasks[pi].collapsed {
                vis = false;
                break;
            }
            par = p.tasks[pi].calc.parent;
        }
        p.tasks[i].calc.visible = vis;
    }
}

fn leaves_of(p: &Project, i: usize) -> Vec<usize> {
    if !p.tasks[i].calc.summary {
        return vec![i];
    }
    let lvl = p.tasks[i].level;
    let mut out = vec![];
    let mut j = i + 1;
    while j < p.tasks.len() && p.tasks[j].level > lvl {
        if !p.tasks[j].calc.summary {
            out.push(j);
        }
        j += 1;
    }
    out
}

fn ancestors(p: &Project, i: usize) -> Vec<usize> {
    let mut v = vec![];
    let mut par = p.tasks[i].calc.parent;
    while let Some(pi) = par {
        v.push(pi);
        par = p.tasks[pi].calc.parent;
    }
    v
}

fn from_pred(cal: &WorkCalendar, t: NaiveDateTime, lag: i64) -> NaiveDateTime {
    cal.add_minutes(t, lag)
}

fn start_from_finish(cal: &WorkCalendar, finish: NaiveDateTime, dur: i64) -> NaiveDateTime {
    if dur == 0 {
        finish
    } else {
        cal.add_minutes(cal.prev_work_end(finish), -dur)
    }
}

fn finish_from_start(cal: &WorkCalendar, start: NaiveDateTime, dur: i64) -> NaiveDateTime {
    if dur == 0 {
        start
    } else {
        cal.add_minutes(start, dur)
    }
}

fn pred_dates(p: &Project, i: usize, late: bool) -> (NaiveDateTime, NaiveDateTime) {
    let t = &p.tasks[i];
    if late {
        (t.calc.ls.unwrap_or(t.start), t.calc.lf.unwrap_or(t.finish))
    } else {
        (t.calc.es.unwrap_or(t.start), t.calc.ef.unwrap_or(t.finish))
    }
}

fn roll_up(p: &mut Project) {
    let n = p.tasks.len();
    for i in (0..n).rev() {
        if !p.tasks[i].calc.summary {
            continue;
        }
        let leaves = leaves_of(p, i);
        if leaves.is_empty() {
            continue;
        }
        let es = leaves.iter().map(|&j| p.tasks[j].start).min().unwrap();
        let ef = leaves.iter().map(|&j| p.tasks[j].finish).max().unwrap();
        let ls = leaves.iter().filter_map(|&j| p.tasks[j].calc.ls).min();
        let lf = leaves.iter().filter_map(|&j| p.tasks[j].calc.lf).max();
        // Task::SetSummaryPercent: active subtasks only; % = sum(actual duration) / sum(duration) x 100,
        // actual duration = duration x % / 100 (CalculateSummaryPDM IL_0063-IL_00a0).
        // With no duration at all: 100 % when every active subtask is complete, else 0.
        let active: Vec<usize> = leaves.iter().copied().filter(|&j| p.tasks[j].active).collect();
        let total: f64 = active.iter().map(|&j| p.tasks[j].dur as f64).sum();
        let done: f64 = active
            .iter()
            .map(|&j| (p.tasks[j].dur as f64 * p.tasks[j].percent / 100.0).round())
            .sum();
        let pct = if total > 0.0 {
            done / total * 100.0
        } else if !active.is_empty() && active.iter().all(|&j| p.tasks[j].complete()) {
            100.0
        } else {
            0.0
        };
        let dur = p.calendar.work_between(es, ef);
        let t = &mut p.tasks[i];
        t.start = es;
        t.finish = ef;
        t.dur = dur;
        t.percent = (pct * 10.0).round() / 10.0;
        t.calc.es = Some(es);
        t.calc.ef = Some(ef);
        t.calc.ls = ls;
        t.calc.lf = lf;
    }
}

pub fn schedule(p: &mut Project) -> ScheduleResult {
    outline(p);
    let n = p.tasks.len();
    let cal = p.calendar.clone();
    let proj_start = cal.next_work_start(p.start);

    // ---- spread links to leaf tasks ----
    let mut incoming: Vec<Vec<Edge>> = vec![vec![]; n];
    let mut leaf_succ: Vec<Vec<(usize, Edge)>> = vec![vec![]; n];
    for i in 0..n {
        if p.tasks[i].calc.summary {
            continue;
        }
        let mut owners = vec![i];
        owners.extend(ancestors(p, i));
        for &o in &owners {
            for l in p.tasks[o].links.clone() {
                let Some(pi) = p.index_of(l.pred) else { continue };
                // a task can't depend on its own summary
                if owners.contains(&pi) || leaves_of(p, pi).contains(&i) {
                    continue;
                }
                let e = Edge { from_task: pi, to_leaf: i, kind: l.kind, lag: l.lag };
                for q in leaves_of(p, pi) {
                    leaf_succ[q].push((i, e.clone()));
                }
                incoming[i].push(e);
            }
        }
    }

    // ---- topological order over leaves, with cycle check ----
    let mut indeg = vec![0usize; n];
    for q in 0..n {
        for (s, _) in &leaf_succ[q] {
            indeg[*s] += 1;
        }
    }
    let mut queue: VecDeque<usize> =
        (0..n).filter(|&i| !p.tasks[i].calc.summary && indeg[i] == 0).collect();
    let mut order = vec![];
    while let Some(q) = queue.pop_front() {
        order.push(q);
        for (s, _) in &leaf_succ[q] {
            indeg[*s] -= 1;
            if indeg[*s] == 0 {
                queue.push_back(*s);
            }
        }
    }
    let leaf_count = (0..n).filter(|&i| !p.tasks[i].calc.summary).count();
    if order.len() < leaf_count {
        // circular relationship: name two tasks on the loop, keep old dates
        let stuck: Vec<usize> = (0..n).filter(|&i| !p.tasks[i].calc.summary && indeg[i] > 0).collect();
        let a = stuck[0];
        let b = incoming[a]
            .iter()
            .map(|e| e.from_task)
            .find(|&f| leaves_of(p, f).iter().any(|x| stuck.contains(x)))
            .unwrap_or(a);
        roll_up(p);
        return ScheduleResult { circular: Some((p.tasks[a].calc.id, p.tasks[b].calc.id)) };
    }

    // ---- forward pass: early dates ----
    for &i in &order {
        let t = p.tasks[i].clone();
        if t.manual {
            let finish = if t.dur == 0 { t.start } else { finish_from_start(&cal, t.start, t.dur) };
            let tt = &mut p.tasks[i];
            tt.finish = finish;
            tt.calc.es = Some(t.start);
            tt.calc.ef = Some(finish);
            continue;
        }
        let mut start = proj_start;
        let mut conflict = false;
        for e in &incoming[i] {
            let (ps, pf) = if p.tasks[e.from_task].calc.summary {
                let lv = leaves_of(p, e.from_task);
                (
                    lv.iter().filter_map(|&j| p.tasks[j].calc.es).min().unwrap_or(proj_start),
                    lv.iter().filter_map(|&j| p.tasks[j].calc.ef).max().unwrap_or(proj_start),
                )
            } else {
                pred_dates(p, e.from_task, false)
            };
            let cand = match e.kind {
                LinkKind::FS => from_pred(&cal, pf, e.lag),
                LinkKind::SS => from_pred(&cal, ps, e.lag),
                LinkKind::FF => start_from_finish(&cal, from_pred(&cal, pf, e.lag), t.dur),
                LinkKind::SF => start_from_finish(&cal, from_pred(&cal, ps, e.lag), t.dur),
            };
            if cand > start {
                start = cand;
            }
        }
        let driven = start;
        if let Some(cd) = t.constraint_date {
            match t.constraint {
                Constraint::SNET => start = start.max(cd),
                Constraint::FNET => start = start.max(start_from_finish(&cal, cd, t.dur)),
                Constraint::MSO => start = cd,
                Constraint::MFO => start = start_from_finish(&cal, cd, t.dur),
                Constraint::SNLT => start = start.min(cd),
                Constraint::FNLT => start = start.min(start_from_finish(&cal, cd, t.dur)),
                _ => {}
            }
            if start < driven {
                conflict = true;
            }
        }
        if t.level_delay > 0 {
            start = cal.add_minutes(cal.next_work_start(start), t.level_delay);
        }
        if t.dur > 0 {
            start = cal.next_work_start(start);
        }
        let finish = finish_from_start(&cal, start, t.dur);
        let tt = &mut p.tasks[i];
        tt.start = start;
        tt.finish = finish;
        tt.calc.es = Some(start);
        tt.calc.ef = Some(finish);
        tt.calc.conflict = conflict;
    }

    // ---- backward pass: late dates ----
    let proj_finish = order
        .iter()
        .filter_map(|&i| p.tasks[i].calc.ef)
        .max()
        .unwrap_or(proj_start);
    for &i in order.iter().rev() {
        let t = p.tasks[i].clone();
        let mut lf = proj_finish;
        for (s, e) in &leaf_succ[i] {
            let (sls, slf) = pred_dates(p, *s, true);
            let cand_lf = match e.kind {
                LinkKind::FS => from_pred(&cal, sls, -e.lag),
                LinkKind::SS => finish_from_start(&cal, from_pred(&cal, sls, -e.lag), t.dur),
                LinkKind::FF => from_pred(&cal, slf, -e.lag),
                LinkKind::SF => finish_from_start(&cal, from_pred(&cal, slf, -e.lag), t.dur),
            };
            if cand_lf < lf {
                lf = cand_lf;
            }
        }
        if t.manual || matches!(t.constraint, Constraint::MSO | Constraint::MFO) {
            lf = lf.min(t.finish).max(t.finish);
        }
        if let Some(cd) = t.constraint_date {
            match t.constraint {
                Constraint::FNLT => lf = lf.min(cd),
                Constraint::SNLT => lf = lf.min(finish_from_start(&cal, cd, t.dur)),
                _ => {}
            }
        }
        if t.dur > 0 {
            lf = cal.prev_work_end(lf);
        }
        let ls = start_from_finish(&cal, lf, t.dur);
        let tt = &mut p.tasks[i];
        tt.calc.lf = Some(lf);
        tt.calc.ls = Some(ls);
    }

    // ---- as late as possible tasks take their late dates ----
    for &i in order.iter().rev() {
        let t = &p.tasks[i];
        if t.manual || t.constraint != Constraint::ALAP {
            continue;
        }
        // recompute against successors' current dates so chains of ALAP tasks pack late
        let mut lf = t.calc.lf.unwrap_or(t.finish);
        for (s, e) in &leaf_succ[i] {
            let st = &p.tasks[*s];
            let cand = match e.kind {
                LinkKind::FS => from_pred(&cal, st.start, -e.lag),
                LinkKind::FF => from_pred(&cal, st.finish, -e.lag),
                _ => lf,
            };
            lf = lf.min(cand);
        }
        let dur = t.dur;
        let lf = if dur > 0 { cal.prev_work_end(lf) } else { lf };
        let ls = start_from_finish(&cal, lf, dur);
        let es = t.calc.es.unwrap_or(t.start);
        if ls >= es {
            let tt = &mut p.tasks[i];
            tt.start = ls;
            tt.finish = lf;
        }
    }

    roll_up(p);

    // ---- slack and critical (Task.ComputeSlacks + PDM.SetDates) ----
    let crit_limit = p.critical_slack_days * p.minutes_per_day;
    for i in 0..n {
        let t = &p.tasks[i];
        let (Some(es), Some(ef), Some(ls), Some(lf)) = (t.calc.es, t.calc.ef, t.calc.ls, t.calc.lf)
        else {
            continue;
        };
        let start_slack = cal.work_between(es, ls).max(0);
        let finish_slack = cal.work_between(ef, lf).max(0);
        let total = if start_slack < finish_slack && t.percent == 0.0 { start_slack } else { finish_slack };
        let mut free: Option<i64> = None;
        if !t.calc.summary {
            for (s, e) in &leaf_succ[i] {
                if e.from_task != i {
                    continue;
                }
                let st = &p.tasks[*s];
                let (sse, sef) = (st.calc.es.unwrap_or(st.start), st.calc.ef.unwrap_or(st.finish));
                let gap = match e.kind {
                    LinkKind::FS => cal.work_between(from_pred(&cal, ef, e.lag), sse),
                    LinkKind::SS => cal.work_between(from_pred(&cal, es, e.lag), sse),
                    LinkKind::FF => cal.work_between(from_pred(&cal, ef, e.lag), sef),
                    LinkKind::SF => cal.work_between(from_pred(&cal, es, e.lag), sef),
                };
                free = Some(free.map_or(gap, |f: i64| f.min(gap)));
            }
        }
        let free = if t.complete() { 0 } else { free.unwrap_or(total).max(0).min(total) };
        let critical = t.active && total <= crit_limit;
        let tt = &mut p.tasks[i];
        tt.calc.total_slack = total;
        tt.calc.free_slack = free;
        tt.calc.critical = critical;
    }

    // ---- work, cost, indicators ----
    let today = Local::now().naive_local();
    let status = p.status_date.map(|d| cal.day_finish(d)).unwrap_or(today);
    for i in 0..n {
        if p.tasks[i].calc.summary {
            continue;
        }
        let (mut work, mut cost) = (0.0, p.tasks[i].fixed_cost);
        let dur = p.tasks[i].dur as f64;
        for a in &p.tasks[i].assign {
            let Some(ri) = p.res_index(a.res) else { continue };
            let r = &p.resources[ri];
            match r.kind {
                ResKind::Work => {
                    let w = dur * a.units;
                    work += w;
                    cost += w / 60.0 * r.std_rate + r.cost_per_use;
                }
                ResKind::Material => cost += a.units * r.std_rate + r.cost_per_use,
                ResKind::Cost => cost += r.cost_per_use,
            }
        }
        let t = &mut p.tasks[i];
        t.calc.work_min = work;
        t.calc.cost = cost;
        // expected progress by the status date
        let expected = if status <= t.start {
            0.0
        } else if status >= t.finish {
            100.0
        } else if t.dur > 0 {
            cal.work_between(t.start, status) as f64 / t.dur as f64 * 100.0
        } else {
            100.0
        };
        t.calc.late = t.percent + 0.5 < expected && t.finish < status;
        t.calc.missed_deadline = t.deadline.map(|d| t.finish.date() > d).unwrap_or(false);
    }
    for i in (0..n).rev() {
        if p.tasks[i].calc.summary {
            let lv = leaves_of(p, i);
            let w: f64 = lv.iter().map(|&j| p.tasks[j].calc.work_min).sum();
            let c: f64 = lv.iter().map(|&j| p.tasks[j].calc.cost).sum::<f64>() + p.tasks[i].fixed_cost;
            let late = lv.iter().any(|&j| p.tasks[j].calc.late);
            let t = &mut p.tasks[i];
            t.calc.work_min = w;
            t.calc.cost = c;
            t.calc.late = late;
            t.calc.missed_deadline = t.deadline.map(|d| t.finish.date() > d).unwrap_or(false);
        }
    }
    resource_totals(p);
    ScheduleResult { circular: None }
}

/// PercentCalculatorForSummaryTasks::SetPercent: setting % complete on a summary task.
/// 0 %, 100 % or subtasks without duration: every subtask gets the same %.
/// Otherwise the done share (sum of durations x % / 100) is filled into the subtasks in date
/// order, interval by interval between their start/finish points; tasks sharing an interval
/// share it; each subtask's % = its filled duration / its duration x 100 (max 100);
/// milestones before the last filled point become 100 %, later ones 0 %.
pub fn set_summary_percent(p: &mut Project, summary: usize, pct: f64) {
    let leaves: Vec<usize> = leaves_of(p, summary);
    if leaves.is_empty() {
        return;
    }
    let all_zero = leaves.iter().all(|&j| p.tasks[j].dur == 0);
    if pct <= 0.0 || pct >= 100.0 || all_zero {
        for &j in &leaves {
            p.tasks[j].percent = pct.clamp(0.0, 100.0);
        }
        return;
    }
    let cal = p.calendar.clone();
    let entire: f64 = leaves.iter().map(|&j| p.tasks[j].dur as f64).sum();
    let mut remaining = entire * pct / 100.0;
    let mut ticks: Vec<NaiveDateTime> = leaves.iter().flat_map(|&j| [p.tasks[j].start, p.tasks[j].finish]).collect();
    ticks.sort();
    ticks.dedup();
    let mut actual: std::collections::HashMap<usize, f64> = leaves.iter().map(|&j| (j, 0.0)).collect();
    let mut last_tick = ticks.first().copied().unwrap_or(p.start);
    for w in ticks.windows(2) {
        if remaining <= 0.0 {
            break;
        }
        let (a, b) = (w[0], w[1]);
        let inside: Vec<usize> = leaves
            .iter()
            .copied()
            .filter(|&j| p.tasks[j].dur > 0 && p.tasks[j].start <= a && p.tasks[j].finish >= b)
            .collect();
        if inside.is_empty() {
            continue;
        }
        let len = cal.work_between(a, b) as f64;
        let need = len * inside.len() as f64;
        let each = if remaining >= need { len } else { remaining / inside.len() as f64 };
        for &j in &inside {
            *actual.get_mut(&j).unwrap() += each;
        }
        remaining -= each * inside.len() as f64;
        last_tick = if each >= len { b } else { cal.add_minutes(a, each.round() as i64) };
    }
    for &j in &leaves {
        let t = &mut p.tasks[j];
        t.percent = if t.dur == 0 {
            if t.finish <= last_tick { 100.0 } else { 0.0 }
        } else {
            (actual[&j] / t.dur as f64 * 100.0).round().min(100.0)
        };
    }
}

/// Totals per resource and over-allocation (more units at once than Max Units).
pub fn resource_totals(p: &mut Project) {
    for (k, r) in p.resources.iter_mut().enumerate() {
        r.calc = ResCalc { id: k + 1, ..Default::default() };
    }
    let n = p.tasks.len();
    for ri in 0..p.resources.len() {
        let uid = p.resources[ri].uid;
        let mut events: Vec<(NaiveDateTime, f64, usize)> = vec![];
        let (mut work, mut cost) = (0.0, 0.0);
        for i in 0..n {
            let t = &p.tasks[i];
            if t.calc.summary {
                continue;
            }
            for a in &t.assign {
                if a.res != uid {
                    continue;
                }
                let r = &p.resources[ri];
                match r.kind {
                    ResKind::Work => {
                        let w = t.dur as f64 * a.units;
                        work += w;
                        cost += w / 60.0 * r.std_rate + r.cost_per_use;
                        if t.dur > 0 {
                            events.push((t.start, a.units, i));
                            events.push((t.finish, -a.units, i));
                        }
                    }
                    ResKind::Material => {
                        work += a.units;
                        cost += a.units * r.std_rate + r.cost_per_use;
                    }
                    ResKind::Cost => cost += r.cost_per_use,
                }
            }
        }
        events.sort_by(|a, b| a.0.cmp(&b.0).then(a.1.partial_cmp(&b.1).unwrap()));
        let max = p.resources[ri].max_units;
        let (mut cur, mut peak) = (0.0f64, 0.0f64);
        let mut active: Vec<usize> = vec![];
        let mut over_tasks: Vec<usize> = vec![];
        for (_, u, i) in &events {
            cur += u;
            if *u > 0.0 {
                active.push(*i);
            } else if let Some(pos) = active.iter().position(|x| x == i) {
                active.remove(pos);
            }
            peak = peak.max(cur);
            if cur > max + 1e-6 {
                over_tasks.extend(active.iter().copied());
            }
        }
        for i in over_tasks {
            p.tasks[i].calc.overallocated = true;
        }
        let r = &mut p.resources[ri];
        r.calc.work_min = work;
        r.calc.cost = cost;
        r.calc.peak = peak;
        r.calc.overallocated = peak > max + 1e-6;
    }
}

/// Level All: delays lower-priority tasks until no work resource is over its Max Units.
pub fn level_resources(p: &mut Project) -> usize {
    for t in p.tasks.iter_mut() {
        t.level_delay = 0;
    }
    schedule(p);
    let mut moves = 0;
    for _round in 0..400 {
        let mut found: Option<(usize, NaiveDateTime)> = None;
        'res: for ri in 0..p.resources.len() {
            let r = &p.resources[ri];
            if r.kind != ResKind::Work {
                continue;
            }
            let mut items: Vec<(usize, f64)> = vec![];
            for (i, t) in p.tasks.iter().enumerate() {
                if t.calc.summary || t.dur == 0 || t.manual || t.complete() {
                    continue;
                }
                if let Some(a) = t.assign.iter().find(|a| a.res == r.uid) {
                    items.push((i, a.units));
                }
            }
            items.sort_by(|a, b| {
                let (ta, tb) = (&p.tasks[a.0], &p.tasks[b.0]);
                ta.start.cmp(&tb.start).then(tb.priority.cmp(&ta.priority)).then(a.0.cmp(&b.0))
            });
            for x in 0..items.len() {
                for y in 0..x {
                    let (a, b) = (&p.tasks[items[y].0], &p.tasks[items[x].0]);
                    let overlap = b.start < a.finish && a.start < b.finish;
                    if overlap && items[x].1 + items[y].1 > r.max_units + 1e-6 {
                        // the later / lower-priority task waits until the other is done
                        let (wait, until) = if b.priority > a.priority && b.start == a.start {
                            (items[y].0, b.finish)
                        } else {
                            (items[x].0, a.finish)
                        };
                        found = Some((wait, until));
                        break 'res;
                    }
                }
            }
        }
        let Some((i, until)) = found else { break };
        let cal = p.calendar.clone();
        let extra = cal.work_between(p.tasks[i].start, cal.next_work_start(until)).max(1);
        p.tasks[i].level_delay += extra;
        moves += 1;
        schedule(p);
    }
    moves
}
