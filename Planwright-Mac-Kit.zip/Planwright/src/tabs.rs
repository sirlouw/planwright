//! Several projects open at once, as tabs along the top of the window (like browser tabs).
//! The active tab's project lives in PlanApp's own fields; the others wait in `tabs` as
//! DocState and are swapped in when their tab is clicked.

use crate::app::*;
use crate::model::Project;
use chrono::{Local, NaiveDate, NaiveDateTime};
use eframe::egui::{self, Align2, Color32, FontId, Pos2, Rect, Sense, Stroke, Vec2};
use std::path::PathBuf;

/// Everything that belongs to one open project.
pub struct DocState {
    pub p: Project,
    pub file: Option<PathBuf>,
    pub dirty: bool,
    pub undo: Vec<Project>,
    pub redo: Vec<Project>,
    pub sel: Vec<u32>,
    pub anchor: Option<u32>,
    pub sel_res: Option<u32>,
    pub view: View,
    pub filter: Filter,
    pub sort: SortBy,
    pub outline_limit: Option<u32>,
    pub px_per_day: f32,
    pub gantt_x: f32,
    pub cal_month: NaiveDate,
    pub circular: Option<(usize, usize)>,
}

impl DocState {
    pub fn fresh(p: Project, file: Option<PathBuf>) -> Self {
        let first = p.tasks.first().map(|t| t.uid);
        let today = Local::now().naive_local().date();
        DocState {
            p,
            file,
            dirty: false,
            undo: vec![],
            redo: vec![],
            sel: first.into_iter().collect(),
            anchor: first,
            sel_res: None,
            view: View::Gantt,
            filter: Filter::All,
            sort: SortBy::Id,
            outline_limit: None,
            px_per_day: 24.0,
            gantt_x: 0.0,
            cal_month: today.with_day0(0).unwrap_or(today),
            circular: None,
        }
    }

    pub fn label(&self) -> String {
        tab_name(&self.p, &self.file)
    }
}

trait Day0 {
    fn with_day0(&self, d: u32) -> Option<NaiveDate>;
}
impl Day0 for NaiveDate {
    fn with_day0(&self, d: u32) -> Option<NaiveDate> {
        use chrono::Datelike;
        self.with_day(d + 1)
    }
}

pub fn tab_name(p: &Project, file: &Option<PathBuf>) -> String {
    file.as_ref()
        .and_then(|f| f.file_stem())
        .map(|s| s.to_string_lossy().to_string())
        .unwrap_or_else(|| p.title.clone())
}

impl PlanApp {
    /// Moves the active project out of the app's fields (leaving an empty placeholder).
    fn swap_out(&mut self) -> DocState {
        let blank = Project::blank(NaiveDateTime::default());
        DocState {
            p: std::mem::replace(&mut self.p, blank),
            file: self.file.take(),
            dirty: self.dirty,
            undo: std::mem::take(&mut self.undo),
            redo: std::mem::take(&mut self.redo),
            sel: std::mem::take(&mut self.sel),
            anchor: self.anchor.take(),
            sel_res: self.sel_res.take(),
            view: self.view,
            filter: self.filter,
            sort: self.sort,
            outline_limit: self.outline_limit,
            px_per_day: self.px_per_day,
            gantt_x: self.gantt_x,
            cal_month: self.cal_month,
            circular: self.circular.take(),
        }
    }

    fn swap_in(&mut self, d: DocState) {
        self.p = d.p;
        self.file = d.file;
        self.dirty = d.dirty;
        self.undo = d.undo;
        self.redo = d.redo;
        self.sel = d.sel;
        self.anchor = d.anchor;
        self.sel_res = d.sel_res;
        self.view = d.view;
        self.filter = d.filter;
        self.sort = d.sort;
        self.outline_limit = d.outline_limit;
        self.px_per_day = d.px_per_day;
        self.gantt_x = d.gantt_x;
        self.cal_month = d.cal_month;
        self.circular = d.circular;
        self.edit = None;
        self.res_edit = None;
        self.drag = None;
        self.dlg.task = None;
        self.dlg.resource = None;
    }

    pub fn tab_label(&self, i: usize) -> (String, bool) {
        if i == self.active_tab {
            (tab_name(&self.p, &self.file), self.dirty)
        } else {
            match &self.tabs[i] {
                Some(d) => (d.label(), d.dirty),
                None => (String::new(), false),
            }
        }
    }

    pub fn switch_tab(&mut self, i: usize) {
        if i == self.active_tab || i >= self.tabs.len() {
            return;
        }
        let cur = self.swap_out();
        self.tabs[self.active_tab] = Some(cur);
        let next = self.tabs[i].take().expect("tab state");
        self.swap_in(next);
        self.active_tab = i;
        self.backstage = false;
        self.status = format!("Switched to {}", tab_name(&self.p, &self.file));
    }

    /// Opens a project in a new tab (or in this tab when it's an untouched empty project).
    pub fn open_project(&mut self, p: Project, file: Option<PathBuf>) {
        let pristine = self.p.tasks.is_empty() && !self.dirty && self.file.is_none() && self.undo.is_empty();
        if pristine {
            let d = DocState::fresh(p, file);
            self.swap_in(d);
        } else {
            let cur = self.swap_out();
            self.tabs[self.active_tab] = Some(cur);
            self.tabs.push(None);
            self.active_tab = self.tabs.len() - 1;
            self.swap_in(DocState::fresh(p, file));
        }
        self.recalc();
        self.backstage = false;
    }

    pub fn new_blank_tab(&mut self) {
        let s = Self::today_start(&self.p);
        let mut p = Project::blank(s);
        p.title = self.next_untitled();
        let cur = self.swap_out();
        self.tabs[self.active_tab] = Some(cur);
        self.tabs.push(None);
        self.active_tab = self.tabs.len() - 1;
        self.swap_in(DocState::fresh(p, None));
        self.recalc();
        self.backstage = false;
    }

    fn next_untitled(&self) -> String {
        let mut n = 1;
        loop {
            let name = format!("Project{n}");
            let taken = (0..self.tabs.len()).any(|i| self.tab_label(i).0 == name);
            if !taken {
                return name;
            }
            n += 1;
        }
    }

    /// Asks first when the tab has unsaved changes.
    pub fn request_close_tab(&mut self, i: usize) {
        let (_, dirty) = self.tab_label(i);
        if dirty {
            self.switch_tab(i);
            self.dlg.close_tab = Some(i);
        } else {
            self.close_tab(i);
        }
    }

    pub fn close_tab(&mut self, i: usize) {
        if i >= self.tabs.len() {
            return;
        }
        if self.tabs.len() == 1 {
            // closing the last tab leaves one empty project, like a fresh window
            let s = Self::today_start(&self.p);
            self.swap_in(DocState::fresh(Project::blank(s), None));
            self.recalc();
            return;
        }
        if i == self.active_tab {
            self.tabs.remove(i);
            let next = i.min(self.tabs.len() - 1);
            let d = self.tabs[next].take().expect("tab state");
            self.active_tab = next;
            self.swap_in(d);
        } else {
            self.tabs.remove(i);
            if i < self.active_tab {
                self.active_tab -= 1;
            }
        }
    }

    pub fn move_tab(&mut self, from: usize, to: usize) {
        if from == to || from >= self.tabs.len() || to >= self.tabs.len() {
            return;
        }
        let item = self.tabs.remove(from);
        self.tabs.insert(to, item);
        let a = self.active_tab;
        self.active_tab = if a == from {
            to
        } else if from < a && to >= a {
            a - 1
        } else if from > a && to <= a {
            a + 1
        } else {
            a
        };
    }

    pub fn any_unsaved(&self) -> usize {
        (0..self.tabs.len()).filter(|&i| self.tab_label(i).1).count()
    }

    pub fn tab_keyboard(&mut self, ctx: &egui::Context) {
        let (cmd, shift, ctrl) = ctx.input(|i| (i.modifiers.command, i.modifiers.shift, i.modifiers.ctrl));
        let pressed = |k: egui::Key| ctx.input(|i| i.key_pressed(k));
        if cmd && pressed(egui::Key::T) {
            self.new_blank_tab();
        } else if cmd && pressed(egui::Key::W) {
            self.request_close_tab(self.active_tab);
        } else if ctrl && pressed(egui::Key::Tab) {
            let n = self.tabs.len();
            let next = if shift { (self.active_tab + n - 1) % n } else { (self.active_tab + 1) % n };
            self.switch_tab(next);
        } else if cmd {
            // Cmd/Ctrl+1..9 jump to a tab (9 = last), as in browsers
            let keys = [
                egui::Key::Num1,
                egui::Key::Num2,
                egui::Key::Num3,
                egui::Key::Num4,
                egui::Key::Num5,
                egui::Key::Num6,
                egui::Key::Num7,
                egui::Key::Num8,
                egui::Key::Num9,
            ];
            for (k, key) in keys.iter().enumerate() {
                if pressed(*key) {
                    let target = if k == 8 { self.tabs.len() - 1 } else { k };
                    self.switch_tab(target);
                }
            }
        }
    }

    /// The strip of project tabs at the very top of the window.
    pub fn tab_strip(&mut self, ui: &mut egui::Ui) {
        let full = ui.available_rect_before_wrap();
        let h = 32.0;
        let strip = Rect::from_min_size(full.min, Vec2::new(full.width(), h));
        ui.allocate_rect(strip, Sense::hover());
        let painter = ui.painter().with_clip_rect(strip);
        painter.rect_filled(strip, 0.0, Color32::from_rgb(0xE4, 0xE7, 0xEA));
        let n = self.tabs.len();
        let plus_w = 34.0;
        let avail = (strip.width() - plus_w - 16.0).max(100.0);
        let tab_w = (avail / n as f32).clamp(60.0, 220.0);
        let mut x = strip.left() + 8.0;
        let mut switch_to = None;
        let mut close = None;
        let mut drop_move: Option<(usize, usize)> = None;
        let drag_id = ui.make_persistent_id("tab_drag");
        let dragging: Option<usize> = ui.data(|d| d.get_temp(drag_id));
        for i in 0..n {
            let (label, dirty) = self.tab_label(i);
            let r = Rect::from_min_size(Pos2::new(x, strip.top() + 5.0), Vec2::new(tab_w - 2.0, h - 5.0));
            let active = i == self.active_tab;
            let resp = ui.interact(r, ui.make_persistent_id(("tab", i)), Sense::click_and_drag());
            let fill = if active {
                Color32::WHITE
            } else if resp.hovered() {
                Color32::from_rgb(0xF0, 0xF2, 0xF4)
            } else {
                Color32::from_rgb(0xE4, 0xE7, 0xEA)
            };
            painter.rect_filled(r, egui::CornerRadius { nw: 7, ne: 7, sw: 0, se: 0 }, fill);
            if active {
                painter.rect_filled(Rect::from_min_size(r.min, Vec2::new(r.width(), 2.5)), 1.0, ACCENT);
            } else if i + 1 != self.active_tab && i + 1 < n {
                painter.line_segment(
                    [Pos2::new(r.right() + 1.0, r.top() + 6.0), Pos2::new(r.right() + 1.0, r.bottom() - 6.0)],
                    Stroke::new(1.0, Color32::from_gray(185)),
                );
            }
            // little Gantt icon
            let ic = r.left_center() + Vec2::new(12.0, 0.0);
            for k in 0..3 {
                let y = ic.y - 5.0 + k as f32 * 4.0;
                let x0 = ic.x - 5.0 + k as f32 * 3.0;
                painter.rect_filled(Rect::from_min_size(Pos2::new(x0, y), Vec2::new(6.0, 2.5)), 0.5, if active { ACCENT } else { Color32::from_gray(120) });
            }
            // title
            let close_r = Rect::from_center_size(r.right_center() - Vec2::new(14.0, 0.0), Vec2::splat(18.0));
            let text_clip = Rect::from_min_max(Pos2::new(r.left() + 24.0, r.top()), Pos2::new(close_r.left() - 2.0, r.bottom()));
            painter.with_clip_rect(text_clip.intersect(strip)).text(
                Pos2::new(r.left() + 24.0, r.center().y),
                Align2::LEFT_CENTER,
                &label,
                FontId::proportional(12.5),
                if active { Color32::from_gray(20) } else { Color32::from_gray(70) },
            );
            // × (or a dot for unsaved changes when not hovered)
            let close_resp = ui.interact(close_r, ui.make_persistent_id(("tabx", i)), Sense::click());
            if close_resp.hovered() {
                painter.circle_filled(close_r.center(), 8.0, Color32::from_gray(205));
            }
            if dirty && !close_resp.hovered() && !resp.hovered() {
                painter.circle_filled(close_r.center(), 3.5, Color32::from_gray(90));
            } else if active || resp.hovered() || close_resp.hovered() {
                painter.text(close_r.center(), Align2::CENTER_CENTER, "×", FontId::proportional(15.0), Color32::from_gray(60));
            }
            if close_resp.clicked() {
                close = Some(i);
            } else if resp.clicked() {
                switch_to = Some(i);
            }
            if resp.middle_clicked() {
                close = Some(i);
            }
            let tip = if dirty { format!("{label} - unsaved changes") } else { label.clone() };
            let full_tip = match (i == self.active_tab, &self.file) {
                (true, Some(f)) => format!("{tip}\n{}", f.display()),
                _ => tip,
            };
            resp.clone().on_hover_text(full_tip);
            // drag to reorder
            if resp.drag_started() {
                ui.data_mut(|d| d.insert_temp(drag_id, i));
            }
            if let (Some(from), Some(pos)) = (dragging, ui.ctx().pointer_latest_pos()) {
                if from != i && r.contains(Pos2::new(pos.x, r.center().y)) && resp.hovered() {
                    painter.rect_filled(Rect::from_min_size(Pos2::new(if from > i { r.left() } else { r.right() - 2.0 }, r.top()), Vec2::new(2.0, r.height())), 0.0, ACCENT);
                }
                if ui.input(|inp| inp.pointer.any_released()) && from != i && pos.x >= r.left() && pos.x < r.right() {
                    drop_move = Some((from, i));
                }
            }
            resp.context_menu(|ui| {
                if ui.button("New tab").clicked() {
                    self.new_blank_tab();
                    ui.close();
                }
                if ui.button("Duplicate tab").clicked() {
                    self.switch_tab(i);
                    let mut copy = self.p.clone();
                    copy.title = format!("{} copy", copy.title);
                    self.open_project(copy, None);
                    self.dirty = true;
                    ui.close();
                }
                if ui.button("Close tab").clicked() {
                    self.request_close_tab(i);
                    ui.close();
                }
                if ui.add_enabled(self.tabs.len() > 1, egui::Button::new("Close other tabs")).clicked() {
                    self.switch_tab(i);
                    let mut k = self.tabs.len();
                    while k > 0 {
                        k -= 1;
                        if k != self.active_tab && !self.tab_label(k).1 {
                            self.close_tab(k);
                        }
                    }
                    if self.tabs.len() > 1 {
                        self.status = "Tabs with unsaved changes were kept open".into();
                    }
                    ui.close();
                }
            });
            x += tab_w;
        }
        if ui.input(|inp| inp.pointer.any_released()) {
            ui.data_mut(|d| d.remove::<usize>(drag_id));
        }
        // + new tab
        let pr = Rect::from_center_size(Pos2::new(x + plus_w / 2.0, strip.center().y + 2.0), Vec2::splat(26.0));
        let presp = ui.interact(pr, ui.make_persistent_id("tab_plus"), Sense::click());
        if presp.hovered() {
            painter.circle_filled(pr.center(), 13.0, Color32::from_gray(210));
        }
        painter.text(pr.center(), Align2::CENTER_CENTER, "+", FontId::proportional(20.0), Color32::from_gray(50));
        let presp = presp.on_hover_text("New project tab (Ctrl+T / ⌘T)");
        if presp.clicked() {
            self.new_blank_tab();
        }
        if let Some((from, to)) = drop_move {
            self.move_tab(from, to);
        } else if let Some(i) = close {
            self.request_close_tab(i);
        } else if let Some(i) = switch_to {
            self.switch_tab(i);
        }
    }

    /// "Save changes?" when closing a tab, and when quitting with unsaved tabs.
    pub fn tab_dialogs(&mut self, ctx: &egui::Context) {
        if let Some(i) = self.dlg.close_tab {
            let (name, _) = self.tab_label(i);
            let mut choice = None;
            egui::Window::new("Close project")
                .collapsible(false)
                .resizable(false)
                .anchor(Align2::CENTER_CENTER, Vec2::ZERO)
                .show(ctx, |ui| {
                    ui.label(format!("Save the changes to \"{name}\" before closing?"));
                    ui.add_space(8.0);
                    ui.horizontal(|ui| {
                        if ui.add(egui::Button::new(egui::RichText::new("  Save  ").color(Color32::WHITE)).fill(ACCENT)).clicked() {
                            choice = Some(0);
                        }
                        if ui.button("Don't Save").clicked() {
                            choice = Some(1);
                        }
                        if ui.button("Cancel").clicked() {
                            choice = Some(2);
                        }
                    });
                });
            match choice {
                Some(0) => {
                    self.dlg.close_tab = None;
                    if self.save(false) {
                        self.close_tab(i);
                    }
                }
                Some(1) => {
                    self.dlg.close_tab = None;
                    self.close_tab(i);
                }
                Some(2) => self.dlg.close_tab = None,
                _ => {}
            }
        }

        // quitting the app with unsaved tabs
        if self.screenshot.is_none() && !self.allow_quit && ctx.input(|i| i.viewport().close_requested()) && self.any_unsaved() > 0 {
            ctx.send_viewport_cmd(egui::ViewportCommand::CancelClose);
            self.dlg.quit = true;
        }
        if self.dlg.quit {
            let n = self.any_unsaved();
            let mut choice = None;
            egui::Window::new("Quit Planwright")
                .collapsible(false)
                .resizable(false)
                .anchor(Align2::CENTER_CENTER, Vec2::ZERO)
                .show(ctx, |ui| {
                    ui.label(if n == 1 { "1 open project has unsaved changes.".to_string() } else { format!("{n} open projects have unsaved changes.") });
                    ui.add_space(8.0);
                    ui.horizontal(|ui| {
                        if ui.add(egui::Button::new(egui::RichText::new("  Review  ").color(Color32::WHITE)).fill(ACCENT)).clicked() {
                            choice = Some(0);
                        }
                        if ui.button("Quit Without Saving").clicked() {
                            choice = Some(1);
                        }
                        if ui.button("Cancel").clicked() {
                            choice = Some(2);
                        }
                    });
                });
            match choice {
                Some(0) => {
                    self.dlg.quit = false;
                    if let Some(i) = (0..self.tabs.len()).find(|&i| self.tab_label(i).1) {
                        self.request_close_tab(i);
                    }
                }
                Some(1) => {
                    self.dlg.quit = false;
                    self.allow_quit = true;
                    ctx.send_viewport_cmd(egui::ViewportCommand::Close);
                }
                Some(2) => self.dlg.quit = false,
                _ => {}
            }
        }
    }
}
