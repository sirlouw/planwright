//! Files: the app's own project file (JSON), Microsoft Project XML (MSPDI)
//! import/export, and CSV export of the task table.

use crate::calendar::{Exception, WorkCalendar};
use crate::model::*;
#[cfg(test)]
use chrono::NaiveDate;
use chrono::NaiveDateTime;
use quick_xml::events::Event;
use quick_xml::Reader;
use std::collections::HashMap;
use std::path::Path;

pub fn save_json(p: &Project, path: &Path) -> Result<(), String> {
    let s = serde_json::to_string_pretty(p).map_err(|e| e.to_string())?;
    std::fs::write(path, s).map_err(|e| e.to_string())
}

pub fn load_json(path: &Path) -> Result<Project, String> {
    let s = std::fs::read_to_string(path).map_err(|e| e.to_string())?;
    serde_json::from_str(&s).map_err(|e| format!("This file isn't a project file: {e}"))
}

fn csv_cell(s: &str) -> String {
    if s.contains([',', '"', '\n']) {
        format!("\"{}\"", s.replace('"', "\"\""))
    } else {
        s.to_string()
    }
}

pub fn export_csv(p: &Project, path: &Path) -> Result<(), String> {
    let mut out = String::from(
        "ID,WBS,Outline Level,Task Mode,Task Name,Duration,Start,Finish,Predecessors,Resource Names,% Complete,Work,Cost,Total Slack,Critical\n",
    );
    for t in &p.tasks {
        let row = [
            t.calc.id.to_string(),
            t.calc.wbs.clone(),
            t.level.to_string(),
            if t.manual { "Manually Scheduled" } else { "Auto Scheduled" }.to_string(),
            t.name.clone(),
            p.fmt_duration(t.dur, t.estimated),
            fmt_date(t.start),
            fmt_date(t.finish),
            p.fmt_preds(t),
            p.fmt_resources(t),
            format!("{}%", fmt_num(t.percent)),
            fmt_work(t.calc.work_min),
            p.money(t.calc.cost),
            p.fmt_duration(t.calc.total_slack, false),
            if t.calc.critical { "Yes" } else { "No" }.to_string(),
        ];
        out.push_str(&row.iter().map(|c| csv_cell(c)).collect::<Vec<_>>().join(","));
        out.push('\n');
    }
    std::fs::write(path, out).map_err(|e| e.to_string())
}

// ---------------- Microsoft Project XML ----------------

fn esc(s: &str) -> String {
    s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;").replace('"', "&quot;")
}

fn xml_dt(d: NaiveDateTime) -> String {
    d.format("%Y-%m-%dT%H:%M:%S").to_string()
}

fn xml_dur(minutes: i64) -> String {
    let m = minutes.abs();
    format!("PT{}H{}M0S", m / 60, m % 60)
}

fn link_code(k: LinkKind) -> u32 {
    match k {
        LinkKind::FF => 0,
        LinkKind::FS => 1,
        LinkKind::SF => 2,
        LinkKind::SS => 3,
    }
}

fn constraint_code(c: Constraint) -> u32 {
    match c {
        Constraint::ASAP => 0,
        Constraint::ALAP => 1,
        Constraint::MSO => 2,
        Constraint::MFO => 3,
        Constraint::SNET => 4,
        Constraint::SNLT => 5,
        Constraint::FNET => 6,
        Constraint::FNLT => 7,
    }
}

fn constraint_from(code: u32) -> Constraint {
    match code {
        1 => Constraint::ALAP,
        2 => Constraint::MSO,
        3 => Constraint::MFO,
        4 => Constraint::SNET,
        5 => Constraint::SNLT,
        6 => Constraint::FNET,
        7 => Constraint::FNLT,
        _ => Constraint::ASAP,
    }
}

pub fn export_xml(p: &Project, path: &Path) -> Result<(), String> {
    let mut x = String::new();
    x.push_str("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n");
    x.push_str("<Project xmlns=\"http://schemas.microsoft.com/project\">\n");
    x.push_str(&format!("  <Title>{}</Title>\n", esc(&p.title)));
    x.push_str(&format!("  <Manager>{}</Manager>\n", esc(&p.manager)));
    x.push_str(&format!("  <Company>{}</Company>\n", esc(&p.company)));
    x.push_str("  <ScheduleFromStart>1</ScheduleFromStart>\n");
    x.push_str(&format!("  <StartDate>{}</StartDate>\n", xml_dt(p.start)));
    x.push_str(&format!("  <FinishDate>{}</FinishDate>\n", xml_dt(p.finish())));
    x.push_str("  <CalendarUID>1</CalendarUID>\n");
    x.push_str(&format!("  <MinutesPerDay>{}</MinutesPerDay>\n", p.minutes_per_day));
    x.push_str(&format!("  <MinutesPerWeek>{}</MinutesPerWeek>\n", p.minutes_per_week));
    x.push_str(&format!("  <DaysPerMonth>{}</DaysPerMonth>\n", p.days_per_month));
    x.push_str(&format!("  <CurrencySymbol>{}</CurrencySymbol>\n", esc(&p.currency)));
    // calendar
    x.push_str("  <Calendars>\n    <Calendar>\n      <UID>1</UID>\n");
    x.push_str(&format!("      <Name>{}</Name>\n      <IsBaseCalendar>1</IsBaseCalendar>\n      <WeekDays>\n", esc(&p.calendar.name)));
    for (k, iv) in p.calendar.week.iter().enumerate() {
        let day_type = (k + 1) % 7 + 1; // MSPDI: 1 = Sunday
        x.push_str(&format!(
            "        <WeekDay>\n          <DayType>{}</DayType>\n          <DayWorking>{}</DayWorking>\n",
            day_type,
            if iv.is_empty() { 0 } else { 1 }
        ));
        if !iv.is_empty() {
            x.push_str("          <WorkingTimes>\n");
            for (s, e) in iv {
                x.push_str(&format!(
                    "            <WorkingTime><FromTime>{:02}:{:02}:00</FromTime><ToTime>{:02}:{:02}:00</ToTime></WorkingTime>\n",
                    s / 60,
                    s % 60,
                    (e / 60) % 24,
                    e % 60
                ));
            }
            x.push_str("          </WorkingTimes>\n");
        }
        x.push_str("        </WeekDay>\n");
    }
    for ex in &p.calendar.exceptions {
        x.push_str(&format!(
            "        <WeekDay>\n          <DayType>0</DayType>\n          <DayWorking>0</DayWorking>\n          <TimePeriod><FromDate>{}T00:00:00</FromDate><ToDate>{}T23:59:00</ToDate></TimePeriod>\n        </WeekDay>\n",
            ex.from.format("%Y-%m-%d"),
            ex.to.format("%Y-%m-%d")
        ));
    }
    x.push_str("      </WeekDays>\n    </Calendar>\n  </Calendars>\n");
    // tasks
    x.push_str("  <Tasks>\n");
    for t in &p.tasks {
        x.push_str("    <Task>\n");
        x.push_str(&format!("      <UID>{}</UID>\n      <ID>{}</ID>\n", t.uid, t.calc.id));
        x.push_str(&format!("      <Name>{}</Name>\n", esc(&t.name)));
        x.push_str(&format!("      <WBS>{}</WBS>\n      <OutlineLevel>{}</OutlineLevel>\n", t.calc.wbs, t.level));
        x.push_str(&format!("      <Manual>{}</Manual>\n", if t.manual { 1 } else { 0 }));
        x.push_str(&format!("      <Active>{}</Active>\n", if t.active { 1 } else { 0 }));
        x.push_str(&format!("      <Summary>{}</Summary>\n", if t.calc.summary { 1 } else { 0 }));
        x.push_str(&format!("      <Milestone>{}</Milestone>\n", if t.is_milestone() { 1 } else { 0 }));
        x.push_str(&format!("      <Critical>{}</Critical>\n", if t.calc.critical { 1 } else { 0 }));
        x.push_str(&format!("      <Priority>{}</Priority>\n", t.priority));
        x.push_str(&format!("      <Start>{}</Start>\n      <Finish>{}</Finish>\n", xml_dt(t.start), xml_dt(t.finish)));
        x.push_str(&format!("      <Duration>{}</Duration>\n      <DurationFormat>7</DurationFormat>\n", xml_dur(t.dur)));
        x.push_str(&format!("      <Estimated>{}</Estimated>\n", if t.estimated { 1 } else { 0 }));
        x.push_str(&format!("      <PercentComplete>{}</PercentComplete>\n", t.percent.round() as i64));
        x.push_str(&format!("      <FixedCost>{}</FixedCost>\n", t.fixed_cost));
        x.push_str(&format!("      <ConstraintType>{}</ConstraintType>\n", constraint_code(t.constraint)));
        if let Some(cd) = t.constraint_date {
            x.push_str(&format!("      <ConstraintDate>{}</ConstraintDate>\n", xml_dt(cd)));
        }
        if let Some(d) = t.deadline {
            x.push_str(&format!("      <Deadline>{}T17:00:00</Deadline>\n", d.format("%Y-%m-%d")));
        }
        if !t.notes.is_empty() {
            x.push_str(&format!("      <Notes>{}</Notes>\n", esc(&t.notes)));
        }
        for l in &t.links {
            x.push_str(&format!(
                "      <PredecessorLink>\n        <PredecessorUID>{}</PredecessorUID>\n        <Type>{}</Type>\n        <LinkLag>{}</LinkLag>\n        <LagFormat>7</LagFormat>\n      </PredecessorLink>\n",
                l.pred,
                link_code(l.kind),
                l.lag * 10
            ));
        }
        if let Some(b) = &t.baseline {
            x.push_str(&format!(
                "      <Baseline>\n        <Number>0</Number>\n        <Start>{}</Start>\n        <Finish>{}</Finish>\n        <Duration>{}</Duration>\n        <Cost>{}</Cost>\n      </Baseline>\n",
                xml_dt(b.start),
                xml_dt(b.finish),
                xml_dur(b.dur),
                b.cost
            ));
        }
        x.push_str("    </Task>\n");
    }
    x.push_str("  </Tasks>\n  <Resources>\n");
    for r in &p.resources {
        let typ = match r.kind {
            ResKind::Material => 0,
            ResKind::Work => 1,
            ResKind::Cost => 2,
        };
        x.push_str(&format!(
            "    <Resource>\n      <UID>{}</UID>\n      <ID>{}</ID>\n      <Name>{}</Name>\n      <Type>{}</Type>\n      <Initials>{}</Initials>\n      <Group>{}</Group>\n      <MaterialLabel>{}</MaterialLabel>\n      <MaxUnits>{}</MaxUnits>\n      <StandardRate>{}</StandardRate>\n      <OvertimeRate>{}</OvertimeRate>\n      <CostPerUse>{}</CostPerUse>\n      <EmailAddress>{}</EmailAddress>\n    </Resource>\n",
            r.uid,
            r.calc.id,
            esc(&r.name),
            typ,
            esc(&r.initials),
            esc(&r.group),
            esc(&r.material_label),
            r.max_units,
            r.std_rate,
            r.ovt_rate,
            r.cost_per_use,
            esc(&r.email)
        ));
    }
    x.push_str("  </Resources>\n  <Assignments>\n");
    let mut auid = 1;
    for t in &p.tasks {
        for a in &t.assign {
            x.push_str(&format!(
                "    <Assignment>\n      <UID>{}</UID>\n      <TaskUID>{}</TaskUID>\n      <ResourceUID>{}</ResourceUID>\n      <Units>{}</Units>\n    </Assignment>\n",
                auid, t.uid, a.res, a.units
            ));
            auid += 1;
        }
    }
    x.push_str("  </Assignments>\n</Project>\n");
    std::fs::write(path, x).map_err(|e| e.to_string())
}

/// MSPDI durations look like PT16H0M0S (also P1DT2H0M0S).
fn parse_xml_dur(s: &str) -> i64 {
    let s = s.trim();
    let mut total = 0f64;
    let mut num = String::new();
    let mut in_time = false;
    for c in s.chars() {
        match c {
            'P' => {}
            'T' => in_time = true,
            '0'..='9' | '.' | '-' => num.push(c),
            'D' => {
                total += num.parse::<f64>().unwrap_or(0.0) * 480.0;
                num.clear();
            }
            'H' => {
                total += num.parse::<f64>().unwrap_or(0.0) * 60.0;
                num.clear();
            }
            'M' => {
                let v = num.parse::<f64>().unwrap_or(0.0);
                total += if in_time { v } else { v * 480.0 * 20.0 };
                num.clear();
            }
            'S' => {
                total += num.parse::<f64>().unwrap_or(0.0) / 60.0;
                num.clear();
            }
            _ => {}
        }
    }
    total.round() as i64
}

fn parse_xml_dt(s: &str) -> Option<NaiveDateTime> {
    NaiveDateTime::parse_from_str(s.trim(), "%Y-%m-%dT%H:%M:%S").ok()
}

type Rec = HashMap<String, String>;

pub fn import_xml(path: &Path) -> Result<Project, String> {
    let text = std::fs::read_to_string(path).map_err(|e| e.to_string())?;
    let mut reader = Reader::from_str(&text);
    reader.config_mut().trim_text(false);
    let mut stack: Vec<String> = vec![];
    let mut header: Rec = HashMap::new();
    let mut tasks: Vec<(Rec, Vec<Rec>)> = vec![];
    let mut resources: Vec<Rec> = vec![];
    let mut assigns: Vec<Rec> = vec![];
    let mut weekdays: Vec<(Rec, Vec<(String, String)>)> = vec![];
    let mut cur: Rec = HashMap::new();
    let mut cur_link: Rec = HashMap::new();
    let mut cur_links: Vec<Rec> = vec![];
    let mut cur_times: Vec<(String, String)> = vec![];
    let mut cur_from = String::new();
    let mut cal_count = 0;
    let mut text_buf = String::new();
    loop {
        match reader.read_event() {
            Ok(Event::Start(e)) => {
                text_buf.clear();
                let ln = e.local_name();
                let name: String = AsRef::<str>::as_ref(&ln).to_string();
                match name.as_str() {
                    "Task" | "Resource" | "Assignment" => {
                        cur = HashMap::new();
                        cur_links.clear();
                    }
                    "WeekDay" => {
                        cur = HashMap::new();
                        cur_times.clear();
                    }
                    "PredecessorLink" => cur_link = HashMap::new(),
                    "Calendar" => cal_count += 1,
                    _ => {}
                }
                stack.push(name);
            }
            Ok(Event::End(_)) => {
                if !text_buf.is_empty() {
                    let v = std::mem::take(&mut text_buf).trim().to_string();
                    let tag = stack.last().cloned().unwrap_or_default();
                    let parent = if stack.len() >= 2 { stack[stack.len() - 2].clone() } else { String::new() };
                    if parent == "Project" {
                        header.insert(tag, v);
                    } else if parent == "PredecessorLink" {
                        cur_link.insert(tag, v);
                    } else if parent == "WorkingTime" {
                        if tag == "FromTime" {
                            cur_from = v;
                        } else if tag == "ToTime" {
                            cur_times.push((cur_from.clone(), v));
                        }
                    } else if parent == "TimePeriod" {
                        cur.insert(format!("TP{tag}"), v);
                    } else if matches!(parent.as_str(), "Task" | "Resource" | "Assignment" | "WeekDay") {
                        cur.insert(tag, v);
                    }
                }
                let name = stack.pop().unwrap_or_default();
                let parent = stack.last().cloned().unwrap_or_default();
                match name.as_str() {
                    "Task" if parent == "Tasks" => tasks.push((cur.clone(), cur_links.clone())),
                    "Resource" if parent == "Resources" => resources.push(cur.clone()),
                    "Assignment" if parent == "Assignments" => assigns.push(cur.clone()),
                    "WeekDay" if cal_count == 1 => weekdays.push((cur.clone(), cur_times.clone())),
                    "PredecessorLink" => cur_links.push(cur_link.clone()),
                    _ => {}
                }
            }
            Ok(Event::Text(t)) => {
                text_buf.push_str(&t.xml10_content());
            }
            Ok(Event::CData(t)) => {
                let inner = t.into_inner();
                let s: &str = inner.as_ref();
                text_buf.push_str(s);
            }
            Ok(Event::GeneralRef(r)) => {
                if let Ok(Some(c)) = r.resolve_char_ref() {
                    text_buf.push(c);
                } else {
                    let name = r.xml10_content();
                    text_buf.push_str(match name.as_ref() {
                        "amp" => "&",
                        "lt" => "<",
                        "gt" => ">",
                        "quot" => "\"",
                        "apos" => "'",
                        _ => "",
                    });
                }
            }
            Ok(Event::Eof) => break,
            Err(e) => return Err(format!("Couldn't read this XML file: {e}")),
            _ => {}
        }
    }
    if tasks.is_empty() && resources.is_empty() {
        return Err("No Microsoft Project tasks were found in this file.".into());
    }
    let start = header
        .get("StartDate")
        .and_then(|s| parse_xml_dt(s))
        .unwrap_or_else(|| chrono::Local::now().naive_local());
    let mut p = Project::blank(start);
    if let Some(t) = header.get("Title") {
        p.title = t.clone();
    } else if let Some(stem) = path.file_stem() {
        p.title = stem.to_string_lossy().to_string();
    }
    p.manager = header.get("Manager").cloned().unwrap_or_default();
    p.company = header.get("Company").cloned().unwrap_or_default();
    if let Some(v) = header.get("MinutesPerDay").and_then(|v| v.parse().ok()) {
        p.minutes_per_day = v;
    }
    if let Some(v) = header.get("MinutesPerWeek").and_then(|v| v.parse().ok()) {
        p.minutes_per_week = v;
    }
    if let Some(v) = header.get("DaysPerMonth").and_then(|v| v.parse().ok()) {
        p.days_per_month = v;
    }
    if let Some(c) = header.get("CurrencySymbol") {
        p.currency = c.clone();
    }
    // calendar
    if !weekdays.is_empty() {
        let mut cal = WorkCalendar::standard();
        for (w, times) in &weekdays {
            let dt: usize = w.get("DayType").and_then(|v| v.parse().ok()).unwrap_or(0);
            let working = w.get("DayWorking").map(|v| v == "1").unwrap_or(false);
            if dt == 0 {
                let from = w.get("TPFromDate").and_then(|s| parse_xml_dt(s)).map(|d| d.date());
                let to = w.get("TPToDate").and_then(|s| parse_xml_dt(s)).map(|d| d.date());
                if let (Some(f), Some(t), false) = (from, to, working) {
                    cal.exceptions.push(Exception { name: "Exception".into(), from: f, to: t });
                }
                continue;
            }
            let k = (dt + 5) % 7; // 1 = Sunday -> 6
            let mut iv = vec![];
            if working {
                for (f, t) in times {
                    let pm = |s: &str| {
                        let parts: Vec<u32> = s.split(':').filter_map(|x| x.parse().ok()).collect();
                        parts.first().copied().unwrap_or(0) * 60 + parts.get(1).copied().unwrap_or(0)
                    };
                    let (a, mut b) = (pm(f), pm(t));
                    if b == 0 {
                        b = 24 * 60;
                    }
                    if b > a {
                        iv.push((a, b));
                    }
                }
            }
            if !working || !iv.is_empty() {
                cal.week[k] = iv;
            }
        }
        p.calendar = cal;
    }
    // resources
    for r in &resources {
        let Some(uid) = r.get("UID").and_then(|v| v.parse::<u32>().ok()) else { continue };
        let Some(name) = r.get("Name") else { continue };
        if uid == 0 {
            continue;
        }
        let mut res = Resource::new(uid, name);
        res.kind = match r.get("Type").map(|s| s.as_str()) {
            Some("0") => ResKind::Material,
            Some("2") => ResKind::Cost,
            _ => ResKind::Work,
        };
        let f = |k: &str| r.get(k).and_then(|v| v.parse::<f64>().ok());
        if let Some(v) = f("MaxUnits") {
            res.max_units = v;
        }
        if let Some(v) = f("StandardRate") {
            res.std_rate = v;
        }
        if let Some(v) = f("OvertimeRate") {
            res.ovt_rate = v;
        }
        if let Some(v) = f("CostPerUse") {
            res.cost_per_use = v;
        }
        res.initials = r.get("Initials").cloned().unwrap_or(res.initials);
        res.group = r.get("Group").cloned().unwrap_or_default();
        res.material_label = r.get("MaterialLabel").cloned().unwrap_or_default();
        res.email = r.get("EmailAddress").cloned().unwrap_or_default();
        p.next_res_uid = p.next_res_uid.max(uid + 1);
        p.resources.push(res);
    }
    // tasks
    for (t, links) in &tasks {
        let Some(uid) = t.get("UID").and_then(|v| v.parse::<u32>().ok()) else { continue };
        let level: u32 = t.get("OutlineLevel").and_then(|v| v.parse().ok()).unwrap_or(1);
        if uid == 0 || level == 0 {
            continue; // project summary task
        }
        let name = t.get("Name").cloned().unwrap_or_default();
        let s = t.get("Start").and_then(|s| parse_xml_dt(s)).unwrap_or(start);
        let mut task = Task::new(uid, &name, s, t.get("Duration").map(|d| parse_xml_dur(d)).unwrap_or(480));
        task.level = level;
        task.finish = t.get("Finish").and_then(|s| parse_xml_dt(s)).unwrap_or(s);
        task.manual = t.get("Manual").map(|v| v == "1").unwrap_or(false);
        task.active = t.get("Active").map(|v| v != "0").unwrap_or(true);
        task.estimated = t.get("Estimated").map(|v| v == "1").unwrap_or(false);
        task.percent = t.get("PercentComplete").and_then(|v| v.parse().ok()).unwrap_or(0.0);
        task.priority = t.get("Priority").and_then(|v| v.parse().ok()).unwrap_or(500);
        task.fixed_cost = t.get("FixedCost").and_then(|v| v.parse().ok()).unwrap_or(0.0);
        task.constraint = constraint_from(t.get("ConstraintType").and_then(|v| v.parse().ok()).unwrap_or(0));
        task.constraint_date = t.get("ConstraintDate").and_then(|s| parse_xml_dt(s));
        task.deadline = t.get("Deadline").and_then(|s| parse_xml_dt(s)).map(|d| d.date());
        task.notes = t.get("Notes").cloned().unwrap_or_default();
        task.milestone_flag = t.get("Milestone").map(|v| v == "1").unwrap_or(false) && task.dur > 0;
        for l in links {
            let Some(pred) = l.get("PredecessorUID").and_then(|v| v.parse::<u32>().ok()) else { continue };
            let kind = match l.get("Type").map(|s| s.as_str()) {
                Some("0") => LinkKind::FF,
                Some("2") => LinkKind::SF,
                Some("3") => LinkKind::SS,
                _ => LinkKind::FS,
            };
            let lag = l.get("LinkLag").and_then(|v| v.parse::<i64>().ok()).unwrap_or(0) / 10;
            task.links.push(Link { pred, kind, lag });
        }
        p.next_uid = p.next_uid.max(uid + 1);
        p.tasks.push(task);
    }
    for a in &assigns {
        let tu = a.get("TaskUID").and_then(|v| v.parse::<u32>().ok());
        let ru = a.get("ResourceUID").and_then(|v| v.parse::<u32>().ok());
        let units = a.get("Units").and_then(|v| v.parse::<f64>().ok()).unwrap_or(1.0);
        if let (Some(tu), Some(ru)) = (tu, ru) {
            if p.res_index(ru).is_none() {
                continue;
            }
            if let Some(ti) = p.index_of(tu) {
                p.tasks[ti].assign.push(Assignment { res: ru, units });
            }
        }
    }
    Ok(p)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn xml_round_trip_keeps_dates() {
        let monday = NaiveDate::from_ymd_opt(2026, 11, 16).unwrap();
        let mut p = crate::samples::website_launch(monday);
        p.title = "R&D <plan>".into();
        crate::schedule::schedule(&mut p);
        let dir = std::env::temp_dir().join("planwright_test.xml");
        export_xml(&p, &dir).unwrap();
        let mut q = import_xml(&dir).unwrap();
        crate::schedule::schedule(&mut q);
        assert_eq!(q.title, "R&D <plan>");
        assert_eq!(q.tasks.len(), p.tasks.len());
        assert_eq!(q.finish(), p.finish());
        for (a, b) in p.tasks.iter().zip(q.tasks.iter()) {
            assert_eq!(a.start, b.start, "{}", a.name);
            assert_eq!(a.calc.critical, b.calc.critical, "{}", a.name);
        }
        let json = std::env::temp_dir().join("planwright_test.plan");
        save_json(&p, &json).unwrap();
        let r = load_json(&json).unwrap();
        assert_eq!(r.tasks.len(), p.tasks.len());
    }

    #[test]
    fn summary_percent_splits_in_date_order() {
        let monday = NaiveDate::from_ymd_opt(2026, 11, 16).unwrap();
        let mut p = crate::samples::website_launch(monday);
        crate::schedule::schedule(&mut p);
        // "Design" = Wireframes 4d -> Visual design 5d -> Design review 1d (10 days in a chain)
        let d = p.tasks.iter().position(|t| t.name == "Design").unwrap();
        crate::schedule::set_summary_percent(&mut p, d, 50.0);
        crate::schedule::schedule(&mut p);
        let get = |n: &str| p.tasks.iter().find(|t| t.name == n).unwrap().percent;
        assert_eq!(get("Wireframes"), 100.0);
        assert_eq!(get("Visual design"), 20.0);
        assert_eq!(get("Design review"), 0.0);
        assert_eq!(p.tasks[d].percent, 50.0);
    }

    #[test]
    fn critical_path_matches_rules() {
        let monday = NaiveDate::from_ymd_opt(2026, 11, 16).unwrap();
        let mut p = crate::samples::website_launch(monday);
        crate::schedule::schedule(&mut p);
        let get = |n: &str| p.tasks.iter().find(|t| t.name == n).unwrap();
        assert!(get("Visual design").calc.critical);
        assert!(!get("Set up hosting").calc.critical);
        assert!(get("Set up hosting").calc.total_slack > 0);
        // FS link: Wireframes starts at the next working moment after the milestone
        // (12:00 is lunch, so 13:00) - CoumputeEarlyStartPDM_FS snaps when duration > 0
        let ms = get("Requirements signed off").finish;
        assert_eq!(get("Wireframes").start, p.calendar.next_work_start(ms));
        assert_eq!(get("Wireframes").start.format("%H:%M").to_string(), "13:00");
    }
}
