//! Working-time calendar. Defaults follow MECHANICS.md (Standard calendar:
//! Monday-Friday 08:00-12:00 and 13:00-17:00, weekends off).

use chrono::{Datelike, Duration, NaiveDate, NaiveDateTime, NaiveTime, Timelike};
use serde::{Deserialize, Serialize};

/// A day off (holiday, shutdown) or a range of them.
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Exception {
    pub name: String,
    pub from: NaiveDate,
    pub to: NaiveDate,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct WorkCalendar {
    pub name: String,
    /// Working intervals per weekday (0 = Monday .. 6 = Sunday), in minutes from midnight.
    pub week: [Vec<(u32, u32)>; 7],
    pub exceptions: Vec<Exception>,
}

/// Search window so a calendar without any working time can't loop forever.
const MAX_DAYS: i64 = 3660;

impl Default for WorkCalendar {
    fn default() -> Self {
        Self::standard()
    }
}

impl WorkCalendar {
    pub fn standard() -> Self {
        let day = vec![(8 * 60, 12 * 60), (13 * 60, 17 * 60)];
        WorkCalendar {
            name: "Standard".into(),
            week: [
                day.clone(),
                day.clone(),
                day.clone(),
                day.clone(),
                day,
                vec![],
                vec![],
            ],
            exceptions: vec![],
        }
    }

    pub fn twenty_four_hours() -> Self {
        let day = vec![(0, 24 * 60)];
        WorkCalendar {
            name: "24 Hours".into(),
            week: [
                day.clone(),
                day.clone(),
                day.clone(),
                day.clone(),
                day.clone(),
                day.clone(),
                day,
            ],
            exceptions: vec![],
        }
    }

    pub fn night_shift() -> Self {
        // Mon-Fri 23:00-24:00 plus 00:00-03:00 / 04:00-08:00 the next morning, simplified to one block per night.
        let mut week: [Vec<(u32, u32)>; 7] = Default::default();
        for d in 0..5 {
            week[d].push((23 * 60, 24 * 60));
        }
        for d in 1..6 {
            week[d].insert(0, (0, 3 * 60));
            week[d].insert(1, (4 * 60, 8 * 60));
        }
        WorkCalendar { name: "Night Shift".into(), week, exceptions: vec![] }
    }

    pub fn is_exception(&self, d: NaiveDate) -> bool {
        self.exceptions.iter().any(|e| d >= e.from && d <= e.to)
    }

    pub fn intervals(&self, d: NaiveDate) -> &[(u32, u32)] {
        if self.is_exception(d) {
            return &[];
        }
        &self.week[d.weekday().num_days_from_monday() as usize]
    }

    pub fn is_working_day(&self, d: NaiveDate) -> bool {
        !self.intervals(d).is_empty()
    }

    #[allow(dead_code)]
    pub fn day_minutes(&self, d: NaiveDate) -> i64 {
        self.intervals(d).iter().map(|(s, e)| (*e - *s) as i64).sum()
    }

    fn at(d: NaiveDate, minute: u32) -> NaiveDateTime {
        if minute >= 24 * 60 {
            (d + Duration::days(1)).and_time(NaiveTime::MIN)
        } else {
            d.and_hms_opt(minute / 60, minute % 60, 0).unwrap()
        }
    }

    fn minute_of(dt: NaiveDateTime) -> u32 {
        dt.hour() * 60 + dt.minute()
    }

    /// The first working moment at or after `dt`.
    pub fn next_work_start(&self, dt: NaiveDateTime) -> NaiveDateTime {
        let mut d = dt.date();
        let m = Self::minute_of(dt);
        for (s, e) in self.intervals(d) {
            if m < *e {
                return if m >= *s { dt } else { Self::at(d, *s) };
            }
        }
        for _ in 0..MAX_DAYS {
            d = d + Duration::days(1);
            if let Some((s, _)) = self.intervals(d).first() {
                return Self::at(d, *s);
            }
        }
        dt
    }

    /// The last working moment at or before `dt` (an interval end counts).
    pub fn prev_work_end(&self, dt: NaiveDateTime) -> NaiveDateTime {
        let mut d = dt.date();
        let m = Self::minute_of(dt);
        // midnight belongs to the previous day's end
        if m == 0 {
            d = d - Duration::days(1);
            if let Some((_, e)) = self.intervals(d).last() {
                return Self::at(d, *e);
            }
        } else {
            for (s, e) in self.intervals(d).iter().rev() {
                if m > *s {
                    return if m <= *e { dt } else { Self::at(d, *e) };
                }
            }
        }
        for _ in 0..MAX_DAYS {
            d = d - Duration::days(1);
            if let Some((_, e)) = self.intervals(d).last() {
                return Self::at(d, *e);
            }
        }
        dt
    }

    /// Moves `minutes` of working time forward (or backward when negative).
    /// Zero returns `dt` unchanged.
    pub fn add_minutes(&self, dt: NaiveDateTime, minutes: i64) -> NaiveDateTime {
        if minutes == 0 {
            return dt;
        }
        if minutes > 0 {
            let mut cur = self.next_work_start(dt);
            let mut rem = minutes;
            for _ in 0..(MAX_DAYS * 4) {
                let d = cur.date();
                let m = Self::minute_of(cur);
                let iv = self.intervals(d).iter().find(|(s, e)| m >= *s && m < *e).copied();
                let Some((_, e)) = iv else {
                    cur = self.next_work_start(cur + Duration::minutes(1));
                    continue;
                };
                let avail = (e - m) as i64;
                if rem <= avail {
                    return cur + Duration::minutes(rem);
                }
                rem -= avail;
                cur = self.next_work_start(Self::at(d, e));
            }
            cur
        } else {
            let mut cur = self.prev_work_end(dt);
            let mut rem = -minutes;
            for _ in 0..(MAX_DAYS * 4) {
                let (d, m) = if Self::minute_of(cur) == 0 {
                    let d = cur.date() - Duration::days(1);
                    (d, 24 * 60)
                } else {
                    (cur.date(), Self::minute_of(cur))
                };
                let iv = self.intervals(d).iter().find(|(s, e)| m > *s && m <= *e).copied();
                let Some((s, _)) = iv else {
                    cur = self.prev_work_end(cur - Duration::minutes(1));
                    continue;
                };
                let avail = (m - s) as i64;
                if rem <= avail {
                    return Self::at(d, m) - Duration::minutes(rem);
                }
                rem -= avail;
                cur = self.prev_work_end(Self::at(d, s));
            }
            cur
        }
    }

    /// Working minutes between two moments (negative when `b` is before `a`).
    pub fn work_between(&self, a: NaiveDateTime, b: NaiveDateTime) -> i64 {
        if b < a {
            return -self.work_between(b, a);
        }
        let mut total = 0i64;
        let mut d = a.date();
        let end_d = b.date();
        let mut guard = 0;
        while d <= end_d && guard < MAX_DAYS * 3 {
            for (s, e) in self.intervals(d) {
                let is = Self::at(d, *s);
                let ie = Self::at(d, *e);
                let lo = if is > a { is } else { a };
                let hi = if ie < b { ie } else { b };
                if hi > lo {
                    total += (hi - lo).num_minutes();
                }
            }
            d = d + Duration::days(1);
            guard += 1;
        }
        total
    }

    /// The default start time of a working day (first interval start), used when a date is typed.
    pub fn day_start(&self, d: NaiveDate) -> NaiveDateTime {
        match self.intervals(d).first() {
            Some((s, _)) => Self::at(d, *s),
            None => self.next_work_start(d.and_hms_opt(0, 0, 0).unwrap()),
        }
    }

    /// The default finish time of a working day (last interval end).
    pub fn day_finish(&self, d: NaiveDate) -> NaiveDateTime {
        match self.intervals(d).last() {
            Some((_, e)) => Self::at(d, *e),
            None => self.prev_work_end((d + Duration::days(1)).and_hms_opt(0, 0, 0).unwrap()),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn dt(y: i32, mo: u32, d: u32, h: u32, mi: u32) -> NaiveDateTime {
        NaiveDate::from_ymd_opt(y, mo, d).unwrap().and_hms_opt(h, mi, 0).unwrap()
    }
    #[test]
    fn one_day_ends_at_five() {
        let c = WorkCalendar::standard();
        // 2026-11-23 is a Monday
        assert_eq!(c.add_minutes(dt(2026, 11, 23, 8, 0), 480), dt(2026, 11, 23, 17, 0));
        assert_eq!(c.add_minutes(dt(2026, 11, 27, 17, 0), 480), dt(2026, 11, 30, 17, 0));
        assert_eq!(c.next_work_start(dt(2026, 11, 27, 17, 0)), dt(2026, 11, 30, 8, 0));
        assert_eq!(c.add_minutes(dt(2026, 11, 23, 17, 0), -480), dt(2026, 11, 23, 8, 0));
        assert_eq!(c.work_between(dt(2026, 11, 23, 8, 0), dt(2026, 11, 30, 8, 0)), 2400);
        assert_eq!(c.prev_work_end(dt(2026, 11, 30, 8, 0)), dt(2026, 11, 27, 17, 0));
    }
}
