//! Writes dist/Planwright-Mac-Kit.zip: everything needed to build the Mac app on a Mac,
//! with Unix permissions so "Build Planwright.command" can be double-clicked.
//! Run: cargo run --example pack_mac_kit

use std::fs;
use std::path::{Path, PathBuf};

fn crc32(data: &[u8]) -> u32 {
    let mut table = [0u32; 256];
    for i in 0..256u32 {
        let mut c = i;
        for _ in 0..8 {
            c = if c & 1 != 0 { 0xEDB8_8320 ^ (c >> 1) } else { c >> 1 };
        }
        table[i as usize] = c;
    }
    let mut crc = 0xFFFF_FFFFu32;
    for &b in data {
        crc = table[((crc ^ b as u32) & 0xFF) as usize] ^ (crc >> 8);
    }
    !crc
}

fn files_under(dir: &Path, out: &mut Vec<PathBuf>) {
    let mut entries: Vec<_> = fs::read_dir(dir).unwrap().flatten().map(|e| e.path()).collect();
    entries.sort();
    for p in entries {
        if p.is_dir() {
            files_under(&p, out);
        } else {
            out.push(p);
        }
    }
}

fn main() {
    let root = Path::new(env!("CARGO_MANIFEST_DIR"));
    // (path inside the zip, file on disk, runnable?)
    let mut items: Vec<(String, PathBuf, bool)> = vec![
        ("Planwright/Build Planwright.command".into(), root.join("packaging/macos/Build Planwright.command"), true),
        ("Planwright/Cargo.toml".into(), root.join("Cargo.toml"), false),
        ("Planwright/Cargo.lock".into(), root.join("Cargo.lock"), false),
        ("Planwright/MECHANICS.md".into(), root.join("MECHANICS.md"), false),
        ("Planwright/mechanics.json".into(), root.join("mechanics.json"), false),
        ("Planwright/README.md".into(), root.join("dist/README.md"), false),
    ];
    for sub in ["src", "packaging", "examples", ".github"] {
        let mut v = vec![];
        files_under(&root.join(sub), &mut v);
        for f in v {
            let rel = f.strip_prefix(root).unwrap().to_string_lossy().replace('\\', "/");
            let exec = rel.ends_with(".sh") || rel.ends_with(".command");
            items.push((format!("Planwright/{rel}"), f, exec));
        }
    }

    let mut zip: Vec<u8> = vec![];
    let mut central: Vec<u8> = vec![];
    let le16 = |v: &mut Vec<u8>, x: u16| v.extend_from_slice(&x.to_le_bytes());
    let le32 = |v: &mut Vec<u8>, x: u32| v.extend_from_slice(&x.to_le_bytes());
    let mut count = 0u16;
    for (name, path, exec) in &items {
        let data = fs::read(path).unwrap_or_else(|e| panic!("{}: {e}", path.display()));
        let crc = crc32(&data);
        let offset = zip.len() as u32;
        // local file header, stored (no compression)
        le32(&mut zip, 0x0403_4b50);
        le16(&mut zip, 20);
        le16(&mut zip, 0x0800); // UTF-8 names
        le16(&mut zip, 0);
        le16(&mut zip, 0);
        le16(&mut zip, 0x21);
        le32(&mut zip, crc);
        le32(&mut zip, data.len() as u32);
        le32(&mut zip, data.len() as u32);
        le16(&mut zip, name.len() as u16);
        le16(&mut zip, 0);
        zip.extend_from_slice(name.as_bytes());
        zip.extend_from_slice(&data);
        // central directory entry: made by Unix (3), mode in the high 16 bits
        let mode: u32 = if *exec { 0o100755 } else { 0o100644 };
        le32(&mut central, 0x0201_4b50);
        le16(&mut central, (3 << 8) | 30);
        le16(&mut central, 20);
        le16(&mut central, 0x0800);
        le16(&mut central, 0);
        le16(&mut central, 0);
        le16(&mut central, 0x21);
        le32(&mut central, crc);
        le32(&mut central, data.len() as u32);
        le32(&mut central, data.len() as u32);
        le16(&mut central, name.len() as u16);
        le16(&mut central, 0);
        le16(&mut central, 0);
        le16(&mut central, 0);
        le16(&mut central, 0);
        le32(&mut central, mode << 16);
        le32(&mut central, offset);
        central.extend_from_slice(name.as_bytes());
        count += 1;
    }
    let cd_offset = zip.len() as u32;
    let cd_size = central.len() as u32;
    zip.extend_from_slice(&central);
    le32(&mut zip, 0x0605_4b50);
    le16(&mut zip, 0);
    le16(&mut zip, 0);
    le16(&mut zip, count);
    le16(&mut zip, count);
    le32(&mut zip, cd_size);
    le32(&mut zip, cd_offset);
    le16(&mut zip, 0);
    let out = root.join("dist/Planwright-Mac-Kit.zip");
    fs::create_dir_all(out.parent().unwrap()).unwrap();
    fs::write(&out, &zip).unwrap();
    println!("wrote {} ({} files, {} bytes)", out.display(), count, zip.len());
}
