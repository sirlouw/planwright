# Planwright — how to get the app

## Mac
The Mac app is made on your Mac in one step (Apple only allows its Mac-building tools on Macs):

1. Copy **Planwright-Mac-Kit.zip** to your Mac and double-click it to unzip.
2. In the new **Planwright** folder, double-click **Build Planwright.command**.
   (If the Mac says it's from an unidentified developer: right-click it, choose **Open**, then **Open**.)
3. The first time it installs Apple's command line tools and Rust (click **Install** if asked, then double-click the file again). The build takes about 5–10 minutes.
4. A Finder window opens with **Planwright.app** and **Planwright.dmg**. Drag Planwright.app into Applications.
   The first time you open it, right-click it and choose **Open**.

The app runs on both Apple Silicon and Intel Macs.

**No Mac at hand for building?** Put the Planwright folder in a GitHub repository, open **Actions → Mac app → Run workflow**, and download the finished **Planwright-mac** file (it holds Planwright.dmg).

## Windows
`windows/Planwright.exe` is ready to run: double-click it.

## Files
* Your own plans save as `.plan` files.
* File ▸ Import / Export reads and writes Microsoft Project XML (`.xml`), so plans can move to and from Microsoft Project.
* File ▸ Export to Excel writes the task table as CSV.
