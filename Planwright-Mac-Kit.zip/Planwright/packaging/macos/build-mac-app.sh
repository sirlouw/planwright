#!/bin/sh
# Builds Planwright.app (Apple Silicon + Intel) and Planwright.dmg on a Mac.
# Needs: Xcode command line tools (xcode-select --install) and Rust (https://rustup.rs).
# Run from anywhere:  sh packaging/macos/build-mac-app.sh
set -e
cd "$(dirname "$0")/../.."

rustup target add aarch64-apple-darwin x86_64-apple-darwin
cargo build --release --target aarch64-apple-darwin
cargo build --release --target x86_64-apple-darwin

OUT=dist/macos
APP="$OUT/Planwright.app"
rm -rf "$OUT"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"

# one program that runs on both kinds of Mac
lipo -create \
  target/aarch64-apple-darwin/release/planwright \
  target/x86_64-apple-darwin/release/planwright \
  -output "$APP/Contents/MacOS/planwright"
cp packaging/macos/Info.plist "$APP/Contents/Info.plist"

# app icon from packaging/icon.png
ICONSET="$OUT/Planwright.iconset"
mkdir -p "$ICONSET"
for s in 16 32 128 256 512; do
  sips -z $s $s packaging/icon.png --out "$ICONSET/icon_${s}x${s}.png" >/dev/null
  d=$((s * 2))
  sips -z $d $d packaging/icon.png --out "$ICONSET/icon_${s}x${s}@2x.png" >/dev/null
done
iconutil -c icns "$ICONSET" -o "$APP/Contents/Resources/Planwright.icns"
rm -rf "$ICONSET"

# ad-hoc signature so macOS will open it on this Mac
codesign --force --deep --sign - "$APP"

# disk image to share
hdiutil create -volname Planwright -srcfolder "$APP" -ov -format UDZO "$OUT/Planwright.dmg"

echo "Done: $APP and $OUT/Planwright.dmg"
echo "First launch on another Mac: right-click Planwright.app > Open (it is not notarized)."
